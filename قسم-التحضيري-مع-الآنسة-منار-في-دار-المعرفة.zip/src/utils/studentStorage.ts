import { Student, PUPIL_CHARACTERS } from '../types/student';

const STORAGE_KEY = 'dar_al_marifa_manar_students_db_v1';
const ACTIVE_STUDENT_KEY = 'dar_al_marifa_active_student_id';

const DEFAULT_STUDENTS: Student[] = [
  {
    id: 'pupil-1',
    name: 'أمين',
    gender: 'boy',
    characterId: 'lion',
    characterTitle: 'بطل الشجاعة والإقدام',
    characterEmoji: '🦁',
    stars: 15,
    isPresent: true,
    notes: 'ممتاز في الحساب والعد من 1 إلى 20',
    createdAt: Date.now() - 86400000 * 5,
    gamesPlayed: 6,
    badges: ['⭐ نجم الحساب', '🦁 الشجاع']
  },
  {
    id: 'pupil-2',
    name: 'مَرْيَم',
    gender: 'girl',
    characterId: 'butterfly',
    characterTitle: 'أميرة الرقة والإبداع',
    characterEmoji: '🦋',
    stars: 18,
    isPresent: true,
    notes: 'مبدعة في مخارج الحروف وقراءة الكلمات',
    createdAt: Date.now() - 86400000 * 5,
    gamesPlayed: 8,
    badges: ['👑 أميرة الحروف', '🦋 المبدعة']
  },
  {
    id: 'pupil-3',
    name: 'يُوسُف',
    gender: 'boy',
    characterId: 'astronaut',
    characterTitle: 'مستكشف العلوم والأرقام',
    characterEmoji: '🚀',
    stars: 14,
    isPresent: true,
    notes: 'شغوف بالنشاط العلمي واكتشاف العالم',
    createdAt: Date.now() - 86400000 * 4,
    gamesPlayed: 5,
    badges: ['🚀 المستكشف', '🔬 بطل العلوم']
  },
  {
    id: 'pupil-4',
    name: 'سَارَة',
    gender: 'girl',
    characterId: 'bee',
    characterTitle: 'نجمة التعاون والنشاط',
    characterEmoji: '🐝',
    stars: 16,
    isPresent: true,
    notes: 'نشيطة جداً ومتعاونة مع زميلاتها',
    createdAt: Date.now() - 86400000 * 4,
    gamesPlayed: 7,
    badges: ['🐝 النحلة الذهبية', '💖 صديقة القسم']
  },
  {
    id: 'pupil-5',
    name: 'رَيَّان',
    gender: 'boy',
    characterId: 'falcon',
    characterTitle: 'صاحب النظرة الثاقبة',
    characterEmoji: '🦅',
    stars: 12,
    isPresent: true,
    notes: 'سريع الملاحظة في ألعاب الذاكرة',
    createdAt: Date.now() - 86400000 * 3,
    gamesPlayed: 4,
    badges: ['🦅 الصقر الذكي']
  },
  {
    id: 'pupil-6',
    name: 'فَاطِمَة الزَّهْرَاء',
    gender: 'girl',
    characterId: 'artist',
    characterTitle: 'رسامة الحروف والجمال',
    characterEmoji: '🎨',
    stars: 17,
    isPresent: true,
    notes: 'خطها جميل جداً ومتقنة لكتابة الحروف',
    createdAt: Date.now() - 86400000 * 3,
    gamesPlayed: 6,
    badges: ['🎨 الفنانة المبدعة', '✍️ بطلة الخط']
  }
];

class StudentDatabaseService {
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.initDatabase();
  }

  private initDatabase(): void {
    try {
      const existing = localStorage.getItem(STORAGE_KEY);
      if (!existing) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_STUDENTS));
      }
    } catch (e) {
      console.warn('LocalStorage read/write issue in constructor', e);
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    this.listeners.forEach(fn => {
      try {
        fn();
      } catch (err) {
        console.error(err);
      }
    });
  }

  public getAll(): Student[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (!data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_STUDENTS));
        return DEFAULT_STUDENTS;
      }
      return JSON.parse(data) as Student[];
    } catch (e) {
      console.error('Failed to parse students from localStorage', e);
      return DEFAULT_STUDENTS;
    }
  }

  public saveAll(students: Student[]): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
      this.notify();
    } catch (e) {
      console.error('Failed to save students to localStorage', e);
    }
  }

  public addStudent(data: {
    name: string;
    gender: 'boy' | 'girl';
    characterId: string;
    notes?: string;
  }): Student {
    const students = this.getAll();
    const char = PUPIL_CHARACTERS.find(c => c.id === data.characterId) || PUPIL_CHARACTERS[0];
    
    const newStudent: Student = {
      id: `pupil-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: data.name.trim(),
      gender: data.gender,
      characterId: char.id,
      characterTitle: char.title,
      characterEmoji: char.emoji,
      stars: 0,
      isPresent: true,
      notes: data.notes || '',
      createdAt: Date.now(),
      gamesPlayed: 0,
      badges: [`${char.emoji} ${char.name}`]
    };

    const updated = [newStudent, ...students];
    this.saveAll(updated);
    return newStudent;
  }

  public updateStudent(id: string, updates: Partial<Student>): Student | null {
    const students = this.getAll();
    const index = students.findIndex(s => s.id === id);
    if (index === -1) return null;

    let charUpdates = {};
    if (updates.characterId && updates.characterId !== students[index].characterId) {
      const char = PUPIL_CHARACTERS.find(c => c.id === updates.characterId);
      if (char) {
        charUpdates = {
          characterTitle: char.title,
          characterEmoji: char.emoji
        };
      }
    }

    students[index] = {
      ...students[index],
      ...updates,
      ...charUpdates
    };

    this.saveAll(students);
    return students[index];
  }

  public deleteStudent(id: string): boolean {
    const students = this.getAll();
    const filtered = students.filter(s => s.id !== id);
    if (filtered.length !== students.length) {
      this.saveAll(filtered);
      // If deleted student was active in turn, clear active
      if (this.getActiveStudentId() === id) {
        this.setActiveStudentId(filtered[0]?.id || null);
      }
      return true;
    }
    return false;
  }

  public addStars(id: string, amount: number): Student | null {
    const students = this.getAll();
    const target = students.find(s => s.id === id);
    if (!target) return null;

    target.stars = Math.max(0, target.stars + amount);
    this.saveAll(students);
    return target;
  }

  public toggleAttendance(id: string): Student | null {
    const students = this.getAll();
    const target = students.find(s => s.id === id);
    if (!target) return null;

    target.isPresent = !target.isPresent;
    this.saveAll(students);
    return target;
  }

  public recordGameRound(id: string): Student | null {
    const students = this.getAll();
    const target = students.find(s => s.id === id);
    if (!target) return null;

    target.gamesPlayed = (target.gamesPlayed || 0) + 1;
    target.lastPlayedAt = Date.now();
    this.saveAll(students);
    return target;
  }

  public getActiveStudentId(): string | null {
    return localStorage.getItem(ACTIVE_STUDENT_KEY);
  }

  public setActiveStudentId(id: string | null): void {
    if (id) {
      localStorage.setItem(ACTIVE_STUDENT_KEY, id);
    } else {
      localStorage.removeItem(ACTIVE_STUDENT_KEY);
    }
    this.notify();
  }

  public getNextStudentTurn(currentId?: string): Student | null {
    const list = this.getAll().filter(s => s.isPresent);
    if (list.length === 0) return null;
    if (!currentId) return list[0];

    const idx = list.findIndex(s => s.id === currentId);
    if (idx === -1 || idx === list.length - 1) {
      return list[0];
    }
    return list[idx + 1];
  }

  public getRandomStudent(): Student | null {
    const list = this.getAll().filter(s => s.isPresent);
    if (list.length === 0) return null;
    const randomIndex = Math.floor(Math.random() * list.length);
    return list[randomIndex];
  }

  public exportBackup(): string {
    const all = this.getAll();
    return JSON.stringify(
      {
        version: '1.0',
        school: 'دار المعرفة',
        teacher: 'الآنسة منار',
        exportDate: new Date().toISOString(),
        students: all
      },
      null,
      2
    );
  }

  public importBackup(jsonString: string): { success: boolean; count: number; error?: string } {
    try {
      const parsed = JSON.parse(jsonString);
      const list = Array.isArray(parsed) ? parsed : parsed.students;
      if (!Array.isArray(list) || list.length === 0) {
        return { success: false, count: 0, error: 'الملف لا يحتوي على قائمة تلاميذ صالحة' };
      }

      // Basic validation
      const cleaned: Student[] = list.map((item: any, idx: number) => ({
        id: item.id || `pupil-imported-${Date.now()}-${idx}`,
        name: String(item.name || `تلميذ ${idx + 1}`),
        gender: item.gender === 'girl' ? 'girl' : 'boy',
        characterId: item.characterId || 'star',
        characterTitle: item.characterTitle || 'بطل القسم',
        characterEmoji: item.characterEmoji || '⭐',
        stars: Number(item.stars) || 0,
        isPresent: item.isPresent !== false,
        notes: item.notes || '',
        createdAt: item.createdAt || Date.now(),
        gamesPlayed: Number(item.gamesPlayed) || 0,
        badges: Array.isArray(item.badges) ? item.badges : ['⭐ بطل القسم']
      }));

      this.saveAll(cleaned);
      return { success: true, count: cleaned.length };
    } catch (err: any) {
      return { success: false, count: 0, error: err.message || 'فشل قراءة الملف' };
    }
  }

  public resetToDefault(): Student[] {
    this.saveAll(DEFAULT_STUDENTS);
    this.setActiveStudentId(DEFAULT_STUDENTS[0].id);
    return DEFAULT_STUDENTS;
  }
}

export const studentDB = new StudentDatabaseService();
