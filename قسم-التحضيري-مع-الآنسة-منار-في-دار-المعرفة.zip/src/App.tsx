import React, { useState } from 'react';
import { TeacherNavbar, ActiveModule } from './components/TeacherNavbar';
import { HomeDashboard } from './components/HomeDashboard';
import { LessonsCatalogView } from './components/LessonsCatalogView';
import { LetterModuleView } from './components/LetterModuleView';
import { NumberModuleView } from './components/NumberModuleView';
import { IslamicModuleView } from './components/IslamicModuleView';
import { ScienceModuleView } from './components/ScienceModuleView';
import { WritingModuleView } from './components/WritingModuleView';
import { ColorsShapesModuleView } from './components/ColorsShapesModuleView';
import { WorldAndValuesModuleView } from './components/WorldAndValuesModuleView';
import { SongsModuleView } from './components/SongsModuleView';
import { GamesHubView } from './components/GamesHubView';
import { AssessmentView } from './components/AssessmentView';
import { StudentsManagementView } from './components/StudentsManagementView';
import { OfflineIndicator } from './components/OfflineIndicator';
import { soundEngine } from './utils/audio';

export default function App() {
  const [currentModule, setCurrentModule] = useState<ActiveModule>('home');
  const [dataShowZoom, setDataShowZoom] = useState<number>(1);
  const [starsCount, setStarsCount] = useState<number>(12);

  const handleEarnStar = () => {
    setStarsCount(prev => prev + 1);
  };

  const getModuleTitle = (mod: ActiveModule): string => {
    switch (mod) {
      case 'students': return 'قائمة أبطال وتلاميذ القسم';
      case 'lessons_catalog': return 'فهرس الدروس والأنشطة';
      case 'letters': return 'الحروف واللغة العربية';
      case 'numbers': return 'الأعداد (1 إلى 100)';
      case 'islamic': return 'التربية الإسلامية';
      case 'science': return 'النشاط العلمي';
      case 'writing': return 'الكتابة والخط';
      case 'colors_shapes': return 'الألوان والأشكال';
      case 'world': return 'اكتشف العالم';
      case 'behavior': return 'القيم والسلوك';
      case 'songs': return 'الأناشيد التعليمية';
      case 'games': return 'بنك الألعاب والمراجعة';
      case 'assessment': return 'التقييم والشهادة';
      default: return '';
    }
  };

  return (
    <div 
      className="min-h-screen bg-[#F8FAFB] flex flex-col transition-all duration-200"
      style={{
        zoom: dataShowZoom > 1 ? dataShowZoom : undefined,
      }}
    >
      {/* When Home: Full-screen Classroom Immersion with Miss Manar at Dar Al-Ma'rifa */}
      {currentModule === 'home' ? (
        <HomeDashboard onNavigate={setCurrentModule} starsCount={starsCount} />
      ) : (
        <>
          {/* Teacher Top Navigation & Data Show Controls */}
          <TeacherNavbar
            currentModule={currentModule}
            onNavigate={setCurrentModule}
            dataShowZoom={dataShowZoom}
            setDataShowZoom={setDataShowZoom}
            starsCount={starsCount}
            moduleTitle={getModuleTitle(currentModule)}
            onResetActivity={() => {
              soundEngine.playPop(400);
              const temp = currentModule;
              setCurrentModule('home');
              setTimeout(() => setCurrentModule(temp), 50);
            }}
          />

          {/* Main Lessons & Activities Container */}
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 select-none">
            {currentModule === 'students' && (
              <StudentsManagementView onNavigateToGames={() => setCurrentModule('games')} />
            )}

            {currentModule === 'lessons_catalog' && (
              <LessonsCatalogView onNavigate={setCurrentModule} />
            )}

            {currentModule === 'letters' && (
              <LetterModuleView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'numbers' && (
              <NumberModuleView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'islamic' && (
              <IslamicModuleView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'science' && (
              <ScienceModuleView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'writing' && (
              <WritingModuleView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'colors_shapes' && (
              <ColorsShapesModuleView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'world' && (
              <WorldAndValuesModuleView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'behavior' && (
              <WorldAndValuesModuleView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'songs' && (
              <SongsModuleView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'games' && (
              <GamesHubView onEarnStar={handleEarnStar} />
            )}

            {currentModule === 'assessment' && (
              <AssessmentView starsCount={starsCount} onEarnStar={handleEarnStar} />
            )}
          </main>

          {/* Clean Educational Classroom Footer with Miss Manar */}
          <footer className="mt-auto border-t border-slate-200 bg-white/80 py-4 px-6 select-none">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-800">قسم التحضيري مع الآنسة منار</span>
                <span>•</span>
                <span>القسم الرقمي التفاعلي للعرض على Data Show</span>
                <span>•</span>
                <span className="text-rose-600 font-medium">التحضيري والسنة الأولى ابتدائي</span>
              </div>

              <div className="flex items-center gap-4">
                <button 
                  onClick={() => soundEngine.speakArabic('مرحباً بكم في قسم التحضيري مع الآنسة منار!')} 
                  className="hover:text-rose-600 transition-colors font-medium cursor-pointer"
                >
                  🔊 ترحيب الآنسة منار
                </button>
                <span>•</span>
                <span>دار المعرفة</span>
              </div>
            </div>
          </footer>
        </>
      )}

      {/* Offline connectivity indicator */}
      <OfflineIndicator />
    </div>
  );
}
