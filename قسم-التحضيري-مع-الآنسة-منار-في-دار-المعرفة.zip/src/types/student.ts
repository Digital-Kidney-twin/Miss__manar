export interface PupilCharacter {
  id: string;
  name: string;
  title: string;
  emoji: string;
  avatarBg: string;
  badgeBorder: string;
  description: string;
}

export const PUPIL_CHARACTERS: PupilCharacter[] = [
  {
    id: 'lion',
    name: 'الأسد الشجاع',
    title: 'بطل الشجاعة والإقدام',
    emoji: '🦁',
    avatarBg: 'bg-amber-100 text-amber-700',
    badgeBorder: 'border-amber-400',
    description: 'شجاع ومبادر في الإجابات'
  },
  {
    id: 'butterfly',
    name: 'الفراشة الذكية',
    title: 'أميرة الرقة والإبداع',
    emoji: '🦋',
    avatarBg: 'bg-pink-100 text-pink-700',
    badgeBorder: 'border-pink-400',
    description: 'سريعة البديهة ومبدعة في التلوين'
  },
  {
    id: 'falcon',
    name: 'الصقر البطل',
    title: 'صاحب النظرة الثاقبة',
    emoji: '🦅',
    avatarBg: 'bg-sky-100 text-sky-700',
    badgeBorder: 'border-sky-400',
    description: 'قوي التركيز ودقيق الملاحظة'
  },
  {
    id: 'bee',
    name: 'النحلة النشيطة',
    title: 'نجمة التعاون والنشاط',
    emoji: '🐝',
    avatarBg: 'bg-yellow-100 text-yellow-800',
    badgeBorder: 'border-yellow-400',
    description: 'نشيطة دائماً ومحبة للمساعدة'
  },
  {
    id: 'astronaut',
    name: 'رائد الفضاء الصغير',
    title: 'مستكشف العلوم والأرقام',
    emoji: '🚀',
    avatarBg: 'bg-indigo-100 text-indigo-700',
    badgeBorder: 'border-indigo-400',
    description: 'يحب استكشاف الكون وحل المسائل'
  },
  {
    id: 'rabbit',
    name: 'الأرنب السريع',
    title: 'بطل السرعة والذكاء',
    emoji: '🐇',
    avatarBg: 'bg-rose-100 text-rose-700',
    badgeBorder: 'border-rose-400',
    description: 'سريع في القراءة والعد'
  },
  {
    id: 'owl',
    name: 'البومة الحكيمة',
    title: 'صديق الهدوء والحكمة',
    emoji: '🦉',
    avatarBg: 'bg-emerald-100 text-emerald-800',
    badgeBorder: 'border-emerald-400',
    description: 'هادئ ومفكر بارع'
  },
  {
    id: 'artist',
    name: 'الفنان المبدع',
    title: 'رسام الحروف والجمال',
    emoji: '🎨',
    avatarBg: 'bg-purple-100 text-purple-700',
    badgeBorder: 'border-purple-400',
    description: 'خطه جميل ومحب للفنون'
  },
  {
    id: 'star',
    name: 'النجم اللامع',
    title: 'شعلة النشاط والتميز',
    emoji: '⭐',
    avatarBg: 'bg-amber-200 text-amber-900',
    badgeBorder: 'border-amber-500',
    description: 'يضيء القسم بإجاباته المتقنة'
  },
  {
    id: 'tiger',
    name: 'النمر القوي',
    title: 'فارس التحديات',
    emoji: '🐯',
    avatarBg: 'bg-orange-100 text-orange-700',
    badgeBorder: 'border-orange-400',
    description: 'يحب التحديات الصعبة والألعاب'
  },
  {
    id: 'dolphin',
    name: 'الدلفين الودود',
    title: 'صديق الجميع المحبوب',
    emoji: '🐬',
    avatarBg: 'bg-cyan-100 text-cyan-800',
    badgeBorder: 'border-cyan-400',
    description: 'ودود ومحب لرفاقه في القسم'
  },
  {
    id: 'knight',
    name: 'الفارس الصغير',
    title: 'حامي الأخلاق والنظام',
    emoji: '🛡️',
    avatarBg: 'bg-teal-100 text-teal-800',
    badgeBorder: 'border-teal-400',
    description: 'منضبط ومؤدب ويحترم الجميع'
  }
];

export interface Student {
  id: string;
  name: string;
  gender: 'boy' | 'girl';
  characterId: string;
  characterTitle: string;
  characterEmoji: string;
  stars: number;
  isPresent: boolean;
  notes?: string;
  createdAt: number;
  lastPlayedAt?: number;
  gamesPlayed: number;
  badges: string[];
}
