import React, { useState, useEffect } from 'react';
import { 
  Volume2, 
  RotateCcw, 
  CheckCircle2, 
  Sparkles, 
  Gamepad2, 
  Dices,
  Layers,
  ArrowUpDown,
  Trophy,
  ArrowRight,
  UserCheck,
  Users,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { soundEngine } from '../utils/audio';
import { studentDB } from '../utils/studentStorage';
import { Student, PUPIL_CHARACTERS } from '../types/student';
import confetti from 'canvas-confetti';

interface GamesHubViewProps {
  onEarnStar: () => void;
  onNavigateToStudents?: () => void;
}

type RealGameType = 
  | 'spin_wheel'
  | 'word_builder'
  | 'number_sort'
  | 'animal_sort'
  | 'listen_choose'
  | 'whack_letter'
  | 'memory';

export const GamesHubView: React.FC<GamesHubViewProps> = ({ onEarnStar, onNavigateToStudents }) => {
  const [selectedGame, setSelectedGame] = useState<RealGameType>('spin_wheel');
  const [roundScore, setRoundScore] = useState(0);

  // Student Turn System
  const [students, setStudents] = useState<Student[]>([]);
  const [activeStudent, setActiveStudent] = useState<Student | null>(null);
  const [isPickingTurn, setIsPickingTurn] = useState(false);

  useEffect(() => {
    const refresh = () => {
      const all = studentDB.getAll();
      setStudents(all);
      const activeId = studentDB.getActiveStudentId();
      const current = all.find(s => s.id === activeId) || all.find(s => s.isPresent) || all[0] || null;
      setActiveStudent(current);
      if (current && !activeId) {
        studentDB.setActiveStudentId(current.id);
      }
    };
    refresh();
    const unsub = studentDB.subscribe(refresh);
    return () => unsub();
  }, []);

  const handleNextTurn = () => {
    const next = studentDB.getNextStudentTurn(activeStudent?.id);
    if (next) {
      studentDB.setActiveStudentId(next.id);
      setActiveStudent(next);
      soundEngine.playPop(550);
      const cheer = next.gender === 'boy'
        ? `حان دور البطل ${next.name}! ${next.characterTitle}!`
        : `حان دور البطلة ${next.name}! ${next.characterTitle}!`;
      soundEngine.speakArabic(cheer);
    }
  };

  const handleRandomTurn = () => {
    const present = students.filter(s => s.isPresent);
    if (present.length === 0) return;

    setIsPickingTurn(true);
    let count = 0;
    const interval = setInterval(() => {
      count++;
      const rand = present[Math.floor(Math.random() * present.length)];
      setActiveStudent(rand);
      soundEngine.playPop(380 + (count % 4) * 50);

      if (count >= 10) {
        clearInterval(interval);
        const finalPick = present[Math.floor(Math.random() * present.length)];
        setActiveStudent(finalPick);
        studentDB.setActiveStudentId(finalPick.id);
        setIsPickingTurn(false);
        soundEngine.playSuccess();
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 }
        });
        const cheer = finalPick.gender === 'boy'
          ? `القرعة اختارت البطل ${finalPick.name}! ${finalPick.characterTitle}!`
          : `القرعة اختارت البطلة ${finalPick.name}! ${finalPick.characterTitle}!`;
        soundEngine.speakArabic(cheer);
      }
    }, 110);
  };

  // Wheel of Fortune State
  const [wheelSpinning, setWheelSpinning] = useState(false);
  const [wheelDegree, setWheelDegree] = useState(0);
  const [wheelQuestion, setWheelQuestion] = useState<{
    topic: string;
    question: string;
    options: { text: string; isCorrect: boolean }[];
  } | null>(null);
  const [wheelAnswered, setWheelAnswered] = useState<boolean | null>(null);

  // Word Builder State (e.g. build بَاب or كِتَاب)
  const [wordTarget, setWordTarget] = useState({ word: 'بَاب', letters: ['بـ', 'ا', 'ب'], meaning: 'باب' });
  const [wordPickedLetters, setWordPickedLetters] = useState<string[]>([]);
  const [wordLetterPool, setWordLetterPool] = useState(['بـ', 'ا', 'ب', 'ت', 'س']);

  // Number Sort State (Order numbers ascending)
  const [unsortedNumbers, setUnsortedNumbers] = useState([14, 5, 29, 8, 42]);
  const [sortedSlots, setSortedSlots] = useState<number[]>([]);

  // Animal Sort State (ولودة vs بيوضة)
  const [animalsPool, setAnimalsPool] = useState([
    { name: 'بَقَرَة', emoji: '🐄', type: 'mammal' },
    { name: 'دَجَاجَة', emoji: '🐔', type: 'bird' },
    { name: 'خَرُوف', emoji: '🐑', type: 'mammal' },
    { name: 'بَطَّة', emoji: '🦆', type: 'bird' },
    { name: 'أَرْنَب', emoji: '🐇', type: 'mammal' },
    { name: 'عُصْفُور', emoji: '🐦', type: 'bird' }
  ]);
  const [mammalsList, setMammalsList] = useState<{ name: string; emoji: string }[]>([]);
  const [birdsList, setBirdsList] = useState<{ name: string; emoji: string }[]>([]);

  // Memory cards state
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matchedPairs, setMatchedPairs] = useState<number[]>([]);
  const memoryCards = [
    { id: 1, char: 'ب', matchId: 101 },
    { id: 2, char: 'ت', matchId: 102 },
    { id: 3, char: '🚪', matchId: 101 },
    { id: 4, char: '🍎', matchId: 102 },
    { id: 5, char: 'م', matchId: 103 },
    { id: 6, char: '🍌', matchId: 103 }
  ];

  // Whack letter state
  const [whackTarget, setWhackTarget] = useState('ب');
  const [whackLetters, setWhackLetters] = useState(['ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'ب', 'د', 'ب']);

  const speak = (text: string) => {
    soundEngine.playPop(520);
    soundEngine.speakArabic(text);
  };

  const triggerReward = () => {
    soundEngine.playSuccess();
    onEarnStar();
    setRoundScore(s => s + 1);
    if (activeStudent) {
      studentDB.addStars(activeStudent.id, 1);
      studentDB.recordGameRound(activeStudent.id);
      const cheer = activeStudent.gender === 'boy'
        ? `أَحْسَنْتَ يَا بَطَل ${activeStudent.name}! نَجْمَةٌ ذَهَبِيَّةٌ لَكَ!`
        : `أَحْسَنْتِ يَا بَطَلَة ${activeStudent.name}! نَجْمَةٌ ذَهَبِيَّةٌ لَكِ!`;
      setTimeout(() => {
        soundEngine.speakArabic(cheer);
      }, 400);
    }
    confetti({
      particleCount: 55,
      spread: 65,
      origin: { y: 0.7 }
    });
  };

  // Wheel Spin Logic
  const spinWheel = () => {
    if (wheelSpinning) return;
    setWheelSpinning(true);
    setWheelAnswered(null);
    soundEngine.playPop(440);

    const extraDeg = 720 + Math.floor(Math.random() * 360);
    const newDeg = wheelDegree + extraDeg;
    setWheelDegree(newDeg);

    setTimeout(() => {
      setWheelSpinning(false);
      const questions = [
        {
          topic: 'الحروف واللغة',
          question: 'ما هي الكلمة التي تبدأ بحرف الباء؟',
          options: [
            { text: 'بَقَرَة 🐄', isCorrect: true },
            { text: 'شَمْس ☀️', isCorrect: false },
            { text: 'تُفَّاحَة 🍎', isCorrect: false }
          ]
        },
        {
          topic: 'الأعداد والحساب',
          question: 'ما هو حاصل جمع 3 + 2؟',
          options: [
            { text: '4', isCorrect: false },
            { text: '5 ⭐', isCorrect: true },
            { text: '6', isCorrect: false }
          ]
        },
        {
          topic: 'التربية الإسلامية',
          question: 'كم عدد الصلوات المفروضة في اليوم؟',
          options: [
            { text: 'ثلاث صلوات', isCorrect: false },
            { text: 'خمس صلوات 🕌', isCorrect: true },
            { text: 'صلاتان', isCorrect: false }
          ]
        },
        {
          topic: 'النشاط العلمي',
          question: 'ما هو الشيء الذي يطفو فوق سطح الماء؟',
          options: [
            { text: 'حجر ثقيل 🪨', isCorrect: false },
            { text: 'قطعة خشب 🪵', isCorrect: true },
            { text: 'مسمار حديد 🔩', isCorrect: false }
          ]
        }
      ];
      const q = questions[Math.floor(Math.random() * questions.length)];
      setWheelQuestion(q);
      speak(`${q.topic}.. ${q.question}`);
    }, 2200);
  };

  return (
    <div className="space-y-6">
      {/* Turn-Based Classroom Gaming Bar for Miss Manar */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 rounded-3xl p-5 text-white shadow-lg border border-amber-300 relative overflow-hidden select-none">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Active Pupil Profile */}
          <div className="flex items-center gap-3.5">
            <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-md border-2 border-white/40 flex items-center justify-center text-4xl shadow-inner animate-pulse">
              {activeStudent?.characterEmoji || '⭐'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-white/20 px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider text-amber-100">
                  🎯 دور التلميذ الحالي
                </span>
                {activeStudent && (
                  <span className="text-xs bg-black/20 px-2 py-0.5 rounded-full">
                    {activeStudent.characterTitle}
                  </span>
                )}
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white mt-0.5">
                {activeStudent ? activeStudent.name : 'لم يتم اختيار تلميذ'}
              </h2>
            </div>
          </div>

          {/* Turn Controls & Pupil Switcher */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Student's Personal Stars */}
            {activeStudent && (
              <div className="bg-white/20 backdrop-blur-md px-3.5 py-2 rounded-2xl border border-white/30 flex items-center gap-1.5 text-sm font-bold text-amber-100">
                <span>⭐ نجوم التلميذ:</span>
                <span className="font-mono text-base font-black text-white">{activeStudent.stars}</span>
              </div>
            )}

            {/* Next Student Button */}
            <button
              onClick={handleNextTurn}
              className="px-4 py-2.5 bg-white text-rose-600 hover:bg-rose-50 rounded-2xl font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer"
              title="تمرير الدور للتلميذ التالي في القسم"
            >
              <span>التالي بالدور</span>
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Random Raffle Picker */}
            <button
              onClick={handleRandomTurn}
              disabled={isPickingTurn}
              className="px-3.5 py-2.5 bg-amber-400 hover:bg-amber-300 text-amber-950 rounded-2xl font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
              title="قرعة عشوائية لاختيار التلميذ"
            >
              <Dices className="w-4 h-4" />
              <span>قرعة 🎲</span>
            </button>

            {/* Speak cheer for active student */}
            {activeStudent && (
              <button
                onClick={() => {
                  soundEngine.playPop(500);
                  const cheer = activeStudent.gender === 'boy'
                    ? `يلا يا بطل ${activeStudent.name}! ركز وأجب عن السؤال!`
                    : `يلا يا بطلة ${activeStudent.name}! ركزي وأجيبي عن السؤال!`;
                  soundEngine.speakArabic(cheer);
                }}
                className="p-2.5 bg-white/20 hover:bg-white/30 rounded-2xl text-white transition-transform active:scale-95"
                title="تشجيع التلميذ بصوت المعلمة"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Quick Pupils Ribbon */}
        {students.length > 0 && (
          <div className="mt-4 pt-3 border-t border-white/20 flex items-center gap-2 overflow-x-auto scrollbar-none">
            <span className="text-xs text-white/80 font-bold whitespace-nowrap pl-1">
              تبديل سريع:
            </span>
            {students.filter(s => s.isPresent).map(s => (
              <button
                key={s.id}
                onClick={() => {
                  studentDB.setActiveStudentId(s.id);
                  setActiveStudent(s);
                  soundEngine.playPop(520);
                }}
                className={`px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition-all ${
                  activeStudent?.id === s.id
                    ? 'bg-white text-rose-600 shadow-md font-black scale-105'
                    : 'bg-white/15 hover:bg-white/25 text-white'
                }`}
              >
                <span>{s.characterEmoji}</span>
                <span>{s.name}</span>
                <span className="text-[10px] opacity-75 font-mono">({s.stars}⭐)</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <span className="text-3xl">🎮</span>
              <span>بَنْكُ الأَلْعَابِ الحَقِيقِيَّةِ مَعَ الآنسة منار</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              ألعاب تثبيت حقيقية: عجلة الحظ، تركيب الكلمات، ترتيب الأعداد، وتصنيف الكائنات الحية بالدور بين التلاميذ.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-700 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200">
              رصيد نجوم الجولة: {roundScore} ⭐
            </span>
          </div>
        </div>

        {/* Real Games Navigation Ribbon */}
        <div className="pt-4 flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {[
            { id: 'spin_wheel', label: '1. عجلة الحظ مع الآنسة منار', icon: '🎡' },
            { id: 'word_builder', label: '2. تركيب الكلمة من الحروف', icon: '🧩' },
            { id: 'number_sort', label: '3. ترتيب الأعداد تصاعدياً', icon: '🔢' },
            { id: 'animal_sort', label: '4. تصنيف الحيوانات (ولودة / بيوضة)', icon: '🦁' },
            { id: 'whack_letter', label: '5. صيد الحرف المتحرك', icon: '🎯' },
            { id: 'memory', label: '6. بطاقات الذاكرة', icon: '🃏' }
          ].map(g => (
            <button
              key={g.id}
              onClick={() => {
                soundEngine.playPop(480);
                setSelectedGame(g.id as RealGameType);
              }}
              className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap border-2 transition-all flex items-center gap-2 ${
                selectedGame === g.id
                  ? 'bg-purple-50 border-purple-500 text-purple-800 shadow-xs'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span>{g.icon}</span>
              <span>{g.label}</span>
            </button>
          ))}
        </div>

        {/* Game Arena Container */}
        <div className="pt-6">
          {/* Game 1: Wheel of Fortune with Miss Manar */}
          {selectedGame === 'spin_wheel' && (
            <div className="max-w-xl mx-auto text-center space-y-6">
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-sm font-bold text-amber-900">
                🎡 أدر عجلة الحظ بالضغط على الزر، وأجب عن السؤال الممتع مع زملائك في القسم!
              </div>

              {/* Graphic Wheel */}
              <div className="relative w-56 h-56 mx-auto flex items-center justify-center">
                {/* Pointer indicator */}
                <div className="absolute -top-3 z-20 text-3xl">🔻</div>

                <div
                  style={{
                    transform: `rotate(${wheelDegree}deg)`,
                    transition: wheelSpinning ? 'transform 2.2s cubic-bezier(0.17, 0.67, 0.12, 0.99)' : 'none'
                  }}
                  className="w-52 h-52 rounded-full border-8 border-white shadow-xl bg-gradient-to-tr from-rose-400 via-amber-400 to-indigo-500 flex items-center justify-center relative overflow-hidden"
                >
                  <div className="w-16 h-16 rounded-full bg-white shadow-md border-4 border-slate-100 flex items-center justify-center font-bold text-2xl">
                    ⭐
                  </div>
                </div>
              </div>

              <button
                onClick={spinWheel}
                disabled={wheelSpinning}
                className="px-8 py-3.5 bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white font-extrabold rounded-2xl shadow-md btn-3d text-sm"
              >
                {wheelSpinning ? 'العجلة تدور...' : 'دَوِّرِ العَجَلَةَ الآن! 🎡'}
              </button>

              {/* Pop-up Question from Wheel */}
              {wheelQuestion && (
                <div className="p-6 bg-purple-50 rounded-3xl border-2 border-purple-200 space-y-4 animate-bounce-slow text-right">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 bg-purple-600 text-white text-xs font-bold rounded-xl">
                      {wheelQuestion.topic}
                    </span>
                    <button
                      onClick={() => speak(wheelQuestion.question)}
                      className="text-xs text-purple-700 font-bold inline-flex items-center gap-1"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span>استمع</span>
                    </button>
                  </div>

                  <h4 className="text-xl font-extrabold text-slate-800 font-['Tajawal',sans-serif]">
                    {wheelQuestion.question}
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                    {wheelQuestion.options.map((opt, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          if (opt.isCorrect) {
                            setWheelAnswered(true);
                            triggerReward();
                            setRoundScore(s => s + 1);
                            speak('إجابة رائعة وصحيحة! أحسنت!');
                          } else {
                            setWheelAnswered(false);
                            soundEngine.playGentleBoing();
                            speak('حاول مرة أخرى!');
                          }
                        }}
                        className="p-3 bg-white hover:bg-purple-100/60 rounded-2xl border border-purple-200 text-slate-800 font-bold text-sm card-3d text-center"
                      >
                        {opt.text}
                      </button>
                    ))}
                  </div>

                  {wheelAnswered === true && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-center text-emerald-800 font-bold text-xs">
                      🎉 أحسنت يا بطل! كسبت نقطة ونجمة جديدة مع الآنسة منار!
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Game 2: Word Builder (تركيب الكلمة) */}
          {selectedGame === 'word_builder' && (
            <div className="max-w-xl mx-auto text-center space-y-6">
              <div className="p-3 bg-teal-50 rounded-2xl border border-teal-200 text-sm font-bold text-teal-900">
                🧩 رتّب الحروف لتكوين كلمة: ({wordTarget.word}) 🚪
              </div>

              {/* Slot Target */}
              <div className="p-6 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-300 flex items-center justify-center gap-3 min-h-[90px]">
                {wordTarget.letters.map((_, i) => (
                  <div
                    key={i}
                    className="w-16 h-16 rounded-2xl bg-white border-2 border-slate-300 flex items-center justify-center font-['Tajawal',sans-serif] text-3xl font-extrabold text-teal-700 shadow-sm"
                  >
                    {wordPickedLetters[i] || '؟'}
                  </div>
                ))}
              </div>

              {/* Letter Pool to Pick */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-500">اختر الحروف بالترتيب الصحيح:</span>
                <div className="flex items-center justify-center gap-3">
                  {wordLetterPool.map((letter, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        soundEngine.playPop(480);
                        const next = [...wordPickedLetters, letter];
                        setWordPickedLetters(next);

                        if (next.length === wordTarget.letters.length) {
                          if (next.join('') === wordTarget.letters.join('')) {
                            triggerReward();
                            setRoundScore(s => s + 1);
                            speak(`ممتاز! كونت كلمة ${wordTarget.word}!`);
                          } else {
                            soundEngine.playGentleBoing();
                            speak('ترتيب الحروف غير صحيح، اضغط إعادة المحاولة!');
                          }
                        }
                      }}
                      className="w-14 h-14 rounded-2xl bg-white hover:bg-teal-50 border-2 border-slate-200 hover:border-teal-400 font-['Tajawal',sans-serif] text-2xl font-extrabold text-slate-800 card-3d flex items-center justify-center"
                    >
                      {letter}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => {
                    setWordPickedLetters([]);
                    soundEngine.playPop(400);
                  }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>إعادة المحاولة</span>
                </button>
              </div>
            </div>
          )}

          {/* Game 3: Number Ascending Order (ترتيب الأرقام) */}
          {selectedGame === 'number_sort' && (
            <div className="max-w-xl mx-auto text-center space-y-6">
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-sm font-bold text-amber-900">
                🔢 رتّب هذه الأرقام تصاعدياً من الأصغر إلى الأكبر!
              </div>

              {/* Sorted Slots */}
              <div className="p-5 bg-slate-50 rounded-3xl border-2 border-slate-200 flex items-center justify-center gap-3 min-h-[80px]">
                {sortedSlots.length === 0 ? (
                  <span className="text-xs text-slate-400 font-bold">(اضغط على الرقم الأصغر لوضعه هنا أولاً)</span>
                ) : (
                  sortedSlots.map((n, i) => (
                    <div key={i} className="w-14 h-14 rounded-2xl bg-amber-500 text-white font-mono font-extrabold text-2xl flex items-center justify-center shadow-md animate-bounce-slow">
                      {n}
                    </div>
                  ))
                )}
              </div>

              {/* Unsorted Numbers to Pick */}
              <div className="flex items-center justify-center gap-3">
                {unsortedNumbers.map((num, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      // Check if num is indeed the minimum in unsortedNumbers
                      const minVal = Math.min(...unsortedNumbers);
                      if (num === minVal) {
                        soundEngine.playPop(520);
                        setSortedSlots(prev => [...prev, num]);
                        const remaining = unsortedNumbers.filter((_, i) => i !== idx);
                        setUnsortedNumbers(remaining);

                        if (remaining.length === 0) {
                          triggerReward();
                          setRoundScore(s => s + 1);
                          speak('أحسنت يا بطل! رتبت جميع الأرقام تصاعدياً بنجاح!');
                        }
                      } else {
                        soundEngine.playGentleBoing();
                        speak('هذا ليس الرقم الأصغر، فكر جيداً!');
                      }
                    }}
                    className="w-16 h-16 rounded-2xl bg-white hover:bg-amber-100 border-2 border-slate-200 hover:border-amber-400 font-mono font-extrabold text-2xl text-slate-800 card-3d flex items-center justify-center"
                  >
                    {num}
                  </button>
                ))}
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => {
                    setUnsortedNumbers([14, 5, 29, 8, 42]);
                    setSortedSlots([]);
                    soundEngine.playPop(400);
                  }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>إعادة اللعبة</span>
                </button>
              </div>
            </div>
          )}

          {/* Game 4: Animal Sort (ولودة vs بيوضة) */}
          {selectedGame === 'animal_sort' && (
            <div className="max-w-2xl mx-auto text-center space-y-6">
              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-sm font-bold text-emerald-900">
                🦁 صَنِّفْ هَذِهِ الحَيَوَانَات: هَلْ هِيَ وَلُودَة (تلد) أَمْ بَيُوضَة (تبيض)؟
              </div>

              {/* Two Baskets */}
              <div className="grid grid-cols-2 gap-4">
                {/* Mammals (ولودة) */}
                <div className="p-5 bg-amber-50 rounded-3xl border-2 border-amber-300 space-y-2 min-h-[140px]">
                  <span className="text-xs font-bold text-amber-900 block">حَيَوَانَاتٌ وَلُودَة (تَلِد) 🐄</span>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    {mammalsList.map((m, i) => (
                      <span key={i} className="text-3xl p-1 bg-white rounded-xl shadow-xs" title={m.name}>
                        {m.emoji}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Birds (بيوضة) */}
                <div className="p-5 bg-sky-50 rounded-3xl border-2 border-sky-300 space-y-2 min-h-[140px]">
                  <span className="text-xs font-bold text-sky-900 block">حَيَوَانَاتٌ بَيُوضَة (تَبِيض) 🥚</span>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    {birdsList.map((b, i) => (
                      <span key={i} className="text-3xl p-1 bg-white rounded-xl shadow-xs" title={b.name}>
                        {b.emoji}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Animal Pool to Classify */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-500">اضغط على الحيوان ثم اختر تصنيفه:</span>
                <div className="flex flex-wrap items-center justify-center gap-3">
                  {animalsPool.map((an, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        soundEngine.playPop(480);
                        if (an.type === 'mammal') {
                          setMammalsList(prev => [...prev, an]);
                          speak(`${an.name}.. حيوان ولود يلد صغاره ويرضعهم!`);
                        } else {
                          setBirdsList(prev => [...prev, an]);
                          speak(`${an.name}.. حيوان بيوض يضع البيض!`);
                        }
                        const rest = animalsPool.filter((_, i) => i !== idx);
                        setAnimalsPool(rest);

                        if (rest.length === 0) {
                          triggerReward();
                          setRoundScore(s => s + 1);
                        }
                      }}
                      className="p-3 bg-white hover:bg-slate-50 rounded-2xl border-2 border-slate-200 card-3d flex items-center gap-2"
                    >
                      <span className="text-3xl">{an.emoji}</span>
                      <span className="text-xs font-bold text-slate-800">{an.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {animalsPool.length === 0 && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 font-bold text-xs animate-bounce-slow">
                  🎉 رائع جداً! صنفت جميع الحيوانات بدقة وتميز!
                </div>
              )}
            </div>
          )}

          {/* Game 5: Whack a letter */}
          {selectedGame === 'whack_letter' && (
            <div className="max-w-xl mx-auto text-center space-y-6">
              <div className="p-3 bg-rose-50 rounded-2xl border border-rose-200 text-sm font-bold text-rose-900">
                🎯 اصطد حرف ({whackTarget}) بالضغط عليه بسرعة قبل اختفائه!
              </div>

              <div className="grid grid-cols-3 gap-4">
                {whackLetters.map((char, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      if (char === whackTarget) {
                        soundEngine.playPop(600);
                        triggerReward();
                        const next = [...whackLetters];
                        next[idx] = ['ت', 'ث', 'ج', 'ح'][Math.floor(Math.random() * 4)];
                        setWhackLetters(next);
                      } else {
                        soundEngine.playGentleBoing();
                      }
                    }}
                    className={`h-24 rounded-3xl font-extrabold text-5xl flex items-center justify-center transition-all card-3d ${
                      char === whackTarget
                        ? 'bg-rose-500 text-white border-rose-600 scale-102'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    {char}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Game 6: Memory Cards */}
          {selectedGame === 'memory' && (
            <div className="max-w-xl mx-auto text-center space-y-6">
              <div className="p-3 bg-indigo-50 rounded-2xl border border-indigo-200 text-sm font-bold text-indigo-900">
                🃏 اقلب بطاقتين للبحث عن الحرف والصورة التي تبدأ به!
              </div>

              <div className="grid grid-cols-3 gap-4">
                {memoryCards.map((card, idx) => {
                  const isFlipped = flippedCards.includes(idx) || matchedPairs.includes(idx);
                  return (
                    <button
                      key={card.id}
                      onClick={() => {
                        if (flippedCards.length === 2 || flippedCards.includes(idx) || matchedPairs.includes(idx)) return;
                        soundEngine.playPop(440);
                        const newFlipped = [...flippedCards, idx];
                        setFlippedCards(newFlipped);

                        if (newFlipped.length === 2) {
                          const card1 = memoryCards[newFlipped[0]];
                          const card2 = memoryCards[newFlipped[1]];
                          if (card1.matchId === card2.matchId) {
                            setTimeout(() => {
                              setMatchedPairs(prev => [...prev, newFlipped[0], newFlipped[1]]);
                              setFlippedCards([]);
                              triggerReward();
                            }, 500);
                          } else {
                            setTimeout(() => {
                              setFlippedCards([]);
                              soundEngine.playGentleBoing();
                            }, 1000);
                          }
                        }
                      }}
                      className={`h-28 rounded-3xl text-5xl font-extrabold border-2 transition-all card-3d flex items-center justify-center ${
                        isFlipped
                          ? 'bg-white border-indigo-400 text-indigo-600 shadow-sm'
                          : 'bg-gradient-to-tr from-indigo-500 to-purple-600 border-indigo-600 text-white'
                      }`}
                    >
                      {isFlipped ? card.char : '❓'}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
