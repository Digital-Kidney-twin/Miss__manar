import React from 'react';
import { 
  ArrowLeft, 
  Home, 
  Sparkles, 
  BookOpen, 
  Volume2 
} from 'lucide-react';
import { ActiveModule } from './TeacherNavbar';
import { soundEngine } from '../utils/audio';

import alphabetImg from '../assets/images/alphabet_arabic_3d_1790362259078.jpg';
import numbersImg from '../assets/images/numbers_math_3d_1790362269431.jpg';
import worldImg from '../assets/images/world_discovery_3d_1790362280277.jpg';

interface LessonsCatalogViewProps {
  onNavigate: (module: ActiveModule) => void;
}

export const LessonsCatalogView: React.FC<LessonsCatalogViewProps> = ({ onNavigate }) => {
  const modules = [
    {
      id: 'letters',
      title: 'الحروف واللغة العربية',
      subtitle: 'الحروف الهجائية، الحركات القصيرة والطويلة، التنوين، وأشكال الحرف في الكلمة',
      emoji: '🔤',
      img: alphabetImg,
      bgGradient: 'from-rose-500 to-pink-500',
      borderTone: 'border-rose-200 hover:border-rose-400',
      accentColor: 'bg-rose-50 text-rose-700',
      moduleTarget: 'letters' as ActiveModule,
      tag: 'قراءة ونطق'
    },
    {
      id: 'numbers',
      title: 'الأعداد والرياضيات (1 إلى 100)',
      subtitle: 'جميع الأعداد من 1 إلى 100 مكتوبة بالحروف • الوحدات على اليمين والعشرات على اليسار دائماً',
      emoji: '🔢',
      img: numbersImg,
      bgGradient: 'from-amber-500 to-yellow-500',
      borderTone: 'border-amber-200 hover:border-amber-400',
      accentColor: 'bg-amber-50 text-amber-700',
      moduleTarget: 'numbers' as ActiveModule,
      tag: 'حساب وأعداد'
    },
    {
      id: 'islamic',
      title: 'التربية الإسلامية وقصار السور',
      subtitle: 'أركان الإسلام، الصلوات الخمس ومواقيتها، خطوات الوضوء الصحيحة، والآداب اليومية',
      emoji: '🕌',
      bgGradient: 'from-emerald-500 to-teal-600',
      borderTone: 'border-emerald-200 hover:border-emerald-400',
      accentColor: 'bg-emerald-50 text-emerald-700',
      moduleTarget: 'islamic' as ActiveModule,
      tag: 'قيم وإيمان'
    },
    {
      id: 'science',
      title: 'الإيقاظ العلمي والتجارب',
      subtitle: 'يطفو أم يغرق، دورة حياة النبات، حالات المادة (الماء)، وقوة المغناطيس العجيب',
      emoji: '🔬',
      bgGradient: 'from-sky-500 to-cyan-600',
      borderTone: 'border-sky-200 hover:border-sky-400',
      accentColor: 'bg-sky-50 text-sky-700',
      moduleTarget: 'science' as ActiveModule,
      tag: 'تجارب واكتشاف'
    },
    {
      id: 'writing',
      title: 'الكتابة والخط والمسارات',
      subtitle: 'مسك القلم السليم، تتبع الخطوط والمسارات المنحنية، والسبورة الحرة للرسم',
      emoji: '✏️',
      bgGradient: 'from-teal-500 to-emerald-500',
      borderTone: 'border-teal-200 hover:border-teal-400',
      accentColor: 'bg-teal-50 text-teal-700',
      moduleTarget: 'writing' as ActiveModule,
      tag: 'تخطيط وتدريب'
    },
    {
      id: 'colors_shapes',
      title: 'الألوان والأشكال الهندسية',
      subtitle: '10 ألوان بهيجة و6 أشكال هندسية مع الخصائص وأمثلة من واقع الطفل اليومي',
      emoji: '🎨',
      bgGradient: 'from-indigo-500 to-blue-500',
      borderTone: 'border-indigo-200 hover:border-indigo-400',
      accentColor: 'bg-indigo-50 text-indigo-700',
      moduleTarget: 'colors_shapes' as ActiveModule,
      tag: 'تميز بصري'
    },
    {
      id: 'world',
      title: 'اكتشف العالم وأنا وجسمي',
      subtitle: 'الحواس الخمس، أصوات الحيوانات، فصول السنة الأربعة، والغذاء الصحي المتوازن',
      emoji: '🌱',
      img: worldImg,
      bgGradient: 'from-emerald-500 to-green-600',
      borderTone: 'border-emerald-200 hover:border-emerald-400',
      accentColor: 'bg-emerald-50 text-emerald-700',
      moduleTarget: 'world' as ActiveModule,
      tag: 'جسمي والبيئة'
    },
    {
      id: 'games',
      title: 'بنك الألعاب والتثبيت التفاعلي',
      subtitle: 'عجلة الحظ الدوارة مع الآنسة منار، تركيب الكلمات، وترتيب الأعداد التنازلي والتصاعدي',
      emoji: '🎮',
      bgGradient: 'from-purple-500 to-violet-600',
      borderTone: 'border-purple-200 hover:border-purple-400',
      accentColor: 'bg-purple-50 text-purple-700',
      moduleTarget: 'games' as ActiveModule,
      tag: 'ألعاب تعليمية'
    },
    {
      id: 'songs',
      title: 'الأناشيد التعليمية الهادفة',
      subtitle: 'أناشيد الحروف والأعداد والترحيب بكلمات واضحة وتظليل تفاعلي للإنشاد مع الأطفال',
      emoji: '🎵',
      bgGradient: 'from-pink-500 to-rose-400',
      borderTone: 'border-pink-200 hover:border-pink-400',
      accentColor: 'bg-pink-50 text-pink-700',
      moduleTarget: 'songs' as ActiveModule,
      tag: 'إيقاع وإنشاد'
    },
    {
      id: 'assessment',
      title: 'التقييم الشامل وشهادة التقدير',
      subtitle: 'اختبار ختامي شامل ممتع، مع شهادة تفوق وتكريم باسم التلميذ موقعة من الآنسة منار',
      emoji: '⭐',
      bgGradient: 'from-amber-400 to-orange-500',
      borderTone: 'border-amber-200 hover:border-amber-400',
      accentColor: 'bg-amber-50 text-amber-700',
      moduleTarget: 'assessment' as ActiveModule,
      tag: 'شهادة تفوق'
    }
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header bar for lessons portal */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-rose-100 text-rose-700 font-bold text-xs rounded-xl flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5" />
              <span>فِهْرِسُ الدُّرُوسِ وَالْوَحَدَاتِ</span>
            </span>
            <span className="text-xs text-slate-400">قسم الآنسة منار • دار المعرفة</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-800 font-['Tajawal',sans-serif]">
            اخْتَرْ الدَّرْسَ أَوِ النَّشَاطَ التَّفَاعُلِيّ
          </h2>
          <p className="text-sm text-slate-500 font-medium">
            دروس تفاعلية صوتية مصممة خصيصاً للشرح على شاشة الـ Data Show لصفوف التحضيري والسنة الأولى
          </p>
        </div>

        <div className="flex items-center gap-3 self-start md:self-center">
          <button
            onClick={() => {
              soundEngine.playPop(420);
              onNavigate('home');
            }}
            className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-bold text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer active:scale-95"
          >
            <Home className="w-4 h-4" />
            <span>شاشة الترحيب الرئيسية</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playPop(520);
              soundEngine.speakArabic('أهلاً بكم في فهرس الدروس والأنشطة في قسم الآنسة منار!');
            }}
            className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl transition-all cursor-pointer"
            title="نطق ترحيبي"
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Featured Classroom Pupils Database & Turn Management Banner */}
      <div 
        onClick={() => {
          soundEngine.playPop(450);
          onNavigate('students');
        }}
        className="bg-gradient-to-r from-amber-500 via-rose-500 to-pink-500 rounded-3xl p-6 sm:p-7 text-white shadow-lg cursor-pointer transition-all hover:shadow-xl hover:scale-[1.01] active:scale-[0.99] border-2 border-amber-300 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6"
      >
        <div className="space-y-2 relative z-10">
          <div className="inline-flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full text-xs font-black uppercase">
            <span>⭐ جديد • قاعدة البيانات الدائمة</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-black leading-tight">
            🎒 قائمة أبطال وتلاميذ قسم الآنسة منار
          </h3>
          <p className="text-sm text-white/90 max-w-xl">
            أضيفي تلاميذكِ الجدد، خصصي لكل تلميذ شخصية كرتونية ورسمة محببة، نظمي الأدوار في الألعاب، وتابعي النجوم المحققة بدقة.
          </p>
        </div>

        <div className="flex items-center gap-3 relative z-10">
          <button
            onClick={(e) => {
              e.stopPropagation();
              soundEngine.playPop(450);
              onNavigate('students');
            }}
            className="px-6 py-3.5 bg-white text-rose-600 hover:bg-rose-50 rounded-2xl font-black text-sm shadow-md transition-transform active:scale-95 flex items-center gap-2"
          >
            <span>فتح قائمة التلاميذ</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grid of Lesson Modules */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {modules.map((m) => (
          <div
            key={m.id}
            onClick={() => {
              soundEngine.playPop(480);
              onNavigate(m.moduleTarget);
            }}
            className={`p-6 bg-white rounded-3xl border-2 ${m.borderTone} shadow-sm hover:shadow-xl transition-all cursor-pointer card-3d flex flex-col justify-between group relative overflow-hidden`}
          >
            {m.img && (
              <div className="w-full h-36 rounded-2xl overflow-hidden mb-4 border border-slate-100 shadow-inner">
                <img
                  src={m.img}
                  alt={m.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
            )}

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-4xl group-hover:scale-110 transition-transform">
                  {m.emoji}
                </span>
                <span className={`text-xs font-bold px-3 py-1 rounded-xl ${m.accentColor}`}>
                  {m.tag}
                </span>
              </div>

              <h3 className="text-xl font-extrabold text-slate-800 group-hover:text-rose-600 transition-colors font-['Tajawal',sans-serif]">
                {m.title}
              </h3>

              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                {m.subtitle}
              </p>
            </div>

            <div className="pt-5 mt-4 flex items-center justify-between border-t border-slate-100">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1 group-hover:text-rose-600">
                <span>دخول الوحدة الكاملة</span>
                <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
              </span>
              <span className="text-xs text-slate-400">شرح • تفاعل • صوت</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
