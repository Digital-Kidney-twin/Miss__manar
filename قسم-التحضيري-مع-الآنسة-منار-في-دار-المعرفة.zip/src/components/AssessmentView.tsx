import React, { useState } from 'react';
import { 
  Trophy, 
  Award, 
  CheckCircle2, 
  RotateCcw, 
  Volume2, 
  Sparkles,
  Printer,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

interface AssessmentViewProps {
  starsCount: number;
  onEarnStar: () => void;
}

interface Question {
  id: number;
  section: 'حروف' | 'أرقام' | 'إسلامية' | 'علمية';
  title: string;
  prompt: string;
  options: { label: string; isCorrect: boolean; display: string }[];
}

const ASSESSMENT_QUESTIONS: Question[] = [
  {
    id: 1,
    section: 'حروف',
    title: 'تَمْيِيزُ الحَرْف',
    prompt: 'أَيْنَ هُوَ حَرْفُ البَاء (ب)؟',
    options: [
      { label: 'أ', isCorrect: false, display: 'أ' },
      { label: 'ب', isCorrect: true, display: 'ب' },
      { label: 'ت', isCorrect: false, display: 'ت' }
    ]
  },
  {
    id: 2,
    section: 'حروف',
    title: 'تَمْيِيزُ الحَرَكَة',
    prompt: 'أَيْنَ صَوْتُ (بُ) مَعَ الضَّمَّة؟',
    options: [
      { label: 'بَ', isCorrect: false, display: 'بَ' },
      { label: 'بُ', isCorrect: true, display: 'بُ' },
      { label: 'بِ', isCorrect: false, display: 'بِ' }
    ]
  },
  {
    id: 3,
    section: 'حروف',
    title: 'تَمْيِيزُ حَرْفِ المَدّ',
    prompt: 'أَيْنَ مَدُّ الأَلِف (بَا)؟',
    options: [
      { label: 'بَا', isCorrect: true, display: 'بَا' },
      { label: 'بُو', isCorrect: false, display: 'بُو' },
      { label: 'بِي', isCorrect: false, display: 'بِي' }
    ]
  },
  {
    id: 4,
    section: 'أرقام',
    title: 'تَمْيِيزُ الرَّقْم',
    prompt: 'أَيْنَ هُوَ الرَّقْمُ 3 (ثَلَاثَة)؟',
    options: [
      { label: '2', isCorrect: false, display: '2' },
      { label: '3', isCorrect: true, display: '3' },
      { label: '4', isCorrect: false, display: '4' }
    ]
  },
  {
    id: 5,
    section: 'أرقام',
    title: 'عَدُّ الأَشْيَاء',
    prompt: 'كَمْ تُفَّاحَةً تَرَى: 🍎 🍎 🍎؟',
    options: [
      { label: '2', isCorrect: false, display: '2' },
      { label: '3', isCorrect: true, display: '3' },
      { label: '5', isCorrect: false, display: '5' }
    ]
  },
  {
    id: 6,
    section: 'إسلامية',
    title: 'أَرْكَانُ الإِسْلَام',
    prompt: 'كَمْ عَدَدُ أَرْكَانِ الإِسْلَام؟',
    options: [
      { label: '3', isCorrect: false, display: '3 أركان' },
      { label: '5', isCorrect: true, display: '5 أركان 🕌' },
      { label: '7', isCorrect: false, display: '7 أركان' }
    ]
  },
  {
    id: 7,
    section: 'علمية',
    title: 'الإِيقَاظُ العِلْمِي',
    prompt: 'مَا هُوَ الشَّيْءُ الَّذِي يَطْفُو فَوْقَ المَاء؟',
    options: [
      { label: 'خشب', isCorrect: true, display: 'قِطْعَةُ خَشَب 🪵' },
      { label: 'حجر', isCorrect: false, display: 'حَجَرٌ ثَقِيل 🪨' },
      { label: 'مسمار', isCorrect: false, display: 'مِسْمَارُ حَدِيد 🔩' }
    ]
  }
];

export const AssessmentView: React.FC<AssessmentViewProps> = ({ starsCount, onEarnStar }) => {
  const [currentQIdx, setCurrentQIdx] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, boolean>>({});
  const [isCompleted, setIsCompleted] = useState(false);
  const [studentName, setStudentName] = useState('البطل الصغير');
  const [showCertificate, setShowCertificate] = useState(false);

  const currentQ = ASSESSMENT_QUESTIONS[currentQIdx];

  const handleSelectOption = (isCorrect: boolean) => {
    soundEngine.playPop(480);
    const updated = { ...userAnswers, [currentQ.id]: isCorrect };
    setUserAnswers(updated);

    if (isCorrect) {
      soundEngine.playSuccess();
      onEarnStar();
    } else {
      soundEngine.playGentleBoing();
    }

    if (currentQIdx < ASSESSMENT_QUESTIONS.length - 1) {
      setTimeout(() => setCurrentQIdx(prev => prev + 1), 600);
    } else {
      setTimeout(() => {
        setIsCompleted(true);
        confetti({
          particleCount: 80,
          spread: 80,
          origin: { y: 0.6 }
        });
        soundEngine.speakArabic('مَبْرُوكٌ يَا بَطَل! أَكْمَلْتَ التَّقْيِيمَ بِنَجَاحٍ بَاهِر!');
      }, 700);
    }
  };

  const correctCount = Object.values(userAnswers).filter(Boolean).length;

  const restartAssessment = () => {
    setCurrentQIdx(0);
    setUserAnswers({});
    setIsCompleted(false);
    setShowCertificate(false);
    soundEngine.playPop(440);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl p-6 lg:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <span className="text-3xl">⭐</span>
              <span>تَقْيِيمُ المَكْتَسَبَاتِ وَالشَّهَادَةِ التَّشْجِيعِيَّة</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              اختبار ممتع يقيس استيعاب الحروف، الأصوات، الأعداد والكميات، مع شهادة تكريمية للأطفال.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
              السؤال {currentQIdx + 1} من {ASSESSMENT_QUESTIONS.length}
            </span>
          </div>
        </div>

        {/* Assessment In Progress */}
        {!isCompleted ? (
          <div className="pt-8 max-w-xl mx-auto text-center space-y-6">
            <div className="space-y-2">
              <span className="px-3 py-1 bg-rose-50 text-rose-600 rounded-xl text-xs font-bold border border-rose-200">
                {currentQ.section} • {currentQ.title}
              </span>
              <h4 className="text-3xl font-extrabold text-slate-800 font-['Tajawal',sans-serif]">
                {currentQ.prompt}
              </h4>
              <button
                onClick={() => soundEngine.speakArabic(currentQ.prompt)}
                className="inline-flex items-center gap-1.5 text-xs text-rose-600 font-bold hover:underline pt-1"
              >
                <Volume2 className="w-4 h-4" />
                <span>استمع للسؤال</span>
              </button>
            </div>

            {/* Options */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4">
              {currentQ.options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(opt.isCorrect)}
                  className="h-28 rounded-3xl text-4xl sm:text-5xl font-extrabold bg-slate-50 hover:bg-rose-50 text-slate-800 border-2 border-slate-200 hover:border-rose-400 card-3d flex items-center justify-center font-['Tajawal',sans-serif]"
                >
                  {opt.display}
                </button>
              ))}
            </div>
          </div>
        ) : (
          /* Completion & Certificate View */
          <div className="pt-6 max-w-2xl mx-auto space-y-8 text-center">
            <div className="p-8 bg-gradient-to-tr from-amber-50 to-rose-50 rounded-3xl border-2 border-amber-200 space-y-4">
              <span className="text-6xl animate-bounce-slow inline-block">🏆</span>
              <h4 className="text-3xl font-extrabold text-slate-800 font-['Tajawal',sans-serif]">
                نَتِيجَةٌ مُمَيَّزَةٌ وَرَائِعَة!
              </h4>
              <p className="text-slate-600 font-medium text-sm">
                لقد أجبت بشكل صحيح على {correctCount} من {ASSESSMENT_QUESTIONS.length} أسئلة!
              </p>

              <div className="flex items-center justify-center gap-2 text-3xl">
                {'⭐'.repeat(Math.max(1, correctCount))}
              </div>

              {/* Enter Student Name for Certificate */}
              <div className="max-w-xs mx-auto pt-2 space-y-2">
                <label className="text-xs font-bold text-slate-700 block">
                  اكتب اسم الطفل لعرض الشهادة أمامه:
                </label>
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  className="w-full text-center px-4 py-2 rounded-xl border border-slate-300 font-bold text-slate-800 bg-white shadow-xs focus:ring-2 focus:ring-rose-400 focus:outline-hidden"
                  placeholder="اسم التلميذ(ة)"
                />
              </div>

              <div className="flex items-center justify-center gap-3 pt-3">
                <button
                  onClick={() => setShowCertificate(true)}
                  className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl font-bold text-xs flex items-center gap-2 shadow-xs btn-3d"
                >
                  <Award className="w-4 h-4" />
                  <span>عرض شهادة التقدير 🎓</span>
                </button>

                <button
                  onClick={restartAssessment}
                  className="px-4 py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-2xl font-bold text-xs flex items-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>إعادة التقييم</span>
                </button>
              </div>
            </div>

            {/* Certificate of Excellence Showcase */}
            {showCertificate && (
              <div className="p-8 bg-white border-8 border-amber-300 rounded-3xl shadow-xl space-y-6 relative overflow-hidden text-center">
                <div className="absolute top-2 left-2 text-3xl opacity-40">⭐</div>
                <div className="absolute top-2 right-2 text-3xl opacity-40">⭐</div>
                <div className="absolute bottom-2 left-2 text-3xl opacity-40">🎓</div>
                <div className="absolute bottom-2 right-2 text-3xl opacity-40">🏆</div>

                <div className="space-y-1">
                  <span className="text-xs font-bold tracking-widest text-amber-700 uppercase block">
                    الجمهورية الجزائرية الديمقراطية الشعبية • وزارة التربية الوطنية
                  </span>
                  <h3 className="text-3xl sm:text-4xl font-extrabold text-amber-900 font-['Tajawal',sans-serif]">
                    شَهَادَةُ تَقْدِيرٍ وَامْتِيَاز
                  </h3>
                </div>

                <div className="py-2 space-y-3">
                  <p className="text-sm text-slate-600">
                    تَشْهَدُ الآنسة مَنَار أَنَّ البَطَلَ(ة) المُمَيَّز:
                  </p>
                  <div className="text-3xl sm:text-4xl font-extrabold text-rose-600 font-['Tajawal',sans-serif] underline decoration-amber-400">
                    {studentName}
                  </div>
                  <p className="text-sm text-slate-700 leading-relaxed font-medium max-w-md mx-auto">
                    قَدْ أَتَمَّ دُرُوسَ وَأَنْشِطَةَ قِسْمِ التَّحْضِيرِي مَعَ الآنسة مَنَار فِي الحُرُوفِ، الأَعْدَادِ، التَّرْبِيَةِ الإِسْلَامِيَّةِ وَالعِلْمِيَّةِ بِتَفَوُّقٍ وَجَدَارَة!
                  </p>
                </div>

                <div className="flex items-center justify-between pt-6 border-t border-amber-200 text-xs font-bold text-slate-600 px-6">
                  <span>توقيع المعلمة: 👩‍🏫 الآنسة منار</span>
                  <span>القسم: قسم التحضيري والسنة الأولى</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
