import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  Music, 
  Sparkles,
  Award
} from 'lucide-react';
import { SONGS_DATA, SongItem } from '../data/otherModules';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

interface SongsModuleViewProps {
  onEarnStar: () => void;
}

export const SongsModuleView: React.FC<SongsModuleViewProps> = ({ onEarnStar }) => {
  const [selectedSong, setSelectedSong] = useState<SongItem>(SONGS_DATA[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeLineIdx, setActiveLineIdx] = useState(0);
  const [activeWordIdx, setActiveWordIdx] = useState<number | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    stopSong();
  }, [selectedSong]);

  const stopSong = () => {
    setIsPlaying(false);
    setActiveLineIdx(0);
    setActiveWordIdx(null);
    if (timerRef.current) clearInterval(timerRef.current);
    soundEngine.stopSpeech();
  };

  const playSong = () => {
    if (isPlaying) {
      stopSong();
      return;
    }

    setIsPlaying(true);
    let line = 0;
    let word = 0;

    const playStep = () => {
      if (line >= selectedSong.lyricsLines.length) {
        stopSong();
        onEarnStar();
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 }
        });
        soundEngine.playSuccess();
        soundEngine.speakArabic('أَحْسَنْتُمْ يَا كُرَالَ القِسْمِ المُمَيَّز!');
        return;
      }

      setActiveLineIdx(line);
      const currentWords = selectedSong.lyricsLines[line].words;

      if (word < currentWords.length) {
        setActiveWordIdx(word);
        const w = currentWords[word];
        soundEngine.playPop(300 + (word % 4) * 80);
        soundEngine.speakArabic(w);
        word++;
      } else {
        word = 0;
        line++;
      }
    };

    playStep();
    timerRef.current = setInterval(playStep, 1100);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <span className="text-3xl">🎵</span>
              <span>الأَنَاشِيدُ التَّعْلِيمِيَّةُ المَرِحَة</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              أناشيد ملحنة مع تظليل تفاعلي للكلمات أثناء القراءة لتعزيز الإيقاع واللغة السليمة.
            </p>
          </div>

          {/* Song Switcher */}
          <div className="flex items-center gap-2 overflow-x-auto">
            {SONGS_DATA.map(song => (
              <button
                key={song.id}
                onClick={() => {
                  stopSong();
                  setSelectedSong(song);
                }}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  selectedSong.id === song.id
                    ? 'bg-pink-500 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <span>{song.icon}</span>
                <span>{song.title}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Karaoke Stage */}
        <div className="pt-6 space-y-8 max-w-3xl mx-auto">
          {/* Animated 3D Music Header */}
          <div className="p-8 bg-gradient-to-r from-pink-50 via-purple-50 to-amber-50 rounded-3xl border-2 border-pink-200 text-center space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-center gap-4">
              <span className={`text-5xl ${isPlaying ? 'animate-bounce-slow' : ''}`}>
                {selectedSong.icon}
              </span>
              <span className={`text-4xl ${isPlaying ? 'animate-pulse-slow' : ''}`}>
                🎼
              </span>
            </div>
            <h4 className="text-2xl font-bold text-slate-800 font-['Tajawal',sans-serif]">
              {selectedSong.title}
            </h4>
            <span className="text-xs font-bold text-pink-700 bg-pink-100/70 px-3 py-1 rounded-full inline-block">
              {selectedSong.topic}
            </span>

            {/* Play / Pause Controller */}
            <div className="pt-3 flex items-center justify-center gap-3">
              <button
                onClick={playSong}
                className={`px-8 py-3.5 rounded-2xl font-bold text-sm text-white flex items-center gap-2 shadow-md transition-all btn-3d ${
                  isPlaying ? 'bg-amber-500 hover:bg-amber-600' : 'bg-pink-500 hover:bg-pink-600'
                }`}
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
                <span>{isPlaying ? 'إيقاف مؤقت' : 'تشغيل النشيد والتظليل'}</span>
              </button>

              <button
                onClick={stopSong}
                className="p-3.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-2xl text-slate-600"
                title="إعادة من البداية"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Large Karaoke Lyrics Lines */}
          <div className="space-y-4">
            {selectedSong.lyricsLines.map((lineObj, lIdx) => {
              const isLineActive = isPlaying && activeLineIdx === lIdx;

              return (
                <div
                  key={lIdx}
                  className={`p-6 rounded-3xl border-2 transition-all text-center ${
                    isLineActive
                      ? 'bg-rose-50 border-rose-300 ring-4 ring-rose-100 scale-102 shadow-sm'
                      : 'bg-white border-slate-100 hover:border-slate-200'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4">
                    {lineObj.words.map((word, wIdx) => {
                      const isWordActive = isLineActive && activeWordIdx === wIdx;

                      return (
                        <span
                          key={wIdx}
                          onClick={() => {
                            soundEngine.playPop(480);
                            soundEngine.speakArabic(word);
                          }}
                          className={`text-2xl sm:text-4xl font-extrabold cursor-pointer transition-all px-2 py-1 rounded-2xl font-['Tajawal',sans-serif] ${
                            isWordActive
                              ? 'bg-pink-500 text-white scale-110 shadow-sm animate-pulse-slow'
                              : isLineActive
                              ? 'text-pink-900'
                              : 'text-slate-700 hover:text-pink-600'
                          }`}
                        >
                          {word}
                        </span>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
