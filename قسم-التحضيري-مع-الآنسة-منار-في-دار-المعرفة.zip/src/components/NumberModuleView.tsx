import React, { useState } from 'react';
import { 
  Volume2, 
  ArrowLeft, 
  ArrowRight, 
  RotateCcw, 
  Sparkles, 
  Grid,
  Layers,
  ListOrdered,
  Search,
  BookOpen
} from 'lucide-react';
import { 
  NUMBERS_DATA, 
  NumberLesson, 
  getArabicNumberWord, 
  ALL_100_NUMBERS,
  TENS_NUMBERS,
  FullNumberItem
} from '../data/numbersMath';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

// 3D Realistic Images
import applesImg from '../assets/images/realistic_3d_apples_1790364650769.jpg';
import blocksImg from '../assets/images/math_base_ten_blocks_1790364660490.jpg';
import abacusImg from '../assets/images/educational_abacus_3d_1790364671277.jpg';

interface NumberModuleViewProps {
  onEarnStar: () => void;
}

export const NumberModuleView: React.FC<NumberModuleViewProps> = ({ onEarnStar }) => {
  const [activeTab, setActiveTab] = useState<'all_numbers_list' | 'hundred_grid' | 'units_tens' | 'tens_count' | 'basic_digits'>('all_numbers_list');
  
  // 1-100 Catalog Filter
  const [selectedDecade, setSelectedDecade] = useState<number>(0); // 0 = all, 1 = 1-10, 2 = 11-20, ... 10 = 91-100
  const [searchQuery, setSearchQuery] = useState('');

  // 1-100 Grid state
  const [selectedGridNum, setSelectedGridNum] = useState<number>(25);
  const [gridHighlightMode, setGridHighlightMode] = useState<'all' | 'tens' | 'fives' | 'even'>('all');

  // Place value units & tens machine:
  // Units (الوحدات) MUST ALWAYS BE ON THE RIGHT (اليمين)
  // Tens (العشرات) MUST ALWAYS BE ON THE LEFT (اليسار)
  const [placeUnits, setPlaceUnits] = useState(4); // اليمين
  const [placeTens, setPlaceTens] = useState(3);  // اليسار

  // Basic Digits 0-10 state
  const [selectedNumIndex, setSelectedNumIndex] = useState(3);
  const currentNumber: NumberLesson = NUMBERS_DATA[selectedNumIndex];
  const [interactiveCounted, setInteractiveCounted] = useState<number[]>([]);

  const speak = (text: string) => {
    soundEngine.playPop(520);
    soundEngine.speakArabic(text);
  };

  const triggerReward = () => {
    soundEngine.playSuccess();
    onEarnStar();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  const handleGridNumClick = (n: number) => {
    setSelectedGridNum(n);
    soundEngine.playPop(300 + (n % 10) * 40);
    const spoken = getArabicNumberWord(n);
    speak(`${n}.. ${spoken}`);
  };

  // Filtered 100 numbers list
  const filteredNumbers: FullNumberItem[] = ALL_100_NUMBERS.filter(item => {
    if (searchQuery.trim() !== '') {
      return (
        item.num.toString().includes(searchQuery.trim()) ||
        item.word.includes(searchQuery.trim())
      );
    }
    if (selectedDecade === 0) return true;
    const min = (selectedDecade - 1) * 10 + 1;
    const max = selectedDecade * 10;
    return item.num >= min && item.num <= max;
  });

  const placeTotal = placeTens * 10 + placeUnits;

  return (
    <div className="space-y-6">
      {/* Module Navigation Card */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <span className="text-3xl">🔢</span>
              <span>الأَعْدَادُ مِنْ وَاحِدٍ إِلَى مِئَة (1 إلى 100 بِالرَّقْمِ وَالحُرُوف)</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              جميع الأعداد مكتوبة بالحروف والأرقام • الوحدات دائماً على اليمين والعشرات على اليسار • أمثلة حية ثلاثية الأبعاد.
            </p>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('all_numbers_list'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'all_numbers_list' ? 'bg-amber-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <ListOrdered className="w-4 h-4" />
              <span>جميع الأرقام بالحروف (1-100)</span>
            </button>

            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('units_tens'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'units_tens' ? 'bg-rose-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>الوحدات (يمين) والعشرات (يسار)</span>
            </button>

            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('hundred_grid'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'hundred_grid' ? 'bg-sky-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Grid className="w-4 h-4" />
              <span>لوحة المئة (10x10)</span>
            </button>

            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('tens_count'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                activeTab === 'tens_count' ? 'bg-emerald-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              العد بالعشرات (10-100)
            </button>

            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('basic_digits'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                activeTab === 'basic_digits' ? 'bg-purple-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              الأرقام 0-10 وكتابتها
            </button>
          </div>
        </div>

        {/* Tab 1: All Numbers 1 to 100 with Names in Letters (جميع الأرقام بالحروف) */}
        {activeTab === 'all_numbers_list' && (
          <div className="pt-6 space-y-6">
            {/* Decade Quick Selectors */}
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                <button
                  onClick={() => setSelectedDecade(0)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    selectedDecade === 0 ? 'bg-amber-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  الكل (1-100)
                </button>
                {[
                  { id: 1, label: '1 - 10' },
                  { id: 2, label: '11 - 20' },
                  { id: 3, label: '21 - 30' },
                  { id: 4, label: '31 - 40' },
                  { id: 5, label: '41 - 50' },
                  { id: 6, label: '51 - 60' },
                  { id: 7, label: '61 - 70' },
                  { id: 8, label: '71 - 80' },
                  { id: 9, label: '81 - 90' },
                  { id: 10, label: '91 - 100' }
                ].map(d => (
                  <button
                    key={d.id}
                    onClick={() => setSelectedDecade(d.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                      selectedDecade === d.id ? 'bg-amber-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>

              {/* Quick Search Input */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="ابحث عن رقم أو كلمة..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="px-8 py-1.5 text-xs rounded-xl border border-slate-200 bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-400"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5" />
              </div>
            </div>

            {/* Rule Banner: Units on Right, Tens on Left */}
            <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-center justify-between text-xs font-bold text-amber-900">
              <span>👉 <strong className="text-rose-600">الوحدات (الآحاد) دائماً على اليمين</strong></span>
              <span className="text-slate-400">•</span>
              <span>👈 <strong className="text-indigo-600">العشرات دائماً على اليسار</strong></span>
              <span className="text-slate-400">•</span>
              <span>اضغط على أي بطاقة لسماع النطق العربي بالكلمات 🔊</span>
            </div>

            {/* 1 to 100 Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 max-h-[560px] overflow-y-auto p-1 scrollbar-thin">
              {filteredNumbers.map(item => (
                <div
                  key={item.num}
                  onClick={() => speak(`${item.num}.. ${item.word}`)}
                  className="p-4 bg-white hover:bg-amber-50/60 rounded-2xl border-2 border-slate-200 hover:border-amber-400 card-3d cursor-pointer text-center space-y-2 transition-colors relative group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-mono font-extrabold text-amber-600">
                      {item.num}
                    </span>
                    <button className="p-1 rounded-lg text-slate-400 group-hover:text-amber-600">
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Arabic Word with Full Tashkeel */}
                  <div className="text-sm font-extrabold text-slate-800 font-['Tajawal',sans-serif] leading-tight min-h-[36px] flex items-center justify-center">
                    {item.word}
                  </div>

                  {/* Right: Units | Left: Tens breakdown */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold">
                    {/* Physical RIGHT in RTL = Units */}
                    <span className="text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md" title="الوحدات على اليمين">
                      👉 و (يمين): {item.units}
                    </span>
                    {/* Physical LEFT in RTL = Tens */}
                    <span className="text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md" title="العشرات على اليسار">
                      ع (يسار): {item.tens} 👈
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Place Value Machine (الوحدات على اليمين والعشرات على اليسار) */}
        {activeTab === 'units_tens' && (
          <div className="pt-6 space-y-6 max-w-4xl mx-auto">
            <div className="text-center space-y-2">
              <h4 className="text-2xl font-bold text-slate-800">
                جَدْوَلُ المَنَازِل: الوَحَدَاتُ عَلَى اليَمِينِ وَالعَشَرَاتُ عَلَى اليَسَار 📐
              </h4>
              <p className="text-xs text-slate-500">
                في الرياضيات العربية، نبدأ دائماً من اليمين بخانة الوحدات، ثم ننتقل إلى اليسار لخانة العشرات.
              </p>
            </div>

            {/* 3D Realistic Image Showcase of Base-Ten Blocks */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
              <div className="h-48 rounded-2xl overflow-hidden shadow-md border-2 border-slate-200">
                <img
                  src={blocksImg}
                  alt="مكعبات الآحاد وقضبان العشرات ثلاثية الأبعاد"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 space-y-2 text-right">
                <h5 className="font-bold text-amber-900 text-sm flex items-center gap-1.5">
                  <span>🧱</span>
                  <span>التمثيل المجسم ثلاثي الأبعاد:</span>
                </h5>
                <p className="text-xs text-slate-700 leading-relaxed font-medium">
                  • <strong>الوحدات (الآحاد) على اليمين:</strong> مكعبات مفردة تمثل الأعداد من 0 إلى 9.<br/>
                  • <strong>العشرات على اليسار:</strong> قضيب مكوّن من 10 مكعبات متراصة يمثل عشرة كاملة.
                </p>
              </div>
            </div>

            {/* The Interactive Place Value Builder with RIGHT = Units, LEFT = Tens */}
            <div className="p-8 bg-gradient-to-tr from-amber-50 via-white to-rose-50 rounded-3xl border-2 border-slate-200 space-y-6 shadow-sm">
              {/* Golden Rule Banner */}
              <div className="p-3.5 bg-white rounded-2xl border-2 border-amber-300 shadow-xs flex items-center justify-between text-xs sm:text-sm font-extrabold text-slate-800">
                <span className="text-rose-600">👉 خَانَةُ الوَحَدَاتِ (الآحَاد) دَائِماً عَلَى اليَمِين</span>
                <span className="text-slate-300">•</span>
                <span className="text-indigo-600">👈 خَانَةُ العَشَرَاتِ دَائِماً عَلَى اليَسَار</span>
              </div>

              {/* Columns Header with Direction Arrows */}
              <div className="grid grid-cols-2 gap-6 text-center">
                {/* PHYSICAL RIGHT COLUMN (First in RTL) = UNITS (الوحدات) */}
                <div className="p-4 bg-rose-50/90 rounded-2xl border-2 border-rose-300 space-y-3 shadow-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-rose-800 bg-white px-2.5 py-1 rounded-lg shadow-xs">
                      👉 جِهَةُ اليَمِين (المنزلة الأولى)
                    </span>
                    <span className="text-sm font-extrabold text-rose-900">
                      خَانَةُ الوَحَدَات (الآحَاد)
                    </span>
                  </div>

                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => {
                        setPlaceUnits(u => Math.max(0, u - 1));
                        soundEngine.playPop(380);
                      }}
                      className="w-10 h-10 rounded-xl bg-white border border-rose-300 text-rose-700 font-bold text-xl hover:bg-rose-100"
                    >
                      -
                    </button>
                    <span className="text-5xl font-mono font-extrabold text-rose-600">
                      {placeUnits}
                    </span>
                    <button
                      onClick={() => {
                        setPlaceUnits(u => Math.min(9, u + 1));
                        soundEngine.playPop(480);
                      }}
                      className="w-10 h-10 rounded-xl bg-white border border-rose-300 text-rose-700 font-bold text-xl hover:bg-rose-100"
                    >
                      +
                    </button>
                  </div>

                  {/* 3D-styled individual units cubes */}
                  <div className="flex flex-wrap items-center justify-center gap-1.5 h-16 p-2 bg-white/80 rounded-xl border border-rose-200 overflow-hidden">
                    {Array.from({ length: placeUnits }).map((_, i) => (
                      <div key={i} className="w-6 h-6 bg-gradient-to-tr from-rose-500 to-pink-400 border border-rose-600 rounded-sm shadow-xs flex items-center justify-center text-[10px] text-white font-bold" title="مكعب وحدة">
                        1
                      </div>
                    ))}
                  </div>
                </div>

                {/* PHYSICAL LEFT COLUMN (Second in RTL) = TENS (العشرات) */}
                <div className="p-4 bg-indigo-50/90 rounded-2xl border-2 border-indigo-300 space-y-3 shadow-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-indigo-800 bg-white px-2.5 py-1 rounded-lg shadow-xs">
                      👈 جِهَةُ اليَسَار (المنزلة الثانية)
                    </span>
                    <span className="text-sm font-extrabold text-indigo-900">
                      خَانَةُ العَشَرَات
                    </span>
                  </div>

                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => {
                        setPlaceTens(t => Math.max(0, t - 1));
                        soundEngine.playPop(380);
                      }}
                      className="w-10 h-10 rounded-xl bg-white border border-indigo-300 text-indigo-700 font-bold text-xl hover:bg-indigo-100"
                    >
                      -
                    </button>
                    <span className="text-5xl font-mono font-extrabold text-indigo-600">
                      {placeTens}
                    </span>
                    <button
                      onClick={() => {
                        setPlaceTens(t => Math.min(9, t + 1));
                        soundEngine.playPop(480);
                      }}
                      className="w-10 h-10 rounded-xl bg-white border border-indigo-300 text-indigo-700 font-bold text-xl hover:bg-indigo-100"
                    >
                      +
                    </button>
                  </div>

                  {/* 3D-styled tens rods */}
                  <div className="flex items-center justify-center gap-1.5 h-16 p-2 bg-white/80 rounded-xl border border-indigo-200 overflow-hidden">
                    {Array.from({ length: placeTens }).map((_, i) => (
                      <div key={i} className="w-5 h-12 bg-gradient-to-b from-indigo-400 to-indigo-600 border border-indigo-700 rounded-sm shadow-xs flex items-center justify-center text-[10px] text-white font-bold" title="قضيب 10">
                        10
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Combined Number Output with Official Primary School Place-Value Table */}
              <div className="p-6 bg-white rounded-3xl border-2 border-slate-200 text-center space-y-4 shadow-xs">
                <span className="text-xs font-bold text-slate-500 block">العَدَدُ الإِجْمَالِيُّ المُتَكَوِّن:</span>
                
                {/* Official Algerian/Arab Classroom Place-Value Table */}
                <div className="max-w-md mx-auto rounded-3xl border-4 border-slate-300 overflow-hidden shadow-md bg-white">
                  {/* Table Header: First child in RTL is PHYSICAL RIGHT (Units), Second child is PHYSICAL LEFT (Tens) */}
                  <div className="grid grid-cols-2 text-center text-white font-extrabold text-sm border-b-2 border-slate-300">
                    {/* PHYSICAL RIGHT (الوحدات) */}
                    <div className="bg-rose-500 py-3 px-3 border-l-2 border-slate-300 flex items-center justify-center gap-1.5">
                      <span>👉</span>
                      <span>الوحدات (اليمين)</span>
                      <span className="bg-white/25 px-2 py-0.5 rounded-md text-xs">و</span>
                    </div>

                    {/* PHYSICAL LEFT (العشرات) */}
                    <div className="bg-indigo-600 py-3 px-3 flex items-center justify-center gap-1.5">
                      <span className="bg-white/25 px-2 py-0.5 rounded-md text-xs">ع</span>
                      <span>العشرات (اليسار)</span>
                      <span>👈</span>
                    </div>
                  </div>

                  {/* Table Body Numbers: First child in RTL is PHYSICAL RIGHT (Units), Second child is PHYSICAL LEFT (Tens) */}
                  <div className="grid grid-cols-2 text-center py-5 bg-slate-50 font-mono font-extrabold text-6xl">
                    {/* PHYSICAL RIGHT (Units Digit) */}
                    <div className="text-rose-600 border-l-2 border-slate-200 flex flex-col items-center justify-center">
                      <span>{placeUnits}</span>
                      <span className="text-xs font-bold text-rose-600 font-['Tajawal',sans-serif] mt-1">
                        {placeUnits} {placeUnits === 1 ? 'وحدة' : 'وحدات'} (يمين)
                      </span>
                    </div>

                    {/* PHYSICAL LEFT (Tens Digit) */}
                    <div className="text-indigo-600 flex flex-col items-center justify-center">
                      <span>{placeTens}</span>
                      <span className="text-xs font-bold text-indigo-600 font-['Tajawal',sans-serif] mt-1">
                        {placeTens} {placeTens === 1 ? 'عشرة' : 'عشرات'} (يسار)
                      </span>
                    </div>
                  </div>

                  {/* Table Footer with the standard numeral representation */}
                  <div className="p-3 bg-slate-100 border-t-2 border-slate-200 text-xs font-bold text-slate-700 flex items-center justify-between px-6">
                    <span className="text-indigo-700">👈 العشرات في المنزلة اليسرى: {placeTens}</span>
                    <span className="text-rose-700">الوحدات في المنزلة اليمنى: {placeUnits} 👉</span>
                  </div>
                </div>

                {/* Spoken Word in Letters with Harakat */}
                <div className="text-3xl font-extrabold text-slate-900 font-['Tajawal',sans-serif] pt-1">
                  {getArabicNumberWord(placeTotal)}
                </div>

                <div className="flex items-center justify-center gap-3 pt-2">
                  <button
                    onClick={() => speak(`العدد هو ${placeTotal}.. ${getArabicNumberWord(placeTotal)}.. الوحدات على اليمين ${placeUnits}.. والعشرات على اليسار ${placeTens}`)}
                    className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-xs"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>انطق العدد مع الوحدات والعشرات 🔊</span>
                  </button>

                  <button
                    onClick={triggerReward}
                    className="px-4 py-2.5 bg-emerald-50 text-emerald-700 font-bold rounded-xl text-xs border border-emerald-200 flex items-center gap-1"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>أتقنت المفهوم! ⭐</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: 100-Grid with Click-to-Speak (لوحة المئة) */}
        {activeTab === 'hundred_grid' && (
          <div className="pt-6 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-sky-50 rounded-2xl border border-sky-200">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-sky-900">تصفية لوحة المئة:</span>
                <button
                  onClick={() => setGridHighlightMode('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    gridHighlightMode === 'all' ? 'bg-sky-500 text-white shadow-xs' : 'bg-white text-slate-700 border border-sky-200'
                  }`}
                >
                  الكل (1-100)
                </button>
                <button
                  onClick={() => setGridHighlightMode('tens')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    gridHighlightMode === 'tens' ? 'bg-sky-500 text-white shadow-xs' : 'bg-white text-slate-700 border border-sky-200'
                  }`}
                >
                  العشرات التامة
                </button>
                <button
                  onClick={() => setGridHighlightMode('fives')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    gridHighlightMode === 'fives' ? 'bg-sky-500 text-white shadow-xs' : 'bg-white text-slate-700 border border-sky-200'
                  }`}
                >
                  مضاعفات 5
                </button>
              </div>

              {/* Selected Number Details */}
              <div className="flex items-center gap-4 bg-white px-4 py-2 rounded-2xl border border-sky-200 shadow-xs">
                <div>
                  <span className="text-xs text-slate-500 block">العدد:</span>
                  <span className="text-3xl font-mono font-extrabold text-sky-600 block">{selectedGridNum}</span>
                </div>
                <div className="text-right">
                  <span className="text-base font-extrabold text-slate-800 block font-['Tajawal',sans-serif]">
                    {getArabicNumberWord(selectedGridNum)}
                  </span>
                  <div className="text-[11px] text-slate-500 flex items-center gap-2">
                    <span className="text-rose-600 font-bold">الوحدات (يمين): {selectedGridNum === 100 ? 0 : selectedGridNum % 10}</span>
                    <span>•</span>
                    <span className="text-indigo-600 font-bold">العشرات (يسار): {selectedGridNum === 100 ? 10 : Math.floor(selectedGridNum / 10)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 10x10 Grid */}
            <div className="grid grid-cols-10 gap-1.5 sm:gap-2 max-w-4xl mx-auto p-4 bg-slate-50 rounded-3xl border-2 border-slate-200 shadow-inner">
              {Array.from({ length: 100 }, (_, i) => i + 1).map(n => {
                const isSelected = n === selectedGridNum;
                let isHighlighted = true;
                if (gridHighlightMode === 'tens') isHighlighted = n % 10 === 0;
                else if (gridHighlightMode === 'fives') isHighlighted = n % 5 === 0;

                return (
                  <button
                    key={n}
                    onClick={() => handleGridNumClick(n)}
                    className={`h-11 sm:h-12 rounded-xl font-mono font-bold text-sm sm:text-base transition-all card-3d flex items-center justify-center ${
                      isSelected
                        ? 'bg-rose-500 text-white scale-110 shadow-md ring-2 ring-rose-300 z-10'
                        : isHighlighted
                        ? 'bg-white hover:bg-sky-100 text-slate-800 border border-slate-200 hover:border-sky-400'
                        : 'bg-slate-100/60 text-slate-400 border border-slate-100 opacity-60'
                    }`}
                  >
                    {n}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 4: Tens Counting (العد بالعشرات) */}
        {activeTab === 'tens_count' && (
          <div className="pt-6 space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h4 className="text-2xl font-bold text-slate-800">
                العَدُّ بِالعَشَرَاتِ الكَامِلَة (10 إلى 100) 🔟
              </h4>
              <p className="text-xs text-slate-500">
                كل خطوة نزيد 10 كاملة: 10، 20، 30، 40، 50، 60، 70، 80، 90، 100!
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
              {TENS_NUMBERS.map(n => (
                <button
                  key={n}
                  onClick={() => {
                    soundEngine.playPop(300 + (n / 10) * 40);
                    speak(`${n}.. ${getArabicNumberWord(n)}`);
                  }}
                  className="p-5 bg-emerald-50 hover:bg-emerald-100 rounded-3xl border-2 border-emerald-200 card-3d text-center space-y-2 cursor-pointer transition-colors"
                >
                  <span className="text-4xl font-mono font-extrabold text-emerald-700 block">
                    {n}
                  </span>
                  <span className="text-base font-extrabold text-slate-800 block font-['Tajawal',sans-serif]">
                    {getArabicNumberWord(n)}
                  </span>
                  <div className="text-[11px] font-bold text-emerald-800">
                    الوحدات: 0 | العشرات: {n / 10}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Tab 5: Basic Digits 0-10 & Real Examples */}
        {activeTab === 'basic_digits' && (
          <div className="pt-6 space-y-6">
            {/* Number Selector 0-10 */}
            <div className="grid grid-cols-6 sm:grid-cols-11 gap-2">
              {NUMBERS_DATA.map((item, idx) => {
                const isSelected = idx === selectedNumIndex;
                return (
                  <button
                    key={item.num}
                    onClick={() => {
                      soundEngine.playPop(480);
                      setSelectedNumIndex(idx);
                      speak(`الرقم ${item.num}.. ${item.word}`);
                    }}
                    className={`h-12 rounded-2xl font-mono font-bold text-2xl flex items-center justify-center transition-all ${
                      isSelected
                        ? 'bg-purple-500 text-white shadow-md scale-105 btn-3d'
                        : 'bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200'
                    }`}
                  >
                    {item.symbol}
                  </button>
                );
              })}
            </div>

            {/* Realistic Image Example */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div className="p-8 bg-purple-50/70 border-2 border-purple-200 rounded-3xl text-center space-y-4">
                <span className="text-8xl font-mono font-extrabold text-purple-600 block">
                  {currentNumber.symbol}
                </span>
                <span className="text-3xl font-extrabold text-slate-800 block font-['Tajawal',sans-serif]">
                  {currentNumber.word}
                </span>
                <p className="text-sm text-slate-700 font-medium">
                  {currentNumber.childSpeech}
                </p>

                <div className="flex items-center justify-center gap-3 py-2 text-5xl">
                  {currentNumber.countingItems.map((em, i) => (
                    <span key={i} className="animate-bounce-slow">{em}</span>
                  ))}
                </div>

                <button
                  onClick={() => speak(currentNumber.childSpeech)}
                  className="px-6 py-2.5 bg-purple-500 hover:bg-purple-600 text-white rounded-2xl font-bold text-xs inline-flex items-center gap-2"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>استمع لشرح الرقم</span>
                </button>
              </div>

              {/* Realistic 3D Apple Tray Photo */}
              <div className="space-y-3">
                <div className="h-60 rounded-3xl overflow-hidden shadow-md border-2 border-slate-200">
                  <img
                    src={applesImg}
                    alt="تفاح أحمر حقيقي ومجسم للعد"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-3 bg-rose-50 rounded-2xl border border-rose-200 text-xs text-rose-900 font-bold text-center">
                  🍎 تفاحات حقيقية مجسمة ثلاثية الأبعاد لربط العدد بالكمية الملموسة.
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
