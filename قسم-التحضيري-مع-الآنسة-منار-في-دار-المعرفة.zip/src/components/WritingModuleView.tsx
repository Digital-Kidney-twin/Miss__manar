import React, { useState, useRef, useEffect } from 'react';
import { 
  Volume2, 
  RotateCcw, 
  Sparkles, 
  Pencil, 
  Eraser, 
  Check, 
  Play,
  ArrowRight,
  ArrowLeft
} from 'lucide-react';
import { PRE_WRITING_TRACKS, PreWritingTrack } from '../data/otherModules';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

interface WritingModuleViewProps {
  onEarnStar: () => void;
}

export const WritingModuleView: React.FC<WritingModuleViewProps> = ({ onEarnStar }) => {
  const [selectedTrack, setSelectedTrack] = useState<PreWritingTrack>(PRE_WRITING_TRACKS[0]);
  const [brushColor, setBrushColor] = useState('#2563EB');
  const [brushSize, setBrushSize] = useState(8);
  const [activeTab, setActiveTab] = useState<'tracks' | 'pencil_grip' | 'free_draw'>('tracks');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawing = useRef(false);

  // Initialize and clear canvas when track changes
  useEffect(() => {
    clearCanvas();
  }, [selectedTrack, activeTab]);

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    isDrawing.current = true;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    ctx.beginPath();
    ctx.moveTo(clientX - rect.left, clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    ctx.strokeStyle = brushColor;
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    ctx.lineTo(clientX - rect.left, clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (isDrawing.current) {
      isDrawing.current = false;
      soundEngine.playPop(480);
    }
  };

  const handleFinishTracing = () => {
    soundEngine.playSuccess();
    onEarnStar();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });
    soundEngine.speakArabic('أَحْسَنْتَ يَا رَسَّامَنَا الصَّغِير! خَطٌّ جَمِيلٌ وَمُنَظَّم!');
  };

  const speak = (text: string) => {
    soundEngine.playPop(520);
    soundEngine.speakArabic(text);
  };

  return (
    <div className="space-y-6">
      {/* Header and Mode Selector */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <span className="text-3xl">✏️</span>
              <span>الكِتَابَةُ وَالخَطُّ وَالتَّهْيِئَةُ لِلْقَلَم</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              تمارين إعداد عضلات اليد الدقيقة، مسك القلم، والتحكم في الاتجاهات على الشاشة التفاعلية.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('tracks'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                activeTab === 'tracks' ? 'bg-teal-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              تتبع المسارات والخطوط
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('pencil_grip'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                activeTab === 'pencil_grip' ? 'bg-amber-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              مسك القلم والاتجاهات
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('free_draw'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                activeTab === 'free_draw' ? 'bg-rose-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              السبورة الحرة
            </button>
          </div>
        </div>

        {/* Tab 1: Tracing Tracks */}
        {activeTab === 'tracks' && (
          <div className="pt-6 space-y-6">
            {/* Track Selector Buttons */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              {PRE_WRITING_TRACKS.map(track => {
                const isSelected = track.id === selectedTrack.id;
                return (
                  <button
                    key={track.id}
                    onClick={() => {
                      soundEngine.playPop(480);
                      setSelectedTrack(track);
                      speak(track.instruction);
                    }}
                    className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap border-2 transition-all ${
                      isSelected
                        ? 'bg-teal-50 border-teal-500 text-teal-800 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {track.title}
                  </button>
                );
              })}
            </div>

            {/* Instruction banner */}
            <div className="flex items-center justify-between p-4 bg-teal-50/80 rounded-2xl border border-teal-200">
              <div className="flex items-center gap-3">
                <span className="text-2xl">🚗</span>
                <span className="text-sm font-bold text-teal-900">
                  {selectedTrack.instruction}
                </span>
              </div>
              <button
                onClick={() => speak(selectedTrack.instruction)}
                className="p-2 bg-white rounded-xl shadow-xs border border-teal-200 text-teal-600 hover:text-teal-700"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>

            {/* Tracing Canvas Area */}
            <div className="relative w-full h-72 sm:h-80 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-300 overflow-hidden shadow-inner flex items-center justify-center">
              {/* Background Guide SVG */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none p-4" viewBox="0 0 500 200">
                {/* Dotted guide line */}
                <path
                  d={selectedTrack.svgPath}
                  fill="none"
                  stroke="#CBD5E1"
                  strokeWidth="16"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d={selectedTrack.svgPath}
                  fill="none"
                  stroke="#0D9488"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="guide-path"
                />
                {/* Start indicator ⭐ */}
                <circle cx={selectedTrack.startPoint.x} cy={selectedTrack.startPoint.y} r="14" fill="#F59E0B" />
                <text x={selectedTrack.startPoint.x} y={selectedTrack.startPoint.y + 5} fill="white" fontSize="14" textAnchor="middle" fontWeight="bold">⭐</text>
                
                {/* End indicator 🏁 */}
                <circle cx={selectedTrack.endPoint.x} cy={selectedTrack.endPoint.y} r="14" fill="#10B981" />
                <text x={selectedTrack.endPoint.x} y={selectedTrack.endPoint.y + 5} fill="white" fontSize="14" textAnchor="middle" fontWeight="bold">🏁</text>
              </svg>

              {/* Drawing Interactive HTML Canvas */}
              <canvas
                ref={canvasRef}
                width={700}
                height={350}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
                className="absolute inset-0 w-full h-full cursor-crosshair touch-none"
              />
            </div>

            {/* Canvas Toolbar & Actions */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
              {/* Color Palette */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600">لون القلم:</span>
                {['#2563EB', '#DC2626', '#16A34A', '#9333EA', '#D97706'].map(c => (
                  <button
                    key={c}
                    onClick={() => setBrushColor(c)}
                    style={{ backgroundColor: c }}
                    className={`w-8 h-8 rounded-full border-2 transition-transform ${
                      brushColor === c ? 'scale-115 border-white ring-2 ring-slate-400' : 'border-transparent'
                    }`}
                  />
                ))}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3">
                <button
                  onClick={clearCanvas}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>مسح الرسم</span>
                </button>

                <button
                  onClick={handleFinishTracing}
                  className="px-6 py-2.5 bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-xs btn-3d"
                >
                  <Check className="w-4 h-4" />
                  <span>أنهيت التتبع! 🏆</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Pencil Grip & Directions Guide */}
        {activeTab === 'pencil_grip' && (
          <div className="pt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-amber-50 rounded-3xl border border-amber-200 text-center space-y-3">
                <span className="text-5xl">✋</span>
                <h4 className="text-lg font-bold text-amber-900">مسك القلم بالثلاث أصابع</h4>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  نمسك القلم بالإبهام والسبابة، ويستند برفق على الإصبع الأوسط دون ضغط شديد.
                </p>
                <button
                  onClick={() => speak('نمسك القلم بالإبهام والسبابة، ويستند بلطف على الإصبع الأوسط!')}
                  className="px-3 py-1.5 bg-amber-500 text-white rounded-xl text-xs font-bold"
                >
                  استمع للتوجيه
                </button>
              </div>

              <div className="p-6 bg-sky-50 rounded-3xl border border-sky-200 text-center space-y-3">
                <span className="text-5xl">➡️</span>
                <h4 className="text-lg font-bold text-sky-900">الاتجاه من اليمين لليسار</h4>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  في لغتنا العربية الجميلة، نبدأ الكتابة دائماً من اليمين نحو اليسار على السطر.
                </p>
                <button
                  onClick={() => speak('في اللغة العربية، نبدأ دائماً من اليمين ونتحرك نحو اليسار!')}
                  className="px-3 py-1.5 bg-sky-500 text-white rounded-xl text-xs font-bold"
                >
                  استمع للتوجيه
                </button>
              </div>

              <div className="p-6 bg-rose-50 rounded-3xl border border-rose-200 text-center space-y-3">
                <span className="text-5xl">🪑</span>
                <h4 className="text-lg font-bold text-rose-900">الجلوس السليم</h4>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  ظهر مستقيم، القدمان على الأرض، ومسافة مريحة بين العينين واللوح أو الدفتر.
                </p>
                <button
                  onClick={() => speak('اجلس بظهر مستقيم وقدمين على الأرض للحفاظ على صحة جسمك!')}
                  className="px-3 py-1.5 bg-rose-500 text-white rounded-xl text-xs font-bold"
                >
                  استمع للتوجيه
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Free Drawing Canvas */}
        {activeTab === 'free_draw' && (
          <div className="pt-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600">
                سبورة تفاعلية مفتوحة للأطفال لكتابة الحروف والأرقام بحرية:
              </span>
              <button
                onClick={clearCanvas}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>مسح</span>
              </button>
            </div>

            <div className="relative w-full h-80 bg-white rounded-3xl border-2 border-slate-300 overflow-hidden shadow-inner">
              <canvas
                ref={canvasRef}
                width={800}
                height={400}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
                className="absolute inset-0 w-full h-full cursor-crosshair touch-none"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
