import React, { useState } from 'react';
import { 
  Volume2, 
  Sparkles, 
  CheckCircle2, 
  RotateCcw,
  Palette,
  Shapes,
  HelpCircle
} from 'lucide-react';
import { COLORS_DATA, SHAPES_DATA, ColorItem, ShapeItem } from '../data/otherModules';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

interface ColorsShapesModuleViewProps {
  onEarnStar: () => void;
}

export const ColorsShapesModuleView: React.FC<ColorsShapesModuleViewProps> = ({ onEarnStar }) => {
  const [activeTab, setActiveTab] = useState<'colors' | 'shapes' | 'color_quiz' | 'shape_quiz'>('colors');
  const [selectedColor, setSelectedColor] = useState<ColorItem>(COLORS_DATA[0]);
  const [selectedShape, setSelectedShape] = useState<ShapeItem>(SHAPES_DATA[0]);
  const [quizScore, setQuizScore] = useState(0);
  const [answeredCorrectly, setAnsweredCorrectly] = useState<boolean | null>(null);

  const speak = (text: string) => {
    soundEngine.playPop(520);
    soundEngine.speakArabic(text);
  };

  const triggerReward = () => {
    soundEngine.playSuccess();
    onEarnStar();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  return (
    <div className="space-y-6">
      {/* Module Navigation Card */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <span className="text-3xl">🎨</span>
              <span>عَالَمُ الأَلْوَانِ وَالأَشْكَالِ الهَنْدَسِيَّة</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              اكتشاف الألوان الأساسية، الأشكال الهندسية، وربطها بالأشياء في حياتنا اليومية.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('colors'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                activeTab === 'colors' ? 'bg-rose-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Palette className="w-4 h-4" />
              <span>الألوان الجميلة</span>
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('shapes'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                activeTab === 'shapes' ? 'bg-sky-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Shapes className="w-4 h-4" />
              <span>الأشكال الهندسية</span>
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('color_quiz'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                activeTab === 'color_quiz' ? 'bg-amber-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>🎮 لعبة الألوان</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Colors Showcase */}
        {activeTab === 'colors' && (
          <div className="pt-6 space-y-6">
            {/* Color Swatch Selector */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              {COLORS_DATA.map(c => {
                const isSelected = c.id === selectedColor.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => {
                      soundEngine.playPop(480);
                      setSelectedColor(c);
                      speak(`اللَّوْنُ ${c.arabicName}`);
                    }}
                    style={{ backgroundColor: c.hex }}
                    className={`h-12 px-4 rounded-2xl font-bold text-xs flex items-center gap-2 border-2 transition-all ${
                      isSelected ? 'ring-4 ring-rose-200 scale-105 shadow-md border-white text-white' : 'border-slate-200 opacity-90 text-white'
                    }`}
                  >
                    <span className="drop-shadow-sm font-['Tajawal',sans-serif]">{c.arabicName}</span>
                  </button>
                );
              })}
            </div>

            {/* Selected Color Showcase Stage */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center pt-4">
              <div 
                style={{ backgroundColor: selectedColor.hex }}
                className="md:col-span-5 h-64 rounded-3xl shadow-md border-4 border-white flex flex-col items-center justify-center p-6 text-white text-center cursor-pointer card-3d relative"
                onClick={() => speak(`اللَّوْنُ ${selectedColor.arabicName}`)}
              >
                <span className="text-5xl font-extrabold drop-shadow-md font-['Tajawal',sans-serif]">
                  {selectedColor.arabicName}
                </span>
                <span className="text-xs font-medium mt-2 bg-black/20 px-3 py-1 rounded-full backdrop-blur-xs">
                  اضغط لسماع اسم اللون 🔊
                </span>
              </div>

              <div className="md:col-span-7 space-y-4">
                <h4 className="text-base font-bold text-slate-800">
                  أَشْيَاءٌ تَتَمَيَّزُ بِاللَّوْنِ {selectedColor.arabicName}:
                </h4>
                <div className="grid grid-cols-3 gap-3">
                  {selectedColor.exampleItems.map((ex, idx) => (
                    <div
                      key={idx}
                      onClick={() => speak(`${ex.name}.. لَوْنُهُ ${selectedColor.arabicName}`)}
                      className="p-4 bg-slate-50 hover:bg-slate-100 rounded-2xl border border-slate-200 text-center cursor-pointer transition-colors"
                    >
                      <span className="text-5xl block mb-2">{ex.emoji}</span>
                      <span className="text-sm font-bold text-slate-700 block">{ex.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Shapes Showcase */}
        {activeTab === 'shapes' && (
          <div className="pt-6 space-y-6">
            {/* Shape Selector Ribbon */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              {SHAPES_DATA.map(s => {
                const isSelected = s.id === selectedShape.id;
                return (
                  <button
                    key={s.id}
                    onClick={() => {
                      soundEngine.playPop(480);
                      setSelectedShape(s);
                      speak(`الشَّكْل: ${s.arabicName}.. ${s.description}`);
                    }}
                    className={`px-4 py-2.5 rounded-2xl font-bold text-xs whitespace-nowrap border-2 transition-all flex items-center gap-2 ${
                      isSelected
                        ? 'bg-sky-50 border-sky-500 text-sky-800 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>{s.emojiExample}</span>
                    <span>{s.arabicName}</span>
                  </button>
                );
              })}
            </div>

            {/* Selected Shape Arena */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center pt-4">
              <div 
                onClick={() => speak(`${selectedShape.arabicName}.. ${selectedShape.description}`)}
                className="md:col-span-5 h-64 bg-slate-50 rounded-3xl border-2 border-slate-200 flex flex-col items-center justify-center p-6 text-center cursor-pointer card-3d relative"
              >
                <div 
                  className="w-36 h-36 flex items-center justify-center"
                  dangerouslySetInnerHTML={{ __html: `<svg viewBox="0 0 100 100" class="w-full h-full">${selectedShape.svgPath}</svg>` }}
                />
                <span className="text-2xl font-extrabold text-slate-800 mt-2 font-['Tajawal',sans-serif]">
                  {selectedShape.arabicName}
                </span>
              </div>

              <div className="md:col-span-7 space-y-4">
                <div className="p-5 bg-sky-50 rounded-2xl border border-sky-200 space-y-2">
                  <h4 className="font-bold text-sky-900 text-base">
                    خَصَائِصُ {selectedShape.arabicName}:
                  </h4>
                  <p className="text-xs text-slate-700 leading-relaxed font-medium">
                    {selectedShape.description}
                  </p>
                  <div className="flex items-center gap-4 pt-2 text-xs font-bold text-sky-800">
                    <span>الأضلاع: {selectedShape.sides}</span>
                    <span>•</span>
                    <span>الرؤوس (الزوايا): {selectedShape.corners}</span>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center gap-3">
                  <span className="text-3xl">{selectedShape.emojiExample}</span>
                  <div>
                    <span className="text-xs text-slate-500 block">نَرَاهُ فِي حَيَاتِنَا مِثْل:</span>
                    <span className="text-sm font-bold text-slate-800">{selectedShape.realWorldExample}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Colors & Shapes Mini Game */}
        {activeTab === 'color_quiz' && (
          <div className="pt-6 space-y-6 max-w-xl mx-auto text-center">
            <div className="space-y-2">
              <span className="text-4xl">🎯</span>
              <h3 className="text-2xl font-bold text-slate-800">
                أَيْنَ هُوَ اللَّوْنُ الأَحْمَر؟ 🔴
              </h3>
              <p className="text-slate-600 text-sm">
                المعلمة تسأل الأطفال والطفل يختار اللون الصحيح على الشاشة!
              </p>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4">
              {[
                { hex: '#3B82F6', name: 'أَزْرَق', isCorrect: false },
                { hex: '#EF4444', name: 'أَحْمَر', isCorrect: true },
                { hex: '#10B981', name: 'أَخْضَر', isCorrect: false }
              ].map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    if (opt.isCorrect) {
                      setAnsweredCorrectly(true);
                      triggerReward();
                      speak('أحسنت يا بطل! هذا هو اللون الأحمر!');
                    } else {
                      setAnsweredCorrectly(false);
                      soundEngine.playGentleBoing();
                      speak('لا يا صغيري، حاول مرة ثانية!');
                    }
                  }}
                  style={{ backgroundColor: opt.hex }}
                  className="h-28 rounded-3xl font-bold text-xl text-white flex items-center justify-center card-3d border-2 border-white shadow-md hover:scale-105 transition-transform"
                >
                  <span className="drop-shadow-md">{opt.name}</span>
                </button>
              ))}
            </div>

            {answeredCorrectly === true && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 font-bold animate-bounce-slow">
                🎉 ممتاز! إجابة صحيحة! نلت نجمة ذهبية ⭐
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
