import React, { useState } from 'react';
import { 
  Volume2, 
  Sparkles, 
  CheckCircle2, 
  RotateCcw,
  Globe2,
  HeartHandshake,
  Check,
  X
} from 'lucide-react';
import { WORLD_TOPICS, BEHAVIOR_SCENARIOS, WorldTopic, BehaviorScenario } from '../data/otherModules';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

interface WorldAndValuesModuleViewProps {
  onEarnStar: () => void;
}

export const WorldAndValuesModuleView: React.FC<WorldAndValuesModuleViewProps> = ({ onEarnStar }) => {
  const [activeTab, setActiveTab] = useState<'world' | 'behavior'>('world');
  const [selectedTopic, setSelectedTopic] = useState<WorldTopic>(WORLD_TOPICS[0]);
  const [selectedScenario, setSelectedScenario] = useState<BehaviorScenario>(BEHAVIOR_SCENARIOS[0]);
  const [scenarioAnswer, setScenarioAnswer] = useState<'A' | 'B' | null>(null);

  const speak = (text: string) => {
    soundEngine.playPop(520);
    soundEngine.speakArabic(text);
  };

  const triggerReward = () => {
    soundEngine.playSuccess();
    onEarnStar();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  return (
    <div className="space-y-6">
      {/* Module Navigation Card */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <span className="text-3xl">🌱</span>
              <span>اكْتَشِفِ العَالَمَ وَالسُّلُوكَ وَالقِيَم</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              التعرف على جسم الإنسان، الكائنات الحية، البيئة المحيطة، وغرس مكارم الأخلاق والسلوكيات الحميدة.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('world'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                activeTab === 'world' ? 'bg-emerald-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Globe2 className="w-4 h-4" />
              <span>اكتشف العالم</span>
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('behavior'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                activeTab === 'behavior' ? 'bg-rose-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <HeartHandshake className="w-4 h-4" />
              <span>السلوك والقيم الإسلامية</span>
            </button>
          </div>
        </div>

        {/* Tab 1: World Discovery */}
        {activeTab === 'world' && (
          <div className="pt-6 space-y-6">
            {/* Topic Chips */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              {WORLD_TOPICS.map(t => {
                const isSelected = t.id === selectedTopic.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => {
                      soundEngine.playPop(480);
                      setSelectedTopic(t);
                      speak(`${t.title}.. ${t.summary}`);
                    }}
                    className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap border-2 transition-all flex items-center gap-2 ${
                      isSelected
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>{t.emoji}</span>
                    <span>{t.title}</span>
                  </button>
                );
              })}
            </div>

            {/* Selected Topic Arena */}
            <div className="p-6 bg-gradient-to-tr from-emerald-50 to-teal-50 rounded-3xl border border-emerald-200 space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h4 className="text-xl font-bold text-emerald-900 flex items-center gap-2">
                    <span>{selectedTopic.emoji}</span>
                    <span>{selectedTopic.title}</span>
                  </h4>
                  <p className="text-sm text-slate-700 mt-1 font-medium">
                    {selectedTopic.summary}
                  </p>
                </div>
                <button
                  onClick={() => speak(`${selectedTopic.title}.. ${selectedTopic.summary}`)}
                  className="p-2.5 bg-white rounded-xl shadow-xs border border-emerald-200 text-emerald-700"
                >
                  <Volume2 className="w-5 h-5" />
                </button>
              </div>

              {/* Key Items Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-2">
                {selectedTopic.keyItems.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => speak(`${item.name}.. ${item.detail}`)}
                    className="p-4 bg-white rounded-2xl border border-emerald-100 hover:border-emerald-300 transition-colors cursor-pointer space-y-1"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{item.emoji}</span>
                      <span className="font-bold text-slate-800 text-sm">{item.name}</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed font-medium">
                      {item.detail}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Topic Mini Question */}
            <div className="p-6 bg-white rounded-3xl border-2 border-slate-200 space-y-4">
              <h5 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <span>🤔</span>
                <span>سُؤَالُ التَّفْكِير: {selectedTopic.quizQuestion}</span>
              </h5>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {selectedTopic.quizOptions.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      if (opt.isCorrect) {
                        triggerReward();
                        speak('أحسنت يا بطل! إجابة صحيحة وذكية!');
                      } else {
                        soundEngine.playGentleBoing();
                        speak('فكّر جيداً وحاول مرة أخرى!');
                      }
                    }}
                    className="p-3 rounded-2xl border-2 border-slate-200 hover:border-emerald-400 bg-slate-50 hover:bg-emerald-50 text-slate-800 font-bold text-xs text-right transition-colors"
                  >
                    {opt.text}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Behavior & Values */}
        {activeTab === 'behavior' && (
          <div className="pt-6 space-y-6">
            {/* Scenarios Ribbon */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              {BEHAVIOR_SCENARIOS.map(sc => {
                const isSelected = sc.id === selectedScenario.id;
                return (
                  <button
                    key={sc.id}
                    onClick={() => {
                      soundEngine.playPop(480);
                      setSelectedScenario(sc);
                      setScenarioAnswer(null);
                      speak(`${sc.title}.. ${sc.situation}`);
                    }}
                    className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap border-2 transition-all flex items-center gap-2 ${
                      isSelected
                        ? 'bg-rose-50 border-rose-500 text-rose-800 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>{sc.emoji}</span>
                    <span>{sc.title}</span>
                  </button>
                );
              })}
            </div>

            {/* Selected Scenario Arena */}
            <div className="p-6 bg-rose-50/70 border border-rose-200 rounded-3xl space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <span className="px-3 py-1 bg-rose-500 text-white text-xs font-bold rounded-xl inline-block mb-2">
                    القِيمَة: {selectedScenario.virtue}
                  </span>
                  <h4 className="text-lg font-bold text-slate-800">
                    {selectedScenario.situation}
                  </h4>
                </div>
                <button
                  onClick={() => speak(selectedScenario.situation)}
                  className="p-2.5 bg-white rounded-xl shadow-xs border border-rose-200 text-rose-600"
                >
                  <Volume2 className="w-5 h-5" />
                </button>
              </div>

              {/* Two Choices */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {/* Choice A */}
                <button
                  onClick={() => {
                    setScenarioAnswer('A');
                    if (selectedScenario.choiceA.isCorrect) {
                      triggerReward();
                      speak(selectedScenario.choiceA.feedback);
                    } else {
                      soundEngine.playGentleBoing();
                      speak(selectedScenario.choiceA.feedback);
                    }
                  }}
                  className={`p-5 rounded-3xl border-2 text-right transition-all card-3d ${
                    scenarioAnswer === 'A'
                      ? selectedScenario.choiceA.isCorrect
                        ? 'bg-emerald-50 border-emerald-400 ring-4 ring-emerald-100'
                        : 'bg-red-50 border-red-400'
                      : 'bg-white border-slate-200 hover:border-rose-300'
                  }`}
                >
                  <span className="font-bold text-sm text-slate-800 block">
                    {selectedScenario.choiceA.text}
                  </span>
                  {scenarioAnswer === 'A' && (
                    <span className="text-xs font-bold text-slate-600 block mt-2 pt-2 border-t border-slate-100">
                      {selectedScenario.choiceA.feedback}
                    </span>
                  )}
                </button>

                {/* Choice B */}
                <button
                  onClick={() => {
                    setScenarioAnswer('B');
                    if (selectedScenario.choiceB.isCorrect) {
                      triggerReward();
                      speak(selectedScenario.choiceB.feedback);
                    } else {
                      soundEngine.playGentleBoing();
                      speak(selectedScenario.choiceB.feedback);
                    }
                  }}
                  className={`p-5 rounded-3xl border-2 text-right transition-all card-3d ${
                    scenarioAnswer === 'B'
                      ? selectedScenario.choiceB.isCorrect
                        ? 'bg-emerald-50 border-emerald-400 ring-4 ring-emerald-100'
                        : 'bg-red-50 border-red-400'
                      : 'bg-white border-slate-200 hover:border-rose-300'
                  }`}
                >
                  <span className="font-bold text-sm text-slate-800 block">
                    {selectedScenario.choiceB.text}
                  </span>
                  {scenarioAnswer === 'B' && (
                    <span className="text-xs font-bold text-slate-600 block mt-2 pt-2 border-t border-slate-100">
                      {selectedScenario.choiceB.feedback}
                    </span>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
