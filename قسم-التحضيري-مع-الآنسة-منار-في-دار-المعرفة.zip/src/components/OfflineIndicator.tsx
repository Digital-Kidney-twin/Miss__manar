import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-500/95 backdrop-blur-md px-4 py-2 text-sm font-bold text-white shadow-2xl border border-amber-300 animate-bounce">
      <WifiOff className="w-4 h-4 text-white" />
      <span>وضع بدون إنترنت — التطبيق يعمل بكفاءة وبشكل كامل من الذاكرة المحلية</span>
    </div>
  );
};
