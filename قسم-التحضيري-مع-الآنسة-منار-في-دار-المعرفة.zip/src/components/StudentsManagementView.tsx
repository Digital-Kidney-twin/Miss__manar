import React, { useState, useEffect } from 'react';
import { 
  UserPlus, 
  Search, 
  Sparkles, 
  Volume2, 
  Trash2, 
  Edit3, 
  Dices, 
  Download, 
  Upload, 
  RotateCcw, 
  Star, 
  Check, 
  X, 
  Play, 
  Trophy,
  Users
} from 'lucide-react';
import { Student, PUPIL_CHARACTERS, PupilCharacter } from '../types/student';
import { studentDB } from '../utils/studentStorage';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

interface StudentsManagementViewProps {
  onNavigateToGames?: () => void;
}

export const StudentsManagementView: React.FC<StudentsManagementViewProps> = ({ onNavigateToGames }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [activeStudentId, setActiveStudentId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [genderFilter, setGenderFilter] = useState<'all' | 'boy' | 'girl' | 'present'>('all');

  // Modal States
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [formName, setFormName] = useState('');
  const [formGender, setFormGender] = useState<'boy' | 'girl'>('boy');
  const [formCharacterId, setFormCharacterId] = useState('lion');
  const [formNotes, setFormNotes] = useState('');

  // Spotlight / Raffle Modal
  const [spotlightStudent, setSpotlightStudent] = useState<Student | null>(null);
  const [isRaffling, setIsRaffling] = useState(false);

  // Backup Modal
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [backupMessage, setBackupMessage] = useState<string | null>(null);

  // Load students & subscribe to DB changes
  useEffect(() => {
    const refresh = () => {
      setStudents(studentDB.getAll());
      setActiveStudentId(studentDB.getActiveStudentId());
    };
    refresh();
    const unsubscribe = studentDB.subscribe(refresh);
    return () => unsubscribe();
  }, []);

  const openAddModal = () => {
    setEditingStudent(null);
    setFormName('');
    setFormGender('boy');
    setFormCharacterId('lion');
    setFormNotes('');
    setShowAddModal(true);
    soundEngine.playPop(520);
  };

  const openEditModal = (student: Student) => {
    setEditingStudent(student);
    setFormName(student.name);
    setFormGender(student.gender);
    setFormCharacterId(student.characterId);
    setFormNotes(student.notes || '');
    setShowAddModal(true);
    soundEngine.playPop(480);
  };

  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    if (editingStudent) {
      studentDB.updateStudent(editingStudent.id, {
        name: formName.trim(),
        gender: formGender,
        characterId: formCharacterId,
        notes: formNotes.trim()
      });
      soundEngine.playPop(600);
    } else {
      studentDB.addStudent({
        name: formName.trim(),
        gender: formGender,
        characterId: formCharacterId,
        notes: formNotes.trim()
      });
      soundEngine.playSuccess();
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.6 }
      });
    }

    setShowAddModal(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`هل أنتِ متأكدة من حذف التلميذ(ة) "${name}" من القائمة؟`)) {
      studentDB.deleteStudent(id);
      soundEngine.playPop(300);
    }
  };

  const handleAddStar = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    studentDB.addStars(id, 1);
    soundEngine.playPop(620);
    confetti({
      particleCount: 25,
      spread: 45,
      origin: { y: 0.7 }
    });
  };

  const handleRemoveStar = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    studentDB.addStars(id, -1);
    soundEngine.playPop(350);
  };

  const handleToggleAttendance = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    studentDB.toggleAttendance(id);
    soundEngine.playPop(450);
  };

  const speakStudentCheer = (student: Student) => {
    soundEngine.playPop(520);
    const cheer = student.gender === 'boy' 
      ? `أهلاً بالبطل ${student.name}! ${student.characterTitle} في قسم الآنسة منار!`
      : `أهلاً بالبطلة ${student.name}! ${student.characterTitle} في قسم الآنسة منار!`;
    soundEngine.speakArabic(cheer);
  };

  const handleSelectActiveTurn = (student: Student) => {
    studentDB.setActiveStudentId(student.id);
    soundEngine.playPop(580);
    speakStudentCheer(student);
  };

  // Turn-Taking Raffle / Random Picker
  const handleRandomRaffle = () => {
    const presentStudents = students.filter(s => s.isPresent);
    if (presentStudents.length === 0) {
      alert('لا يوجد تلاميذ حاضرون لاختيارهم!');
      return;
    }

    setIsRaffling(true);
    soundEngine.playPop(400);

    let counter = 0;
    const interval = setInterval(() => {
      counter++;
      const randomCandidate = presentStudents[Math.floor(Math.random() * presentStudents.length)];
      setSpotlightStudent(randomCandidate);
      soundEngine.playPop(350 + (counter % 5) * 60);

      if (counter > 12) {
        clearInterval(interval);
        const finalWinner = presentStudents[Math.floor(Math.random() * presentStudents.length)];
        setSpotlightStudent(finalWinner);
        studentDB.setActiveStudentId(finalWinner.id);
        setIsRaffling(false);
        soundEngine.playSuccess();
        confetti({
          particleCount: 80,
          spread: 80,
          origin: { y: 0.5 }
        });
        const cheer = finalWinner.gender === 'boy'
          ? `حان دور البطل ${finalWinner.name}! ${finalWinner.characterTitle}!`
          : `حان دور البطلة ${finalWinner.name}! ${finalWinner.characterTitle}!`;
        soundEngine.speakArabic(cheer);
      }
    }, 120);
  };

  // Filtered Students
  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchQuery.trim().toLowerCase()) ||
                          student.characterTitle.toLowerCase().includes(searchQuery.trim().toLowerCase());
    if (!matchesSearch) return false;

    if (genderFilter === 'boy') return student.gender === 'boy';
    if (genderFilter === 'girl') return student.gender === 'girl';
    if (genderFilter === 'present') return student.isPresent;
    return true;
  });

  const totalStars = students.reduce((acc, curr) => acc + curr.stars, 0);
  const presentCount = students.filter(s => s.isPresent).length;
  const activeStudent = students.find(s => s.id === activeStudentId);

  return (
    <div className="space-y-6 pb-16 text-right animate-fadeIn select-none font-['Tajawal',sans-serif]">
      {/* Top Welcome & Roster Stats Banner */}
      <div className="bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
        
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-bold border border-white/30 mb-3">
              <span>🏫 دار المعرفة</span>
              <span>•</span>
              <span>قسم الآنسة منار</span>
              <span>•</span>
              <span>قاعدة بيانات التلاميذ الدائمة</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
              أَبْطَالُ وَنُجُومُ قِسْمِ الآنسة مَنَار
            </h1>
            <p className="text-white/90 text-sm sm:text-base mt-2 max-w-2xl">
              إدارة أسماء التلاميذ، تخصيص الشخصيات والرسومات لكل بطل، نظام حفظ النجوم، وتنظيم الأدوار في الألعاب التفاعلية على Data Show.
            </p>
          </div>

          {/* Quick Stats Blocks */}
          <div className="grid grid-cols-3 gap-3 sm:gap-4 text-center">
            <div className="bg-white/15 backdrop-blur-md p-3 sm:p-4 rounded-2xl border border-white/20">
              <div className="text-2xl sm:text-3xl font-black text-white">{students.length}</div>
              <div className="text-xs text-white/80 font-bold mt-1">تلميذ مسجل</div>
            </div>
            <div className="bg-white/15 backdrop-blur-md p-3 sm:p-4 rounded-2xl border border-white/20">
              <div className="text-2xl sm:text-3xl font-black text-emerald-300">{presentCount}</div>
              <div className="text-xs text-white/80 font-bold mt-1">حاضر اليوم</div>
            </div>
            <div className="bg-white/15 backdrop-blur-md p-3 sm:p-4 rounded-2xl border border-white/20">
              <div className="text-2xl sm:text-3xl font-black text-amber-300 flex items-center justify-center gap-1">
                <span>⭐</span>
                <span>{totalStars}</span>
              </div>
              <div className="text-xs text-white/80 font-bold mt-1">نجمة محققة</div>
            </div>
          </div>
        </div>

        {/* Current Active Player Turn Highlight Banner */}
        {activeStudent && (
          <div className="mt-6 pt-5 border-t border-white/20 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/25 flex items-center justify-center text-3xl shadow-inner border border-white/40">
                {activeStudent.characterEmoji}
              </div>
              <div>
                <div className="text-xs font-bold text-amber-200 uppercase tracking-wider">🎯 دور التلميذ الحالي في الألعاب:</div>
                <div className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                  <span>{activeStudent.name}</span>
                  <span className="text-xs bg-white/25 px-2.5 py-0.5 rounded-full font-normal">
                    {activeStudent.characterTitle}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => speakStudentCheer(activeStudent)}
                className="px-3.5 py-2 bg-white/20 hover:bg-white/30 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-transform active:scale-95"
                title="تشجيع صوتي"
              >
                <Volume2 className="w-4 h-4" />
                <span>تشجيع</span>
              </button>
              {onNavigateToGames && (
                <button
                  onClick={onNavigateToGames}
                  className="px-4 py-2 bg-white text-rose-600 hover:bg-rose-50 rounded-xl text-xs sm:text-sm font-black flex items-center gap-1.5 shadow-md transition-transform active:scale-95"
                >
                  <Play className="w-4 h-4 fill-rose-600" />
                  <span>بدء اللعب بهذا التلميذ</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Action Bar: Add, Raffle, Search, Filters & Backups */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 shadow-sm border border-slate-200 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Main Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={openAddModal}
            className="px-5 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-black text-sm sm:text-base flex items-center gap-2 shadow-md transition-transform active:scale-95 cursor-pointer"
          >
            <UserPlus className="w-5 h-5" />
            <span>إضافة تلميذ جديد</span>
          </button>

          <button
            onClick={handleRandomRaffle}
            disabled={isRaffling}
            className="px-4 py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-2xl font-black text-sm sm:text-base flex items-center gap-2 shadow-md transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
            title="قرعة لاختيار تلميذ عشوائي للإجابة أو اللعب"
          >
            <Dices className="w-5 h-5" />
            <span>قرعة الأدوار 🎲</span>
          </button>

          <button
            onClick={() => setShowBackupModal(true)}
            className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl font-bold text-sm transition-transform active:scale-95 flex items-center gap-1.5"
            title="حفظ وتصدير قاعدة البيانات كنسخة احتياطية"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span className="hidden sm:inline">نسخ احتياطي</span>
          </button>

          <button
            onClick={() => {
              if (window.confirm('هل ترغبين في استعادة القائمة الافتراضية مع النماذج؟')) {
                studentDB.resetToDefault();
                soundEngine.playPop(500);
              }
            }}
            className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl font-bold text-sm transition-transform active:scale-95"
            title="استعادة نماذج التلاميذ الافتراضية"
          >
            <RotateCcw className="w-4 h-4 text-slate-500" />
          </button>
        </div>

        {/* Search & Gender Filters */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1 sm:w-64">
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="ابحث عن اسم أو شخصية..."
              className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white text-right"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl">
            <button
              onClick={() => setGenderFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                genderFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              الكل ({students.length})
            </button>
            <button
              onClick={() => setGenderFilter('boy')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                genderFilter === 'boy' ? 'bg-sky-500 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              أولاد 👦
            </button>
            <button
              onClick={() => setGenderFilter('girl')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                genderFilter === 'girl' ? 'bg-pink-500 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              بنات 👧
            </button>
            <button
              onClick={() => setGenderFilter('present')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                genderFilter === 'present' ? 'bg-emerald-500 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              حاضرون ✅
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Student Cards */}
      {filteredStudents.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border-2 border-dashed border-slate-200 space-y-4">
          <div className="w-16 h-16 mx-auto bg-rose-50 text-rose-500 rounded-3xl flex items-center justify-center text-3xl">
            🎒
          </div>
          <h3 className="text-xl font-bold text-slate-800">لا يوجد تلاميذ مطابقون للبحث</h3>
          <p className="text-slate-500 text-sm max-w-sm mx-auto">
            يمكنكِ إضافة تلميذ جديد بالضغط على زر "إضافة تلميذ جديد" أعلاه.
          </p>
          <button
            onClick={openAddModal}
            className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-2xl text-sm transition-transform active:scale-95 inline-flex items-center gap-2"
          >
            <UserPlus className="w-4 h-4" />
            <span>إضافة تلميذ الآن</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-5">
          {filteredStudents.map(student => {
            const charPreset = PUPIL_CHARACTERS.find(c => c.id === student.characterId) || PUPIL_CHARACTERS[0];
            const isActiveTurn = activeStudentId === student.id;

            return (
              <div
                key={student.id}
                className={`bg-white rounded-3xl p-5 border-2 transition-all relative overflow-hidden flex flex-col justify-between group shadow-sm hover:shadow-md ${
                  isActiveTurn
                    ? 'border-amber-400 ring-4 ring-amber-100 bg-amber-50/20'
                    : student.isPresent
                    ? 'border-slate-200 hover:border-rose-300'
                    : 'border-slate-200 opacity-60 bg-slate-50'
                }`}
              >
                {/* Active turn badge */}
                {isActiveTurn && (
                  <div className="absolute top-0 right-0 bg-gradient-to-l from-amber-500 to-orange-500 text-white text-[11px] font-black px-4 py-1 rounded-bl-2xl shadow-xs flex items-center gap-1">
                    <span>🎯</span>
                    <span>الدور الحالي في اللعب</span>
                  </div>
                )}

                <div>
                  {/* Top Row: Character Badge + Presence Toggle */}
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div className="flex items-center gap-3">
                      {/* Character Avatar Drawing Representation */}
                      <div className={`w-16 h-16 rounded-3xl flex items-center justify-center text-4xl shadow-inner border-2 ${charPreset.badgeBorder} ${charPreset.avatarBg} transition-transform group-hover:scale-105`}>
                        {charPreset.emoji}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-2xl font-black text-slate-900 leading-tight">
                            {student.name}
                          </h3>
                          <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${
                            student.gender === 'boy' ? 'bg-sky-100 text-sky-700' : 'bg-pink-100 text-pink-700'
                          }`}>
                            {student.gender === 'boy' ? 'ولد 👦' : 'بنت 👧'}
                          </span>
                        </div>
                        <div className="text-xs font-bold text-slate-500 flex items-center gap-1 mt-0.5">
                          <span>{charPreset.name}</span>
                          <span>•</span>
                          <span className="text-rose-600">{student.characterTitle}</span>
                        </div>
                      </div>
                    </div>

                    {/* Attendance Pill */}
                    <button
                      onClick={e => handleToggleAttendance(student.id, e)}
                      className={`text-xs px-2.5 py-1 rounded-xl font-bold flex items-center gap-1 transition-all ${
                        student.isPresent
                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                          : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                      }`}
                      title={student.isPresent ? 'اضغط لتعيين غائب' : 'اضغط لتعيين حاضر'}
                    >
                      {student.isPresent ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>حاضر</span>
                        </>
                      ) : (
                        <>
                          <X className="w-3.5 h-3.5" />
                          <span>غائب</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Notes if any */}
                  {student.notes && (
                    <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2.5 text-xs text-slate-600 mb-3 leading-relaxed">
                      <span className="font-bold text-slate-700 ml-1">📝 ملاحظة:</span>
                      {student.notes}
                    </div>
                  )}
                </div>

                {/* Bottom Row: Stars counter & Interactive actions */}
                <div className="pt-3 border-t border-slate-100 mt-2 space-y-3">
                  {/* Stars Bar with +/- buttons */}
                  <div className="flex items-center justify-between bg-amber-50/80 border border-amber-200/80 rounded-2xl px-3 py-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">⭐</span>
                      <div>
                        <span className="text-lg font-black text-amber-900 font-mono tabular-nums">
                          {student.stars}
                        </span>
                        <span className="text-xs text-amber-700 font-bold mr-1">نجمة</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={e => handleRemoveStar(student.id, e)}
                        className="w-8 h-8 rounded-xl bg-white hover:bg-rose-50 text-slate-700 hover:text-rose-600 font-black text-base flex items-center justify-center border border-slate-200 shadow-xs transition-transform active:scale-90"
                        title="إنقاص نجمة"
                      >
                        -
                      </button>
                      <button
                        onClick={e => handleAddStar(student.id, e)}
                        className="px-3 h-8 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-xs flex items-center gap-1 shadow-xs transition-transform active:scale-95"
                        title="إضافة نجمة ومكافأة"
                      >
                        <span>+1</span>
                        <span>⭐</span>
                      </button>
                    </div>
                  </div>

                  {/* Action Buttons: Audio, Turn, Edit, Delete */}
                  <div className="flex items-center justify-between gap-1.5 text-xs">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => speakStudentCheer(student)}
                        className="p-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-600 rounded-xl transition-all"
                        title="سماع الترحيب والتشجيع"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleSelectActiveTurn(student)}
                        className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1 transition-all ${
                          isActiveTurn
                            ? 'bg-amber-500 text-white shadow-xs'
                            : 'bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-amber-800'
                        }`}
                        title="تعيين هذا التلميذ ليكون دوره في الألعاب"
                      >
                        <span>🎯</span>
                        <span>{isActiveTurn ? 'دوره الآن' : 'تعيين دوره'}</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => openEditModal(student)}
                        className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
                        title="تعديل بيانات التلميذ والشخصية"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(student.id, student.name)}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                        title="حذف التلميذ"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal: Add or Edit Student */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
                <span>{editingStudent ? '✏️ تعديل تلميذ(ة)' : '➕ إضافة تلميذ(ة) جديد(ة)'}</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveStudent} className="space-y-4">
              {/* Name input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  اسم التلميذ(ة) الكامل <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder="مثال: يوسف، خديجة، محمد علي..."
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white text-right"
                  autoFocus
                />
              </div>

              {/* Gender selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  الجنس
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormGender('boy')}
                    className={`py-3 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 border-2 transition-all ${
                      formGender === 'boy'
                        ? 'border-sky-500 bg-sky-50 text-sky-800 shadow-sm'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-lg">👦</span>
                    <span>ولد (بطل)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormGender('girl')}
                    className={`py-3 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 border-2 transition-all ${
                      formGender === 'girl'
                        ? 'border-pink-500 bg-pink-50 text-pink-800 shadow-sm'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-lg">👧</span>
                    <span>بنت (بطلة)</span>
                  </button>
                </div>
              </div>

              {/* Character / Drawing Selector */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    اختر شخصية / رسمة تمثل التلميذ(ة) 🎨
                  </label>
                  <span className="text-[11px] text-rose-600 font-bold">
                    {PUPIL_CHARACTERS.find(c => c.id === formCharacterId)?.name}
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-2.5 max-h-48 overflow-y-auto p-1.5 bg-slate-50 rounded-2xl border border-slate-200">
                  {PUPIL_CHARACTERS.map(char => (
                    <button
                      type="button"
                      key={char.id}
                      onClick={() => setFormCharacterId(char.id)}
                      className={`p-2.5 rounded-2xl flex flex-col items-center text-center transition-all border-2 ${
                        formCharacterId === char.id
                          ? 'border-rose-500 bg-white shadow-md scale-102 ring-2 ring-rose-200'
                          : 'border-transparent bg-white/70 hover:bg-white hover:border-slate-200'
                      }`}
                    >
                      <span className="text-3xl mb-1">{char.emoji}</span>
                      <span className="text-[11px] font-bold text-slate-800 truncate w-full">
                        {char.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  ملاحظات أو مهارة متميزة (اختياري)
                </label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  placeholder="مثال: سريع الحفظ، يحب الرياضيات، رسمه جميل..."
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white text-right"
                />
              </div>

              {/* Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-sm"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-black text-sm shadow-md transition-transform active:scale-95"
                >
                  {editingStudent ? 'حفظ التعديلات' : 'إضافة التلميذ(ة)'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Spotlight / Raffle Winner Modal */}
      {spotlightStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-gradient-to-b from-white via-amber-50 to-orange-50 rounded-3xl max-w-md w-full p-8 text-center shadow-2xl border-4 border-amber-400 relative overflow-hidden">
            <div className="absolute top-2 left-2">
              <button
                onClick={() => setSpotlightStudent(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <div className="inline-flex items-center gap-1.5 bg-amber-400/30 text-amber-900 px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider mb-4">
              <span>🎲 قرعة اختيار الأدوار</span>
            </div>

            {/* Huge Character Avatar */}
            <div className="w-28 h-28 mx-auto rounded-3xl bg-white shadow-xl flex items-center justify-center text-7xl border-4 border-amber-400 animate-bounce mb-4">
              {spotlightStudent.characterEmoji}
            </div>

            <h2 className="text-4xl font-black text-slate-900 font-['Tajawal',sans-serif]">
              {spotlightStudent.name}
            </h2>

            <div className="text-base font-bold text-rose-600 mt-1">
              {spotlightStudent.characterTitle}
            </div>

            <div className="mt-4 p-3 bg-white/80 rounded-2xl border border-amber-200 inline-flex items-center gap-2 text-sm font-bold text-amber-900">
              <span>⭐ رصيد النجوم الحالي:</span>
              <span className="font-mono text-base font-black">{spotlightStudent.stars}</span>
            </div>

            <p className="text-slate-600 text-xs mt-4">
              تم تعيين {spotlightStudent.name} ليكون دوره الحالي في الألعاب والأنشطة!
            </p>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => speakStudentCheer(spotlightStudent)}
                className="px-4 py-2.5 bg-white hover:bg-amber-100 text-slate-800 rounded-xl font-bold text-sm border border-slate-200 flex items-center gap-2"
              >
                <Volume2 className="w-4 h-4 text-rose-600" />
                <span>تشجيع صوتي</span>
              </button>

              {onNavigateToGames && (
                <button
                  onClick={() => {
                    setSpotlightStudent(null);
                    onNavigateToGames();
                  }}
                  className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-black text-sm shadow-md transition-transform active:scale-95 flex items-center gap-2"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>الانتقال للألعاب بالدور</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Backup & Export Modal */}
      {showBackupModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <span>💾 الحفظ الدائم والنسخ الاحتياطي</span>
              </h3>
              <button
                onClick={() => {
                  setShowBackupModal(false);
                  setBackupMessage(null);
                }}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              يتم حفظ التلاميذ ونجومهم تلقائياً في المتصفح. يمكنكِ أيضاً تنزيل ملف نصي (JSON) للاحتفاظ بنسخة على حاسوبكِ أو نقله إلى جهاز آخر.
            </p>

            {backupMessage && (
              <div className="p-3 bg-emerald-50 text-emerald-800 rounded-xl text-xs font-bold border border-emerald-200">
                {backupMessage}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  const data = studentDB.exportBackup();
                  const blob = new Blob([data], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `قائمة_تلاميذ_قسم_الآنسة_منار_${new Date().toISOString().split('T')[0]}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                  setBackupMessage('تم تنزيل ملف النسخة الاحتياطية بنجاح! ✅');
                  soundEngine.playSuccess();
                }}
                className="py-3 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>تنزيل ملف النسخة الاحتياطية</span>
              </button>

              <label className="py-3 px-4 bg-slate-800 hover:bg-slate-900 text-white rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-95 cursor-pointer text-center">
                <Upload className="w-4 h-4" />
                <span>استيراد من ملف JSON</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  className="hidden"
                  onChange={e => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = evt => {
                      const content = evt.target?.result as string;
                      if (content) {
                        const res = studentDB.importBackup(content);
                        if (res.success) {
                          setBackupMessage(`تم استيراد ${res.count} تلميذ بنجاح! ✅`);
                          soundEngine.playSuccess();
                        } else {
                          setBackupMessage(`خطأ في الاستيراد: ${res.error}`);
                          soundEngine.playGentleBoing();
                        }
                      }
                    };
                    reader.readAsText(file);
                  }}
                />
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
