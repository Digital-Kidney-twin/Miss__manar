import React, { useState } from 'react';
import { 
  Volume2, 
  Sparkles, 
  CheckCircle2, 
  RotateCcw,
  FlaskConical,
  Sprout,
  Waves,
  Magnet,
  SunMoon
} from 'lucide-react';
import { 
  FLOATING_ITEMS, 
  PLANT_LIFECYCLE, 
  WATER_STATES, 
  MAGNET_ITEMS,
  FloatingExperimentItem,
  PlantStage,
  MatterState,
  MagnetItem
} from '../data/scienceLessons';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

interface ScienceModuleViewProps {
  onEarnStar: () => void;
}

export const ScienceModuleView: React.FC<ScienceModuleViewProps> = ({ onEarnStar }) => {
  const [activeTab, setActiveTab] = useState<'floating' | 'plant' | 'water_states' | 'magnet'>('floating');
  const [testedFloatingItems, setTestedFloatingItems] = useState<string[]>([]);
  const [currentTestedItem, setCurrentTestedItem] = useState<FloatingExperimentItem | null>(null);
  const [currentPlantStep, setCurrentPlantStep] = useState(0);
  const [magnetTested, setMagnetTested] = useState<string[]>([]);

  const speak = (text: string) => {
    soundEngine.playPop(520);
    soundEngine.speakArabic(text);
  };

  const triggerReward = () => {
    soundEngine.playSuccess();
    onEarnStar();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  const testFloatingItem = (item: FloatingExperimentItem) => {
    setCurrentTestedItem(item);
    if (!testedFloatingItems.includes(item.id)) {
      setTestedFloatingItems(prev => [...prev, item.id]);
    }
    soundEngine.playPop(480);
    const resultText = item.behavior === 'floats' ? 'يَطْفُو فَوْقَ المَاء' : 'يَغْرَقُ فِي القَاع';
    speak(`${item.name}.. ${resultText}! ${item.explanation}`);

    if (testedFloatingItems.length + 1 >= FLOATING_ITEMS.length) {
      setTimeout(triggerReward, 800);
    }
  };

  return (
    <div className="space-y-6">
      {/* Module Navigation Card */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <span className="text-3xl">🔬</span>
              <span>الإِيقَاظُ العِلْمِيُّ وَالتَّجَارِبُ المَرِحَة</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              تجارب استكشافية بسيطة: يطفو ويغرق، دورة حياة النبات، حالات الماء، والمغناطيس.
            </p>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('floating'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'floating' ? 'bg-sky-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Waves className="w-4 h-4" />
              <span>يطفو أم يغرق؟</span>
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('plant'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'plant' ? 'bg-emerald-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Sprout className="w-4 h-4" />
              <span>دورة حياة النبات</span>
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('water_states'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'water_states' ? 'bg-cyan-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <FlaskConical className="w-4 h-4" />
              <span>حالات الماء</span>
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('magnet'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'magnet' ? 'bg-rose-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Magnet className="w-4 h-4" />
              <span>المغناطيس العجيب</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Floating vs Sinking Interactive Tank */}
        {activeTab === 'floating' && (
          <div className="pt-6 space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h4 className="text-2xl font-bold text-slate-800">
                تَجْرِبَةُ حَوْضِ المَاء: هَلْ يَطْفُو أَمْ يَغْرَق؟ 🌊
              </h4>
              <p className="text-xs text-slate-500">
                المعلمة تطلب من الطفل اختيار عنصر من السلة ورميه داخل حوض الماء لمشاهدة ما يحدث!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
              {/* Interactive Water Tank Stage */}
              <div className="md:col-span-7 bg-gradient-to-b from-sky-100 via-sky-200 to-sky-400 rounded-3xl border-4 border-sky-300 p-6 h-80 relative overflow-hidden shadow-inner flex flex-col justify-between">
                {/* Surface level */}
                <div className="flex items-center justify-between text-xs font-bold text-sky-800 bg-white/60 px-3 py-1 rounded-xl">
                  <span>سطح الماء (المواد التي تطفو) 🪶</span>
                  <span>السطح 〰️</span>
                </div>

                {/* Floating zone */}
                <div className="h-24 flex items-center justify-center gap-3">
                  {currentTestedItem && currentTestedItem.behavior === 'floats' && (
                    <div className="text-center animate-bounce-slow">
                      <span className="text-6xl drop-shadow-md block">{currentTestedItem.emoji}</span>
                      <span className="text-xs font-extrabold bg-emerald-500 text-white px-3 py-0.5 rounded-full shadow-xs mt-1 inline-block">
                        يَطْفُو!
                      </span>
                    </div>
                  )}
                </div>

                {/* Bottom sinking zone */}
                <div className="border-t-2 border-dashed border-sky-400/80 pt-2 flex items-center justify-between text-xs font-bold text-sky-900 bg-sky-500/20 px-3 py-1 rounded-xl">
                  <span>قاع الحوض (المواد التي تغرق) 🪨</span>
                  <span>القاع ⚓</span>
                </div>

                {/* Sunk element */}
                <div className="h-20 flex items-center justify-center">
                  {currentTestedItem && currentTestedItem.behavior === 'sinks' && (
                    <div className="text-center animate-pulse-slow">
                      <span className="text-6xl drop-shadow-md block">{currentTestedItem.emoji}</span>
                      <span className="text-xs font-extrabold bg-rose-500 text-white px-3 py-0.5 rounded-full shadow-xs mt-1 inline-block">
                        يَغْرَقُ فِي القَاع!
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Items Shelf to Pick From */}
              <div className="md:col-span-5 space-y-4">
                <h5 className="text-sm font-bold text-slate-700">
                  اختر عنصراً من الرف لاختباره:
                </h5>
                <div className="grid grid-cols-2 gap-3">
                  {FLOATING_ITEMS.map(item => {
                    const isTested = testedFloatingItems.includes(item.id);
                    return (
                      <button
                        key={item.id}
                        onClick={() => testFloatingItem(item)}
                        className={`p-3 rounded-2xl border-2 transition-all card-3d flex items-center gap-3 text-right ${
                          currentTestedItem?.id === item.id
                            ? 'bg-sky-100 border-sky-500 ring-2 ring-sky-300'
                            : 'bg-white border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <span className="text-3xl">{item.emoji}</span>
                        <div>
                          <span className="text-xs font-bold text-slate-800 block">{item.name}</span>
                          <span className={`text-[10px] font-bold ${item.behavior === 'floats' ? 'text-teal-600' : 'text-rose-600'}`}>
                            {isTested ? (item.behavior === 'floats' ? 'يَطْفُو' : 'يَغْرَق') : 'اضغط للتجربة'}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {currentTestedItem && (
                  <div className="p-4 bg-sky-50 rounded-2xl border border-sky-200 text-xs text-slate-700 font-medium leading-relaxed">
                    💡 <strong className="text-sky-950">التفسير العلمي:</strong> {currentTestedItem.explanation}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Plant Life Cycle */}
        {activeTab === 'plant' && (
          <div className="pt-6 space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h4 className="text-2xl font-bold text-slate-800">
                مَرَاحِلُ نُمُوِّ النَّبَاتِ وَدَوْرَةُ حَيَاتِه 🌱
              </h4>
              <p className="text-xs text-slate-500">
                كيف تصبح البذرة الصغيرة شجرة جميلة مثمرة؟
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {PLANT_LIFECYCLE.map((st, idx) => (
                <div
                  key={idx}
                  onClick={() => speak(`المرحلة ${st.step}.. ${st.title}.. ${st.description}`)}
                  className="p-6 bg-emerald-50/70 hover:bg-emerald-100/60 rounded-3xl border-2 border-emerald-200 card-3d cursor-pointer text-center space-y-3 transition-colors"
                >
                  <span className="px-3 py-1 bg-emerald-600 text-white rounded-xl text-xs font-bold inline-block">
                    المَرْحَلَة {st.step}
                  </span>
                  <span className="text-6xl block py-2">{st.emoji}</span>
                  <h5 className="text-base font-extrabold text-emerald-950 font-['Tajawal',sans-serif]">
                    {st.title}
                  </h5>
                  <p className="text-xs text-slate-600 font-medium leading-relaxed">
                    {st.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: States of Water */}
        {activeTab === 'water_states' && (
          <div className="pt-6 space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h4 className="text-2xl font-bold text-slate-800">
                حَالَاتُ المَاءِ الثَّلَاث: صَلْب، سَائِل، وَغَاز 🧊💧☁️
              </h4>
              <p className="text-xs text-slate-500">
                يتغير شكل الماء حسب درجة الحرارة!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {WATER_STATES.map((ws, idx) => (
                <div
                  key={idx}
                  onClick={() => speak(`${ws.name}.. مِثْل: ${ws.example}.. ${ws.detail}`)}
                  className="p-6 bg-cyan-50/70 hover:bg-cyan-100/60 rounded-3xl border-2 border-cyan-200 card-3d cursor-pointer text-center space-y-3 transition-colors"
                >
                  <span className="text-6xl block">{ws.emoji}</span>
                  <h5 className="text-lg font-extrabold text-cyan-950 font-['Tajawal',sans-serif]">
                    {ws.name}
                  </h5>
                  <div className="p-2 bg-white rounded-xl border border-cyan-200 text-sm font-bold text-cyan-800">
                    {ws.example}
                  </div>
                  <p className="text-xs text-slate-600 font-medium leading-relaxed">
                    {ws.detail}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Magnet */}
        {activeTab === 'magnet' && (
          <div className="pt-6 space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h4 className="text-2xl font-bold text-slate-800">
                المَغْنَاطِيسُ السِّحْرِيّ: مَاذَا يَجْذِب؟ 🧲
              </h4>
              <p className="text-xs text-slate-500">
                المغناطيس يجذب المعادن والحديد، ولا يجذب الخشب والبلاستيك والمطاط!
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {MAGNET_ITEMS.map((item, idx) => {
                const isTested = magnetTested.includes(item.name);
                return (
                  <button
                    key={idx}
                    onClick={() => {
                      if (!magnetTested.includes(item.name)) {
                        setMagnetTested(prev => [...prev, item.name]);
                      }
                      soundEngine.playPop(480);
                      const result = item.attracted ? 'يَنْجَذِبُ لِلْمَغْنَاطِيسِ لِأَنَّهُ مَصْنُوعٌ مِنَ الحَدِيد!' : 'لَا يَنْجَذِبُ لِأَنَّهُ لَيْسَ حَدِيداً!';
                      speak(`${item.name}.. ${result}`);
                    }}
                    className={`p-5 rounded-3xl border-2 text-center transition-all card-3d ${
                      isTested
                        ? item.attracted
                          ? 'bg-emerald-50 border-emerald-400'
                          : 'bg-rose-50 border-rose-300'
                        : 'bg-white border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-5xl block mb-2">{item.emoji}</span>
                    <span className="text-sm font-bold text-slate-800 block font-['Tajawal',sans-serif]">{item.name}</span>
                    <span className="text-xs text-slate-500 block">المادة: {item.material}</span>
                    {isTested && (
                      <span className={`mt-2 inline-block px-2.5 py-0.5 text-[10px] font-bold rounded-full ${
                        item.attracted ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'
                      }`}>
                        {item.attracted ? '🧲 يَجْذِبُهُ' : '❌ لَا يَجْذِبُهُ'}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
