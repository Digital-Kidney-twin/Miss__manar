import React, { useState } from 'react';
import { 
  Volume2, 
  Sparkles, 
  ArrowLeft, 
  ArrowRight, 
  CheckCircle2, 
  RotateCcw,
  BookOpen,
  Moon,
  Clock,
  Droplets
} from 'lucide-react';
import { 
  ISLAMIC_PILLARS, 
  FIVE_PRAYERS, 
  WUDU_STEPS, 
  SHORT_SURAHS,
  IslamicPillar, 
  PrayerItem, 
  WuduStep, 
  ShortSurah 
} from '../data/islamicLessons';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

interface IslamicModuleViewProps {
  onEarnStar: () => void;
}

export const IslamicModuleView: React.FC<IslamicModuleViewProps> = ({ onEarnStar }) => {
  const [activeTab, setActiveTab] = useState<'pillars' | 'prayers' | 'wudu' | 'surahs' | 'manners'>('pillars');
  const [selectedPillar, setSelectedPillar] = useState<IslamicPillar>(ISLAMIC_PILLARS[0]);
  const [currentWuduStep, setCurrentWuduStep] = useState(0);
  const [selectedSurah, setSelectedSurah] = useState<ShortSurah>(SHORT_SURAHS[0]);
  const [activeVerseIdx, setActiveVerseIdx] = useState<number | null>(null);

  const speak = (text: string) => {
    soundEngine.playPop(520);
    soundEngine.speakArabic(text);
  };

  const triggerReward = () => {
    soundEngine.playSuccess();
    onEarnStar();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  return (
    <div className="space-y-6">
      {/* Module Navigation Card */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <span className="text-3xl">🕌</span>
              <span>دُرُوسُ التَّرْبِيَةِ الإِسْلَامِيَّةِ لِلطِّفْلِ المُسْلِم</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              أساسيات ديني الجميل: أركان الإسلام، الصلوات الخمس، خطوات الوضوء، وقصار السور.
            </p>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('pillars'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                activeTab === 'pillars' ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              أركان الإسلام الخمسة
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('prayers'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                activeTab === 'prayers' ? 'bg-amber-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              الصلوات الخمس
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('wudu'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                activeTab === 'wudu' ? 'bg-sky-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              خطوات الوضوء
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('surahs'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                activeTab === 'surahs' ? 'bg-rose-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              قصار السور
            </button>
            <button
              onClick={() => { soundEngine.playPop(440); setActiveTab('manners'); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                activeTab === 'manners' ? 'bg-purple-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              أذكاري وآدابي
            </button>
          </div>
        </div>

        {/* Tab 1: 5 Pillars of Islam */}
        {activeTab === 'pillars' && (
          <div className="pt-6 space-y-6">
            {/* Pillars Chips */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {ISLAMIC_PILLARS.map(p => {
                const isSelected = p.number === selectedPillar.number;
                return (
                  <button
                    key={p.number}
                    onClick={() => {
                      soundEngine.playPop(480);
                      setSelectedPillar(p);
                      speak(`${p.title}.. ${p.name}.. ${p.arabicPillar}`);
                    }}
                    className={`p-4 rounded-2xl border-2 transition-all card-3d text-center flex flex-col items-center gap-2 ${
                      isSelected
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-sm scale-102'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-4xl">{p.emoji}</span>
                    <span className="text-xs font-bold text-emerald-600">{p.title}</span>
                    <span className="text-sm font-extrabold font-['Tajawal',sans-serif]">{p.name}</span>
                  </button>
                );
              })}
            </div>

            {/* Selected Pillar Detailed Arena */}
            <div className="p-8 bg-gradient-to-tr from-emerald-50 to-teal-50 rounded-3xl border-2 border-emerald-200 text-center space-y-4">
              <span className="text-6xl inline-block animate-bounce-slow">
                {selectedPillar.emoji}
              </span>

              <div>
                <span className="text-xs font-bold px-3 py-1 bg-emerald-600 text-white rounded-full">
                  {selectedPillar.title}
                </span>
                <h4 className="text-3xl font-extrabold text-emerald-950 font-['Tajawal',sans-serif] mt-2">
                  {selectedPillar.arabicPillar}
                </h4>
              </div>

              <p className="text-base sm:text-lg text-slate-700 max-w-xl mx-auto font-medium leading-relaxed">
                {selectedPillar.childExplanation}
              </p>

              <div className="pt-2 flex items-center justify-center gap-3">
                <button
                  onClick={() => speak(`${selectedPillar.name}.. ${selectedPillar.arabicPillar}.. ${selectedPillar.childExplanation}`)}
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-bold text-xs flex items-center gap-2 shadow-xs btn-3d"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>استمع للشرح مع الآنسة منار 🔊</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: 5 Prayers */}
        {activeTab === 'prayers' && (
          <div className="pt-6 space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h4 className="text-2xl font-bold text-slate-800">
                الصَّلَوَاتُ الخَمْسُ المَفْرُوضَةُ فِي اليَوْمِ وَاللَّيْلَة 🕌
              </h4>
              <p className="text-xs text-slate-500">
                خمس صلوات جميلة نقف فيها بين يدي الله تعالى وندعوه بالخير والنجاح.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {FIVE_PRAYERS.map((pr, idx) => (
                <div
                  key={idx}
                  onClick={() => speak(`${pr.name}.. عدد ركعاتها: ${pr.rakat} ركعات.. ${pr.timeText}`)}
                  className="p-5 bg-amber-50/70 hover:bg-amber-100/60 rounded-3xl border-2 border-amber-200 card-3d cursor-pointer space-y-3 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-3xl">{pr.icon}</span>
                    <span className="px-3 py-1 bg-amber-500 text-white rounded-xl text-xs font-bold">
                      {pr.rakat} رَكَعَات
                    </span>
                  </div>

                  <h5 className="text-lg font-extrabold text-amber-950 font-['Tajawal',sans-serif]">
                    {pr.name}
                  </h5>

                  <p className="text-xs text-slate-600 font-medium leading-relaxed">
                    {pr.timeText}
                  </p>

                  <div className="pt-2 border-t border-amber-200/60 flex items-center justify-between text-xs text-amber-800 font-bold">
                    <span>{pr.description}</span>
                    <Volume2 className="w-4 h-4 text-amber-600 shrink-0" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Steps of Wudu */}
        {activeTab === 'wudu' && (
          <div className="pt-6 space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h4 className="text-2xl font-bold text-slate-800">
                كَيْفَ أَتَوَضَّأُ لِلصَّلَاةِ خَطْوَةً بِخَطْوَة؟ 💧
              </h4>
              <p className="text-xs text-slate-500">
                الوضوء نظافة وطهارة ونور للوجه والقلب.
              </p>
            </div>

            {/* Stepper display */}
            <div className="max-w-xl mx-auto p-8 bg-sky-50 rounded-3xl border-2 border-sky-200 text-center space-y-6">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 bg-sky-500 text-white rounded-xl text-xs font-bold">
                  الخُطْوَة {currentWuduStep + 1} مِنْ {WUDU_STEPS.length}
                </span>
                <span className="text-xs font-bold text-sky-800">
                  {WUDU_STEPS[currentWuduStep].repeatText}
                </span>
              </div>

              <span className="text-7xl block animate-bounce-slow">
                {WUDU_STEPS[currentWuduStep].emoji}
              </span>

              <div className="space-y-2">
                <h5 className="text-2xl font-extrabold text-sky-950 font-['Tajawal',sans-serif]">
                  {WUDU_STEPS[currentWuduStep].title}
                </h5>
                <p className="text-base text-slate-700 font-medium">
                  {WUDU_STEPS[currentWuduStep].actionText}
                </p>
              </div>

              {/* Step Navigation Controls */}
              <div className="flex items-center justify-center gap-4 pt-2">
                <button
                  onClick={() => {
                    const prev = (currentWuduStep - 1 + WUDU_STEPS.length) % WUDU_STEPS.length;
                    setCurrentWuduStep(prev);
                    speak(`${WUDU_STEPS[prev].title}.. ${WUDU_STEPS[prev].actionText}`);
                  }}
                  className="p-3 bg-white hover:bg-slate-100 rounded-2xl border border-sky-200 text-sky-700"
                  title="الخطوة السابقة"
                >
                  <ArrowRight className="w-5 h-5" />
                </button>

                <button
                  onClick={() => speak(`${WUDU_STEPS[currentWuduStep].title}.. ${WUDU_STEPS[currentWuduStep].actionText}`)}
                  className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white rounded-2xl font-bold text-xs flex items-center gap-2 shadow-xs"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>استمع للخطوة 🔊</span>
                </button>

                <button
                  onClick={() => {
                    const next = (currentWuduStep + 1) % WUDU_STEPS.length;
                    setCurrentWuduStep(next);
                    speak(`${WUDU_STEPS[next].title}.. ${WUDU_STEPS[next].actionText}`);
                    if (next === WUDU_STEPS.length - 1) triggerReward();
                  }}
                  className="p-3 bg-sky-500 hover:bg-sky-600 text-white rounded-2xl shadow-xs"
                  title="الخطوة التالية"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Short Surahs */}
        {activeTab === 'surahs' && (
          <div className="pt-6 space-y-6">
            {/* Surah Switcher */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              {SHORT_SURAHS.map(s => {
                const isSelected = s.id === selectedSurah.id;
                return (
                  <button
                    key={s.id}
                    onClick={() => {
                      soundEngine.playPop(480);
                      setSelectedSurah(s);
                      setActiveVerseIdx(null);
                    }}
                    className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap border-2 transition-all ${
                      isSelected
                        ? 'bg-rose-50 border-rose-500 text-rose-800 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    📖 {s.name}
                  </button>
                );
              })}
            </div>

            {/* Surah Reader Container */}
            <div className="p-8 bg-amber-50/50 rounded-3xl border-2 border-amber-200/80 text-center space-y-4 max-w-2xl mx-auto shadow-inner">
              <h4 className="text-2xl font-extrabold text-amber-900 font-['Tajawal',sans-serif]">
                {selectedSurah.name}
              </h4>

              <div className="space-y-3 pt-2">
                {selectedSurah.verses.map((verse, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setActiveVerseIdx(idx);
                      speak(verse);
                    }}
                    className={`p-3 rounded-2xl transition-all cursor-pointer text-xl sm:text-2xl font-['Tajawal',sans-serif] leading-loose ${
                      activeVerseIdx === idx
                        ? 'bg-amber-400 text-white font-extrabold shadow-sm scale-102'
                        : 'text-slate-800 hover:bg-amber-100/60'
                    }`}
                  >
                    {verse}
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-amber-200/60 text-xs font-bold text-amber-800">
                💡 اضغطي على أي آية لترديدها بصوت واضح مع الأطفال بالقسم
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Muslim Child Manners (أذكار وآداب) */}
        {activeTab === 'manners' && (
          <div className="pt-6 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {[
                { title: 'عِنْدَ البَدْءِ بِالأَكْل', saying: 'بِسْمِ اللَّه', icon: '🍽️', detail: 'نبدأ طعامنا باسم الله ونأكل بيميننا ومما يلينا' },
                { title: 'عِنْدَ الانْتِهَاءِ مِنَ الأَكْل', saying: 'الْحَمْدُ لِلَّه', icon: '🥣', detail: 'نشكر الله تعالى الذي أطعمنا وسقانا من غير حول منا ولا قوة' },
                { title: 'عِنْدَ لِقَاءِ الأَصْدِقَاء', saying: 'السَّلَامُ عَلَيْكُم', icon: '👋', detail: 'تحية الإسلام الجميلة التي تنشر السلام والمحبة' },
                { title: 'عِنْدَ العُطَاس', saying: 'الْحَمْدُ لِلَّه', icon: '🤧', detail: 'نحمد الله ويرد علينا صديقنا: يرحمك الله' },
                { title: 'عِنْدَ الخُرُوجِ مِنَ المَنْزِل', saying: 'بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّه', icon: '🚪', detail: 'يحفظنا الله في طريقنا إلى مدرستنا الجميلة' },
                { title: 'دُعَاءٌ لِلْوَالِدَيْن', saying: 'رَبِّ اغْفِرْ لِي وَلِوَالِدَيّ', icon: '👨‍👩‍👧', detail: 'ندعو لأمنا وأبينا بالرحمة والبركة في كل وقت' }
              ].map((m, idx) => (
                <div
                  key={idx}
                  onClick={() => speak(`${m.title}.. نَقُول: ${m.saying}.. ${m.detail}`)}
                  className="p-5 bg-purple-50/70 hover:bg-purple-100/60 rounded-3xl border-2 border-purple-200 card-3d cursor-pointer space-y-2 transition-colors text-center"
                >
                  <span className="text-4xl block mb-2">{m.icon}</span>
                  <span className="text-xs font-bold text-purple-700 block">{m.title}</span>
                  <div className="p-2 bg-white rounded-xl border border-purple-200 text-lg font-extrabold text-purple-950 font-['Tajawal',sans-serif]">
                    {m.saying}
                  </div>
                  <p className="text-xs text-slate-600 font-medium leading-relaxed pt-1">
                    {m.detail}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
