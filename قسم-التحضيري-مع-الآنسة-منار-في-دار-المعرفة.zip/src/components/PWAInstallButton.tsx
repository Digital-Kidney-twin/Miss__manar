import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Monitor, CheckCircle, X, HelpCircle, Smartphone, ExternalLink } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface PWAInstallButtonProps {
  variant?: 'navbar' | 'hero' | 'floating';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'navbar' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [installedNotice, setInstalledNotice] = useState(false);

  // If running in standalone mode, indicate that it's running as an installed desktop app
  if (isInstalled) {
    if (variant === 'hero') return null;
    return (
      <div 
        className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-700 text-xs font-bold"
        title="التطبيق مثبت ويعمل كبرنامج لسطح المكتب"
      >
        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
        <span>تطبيق مثبت (سطح المكتب)</span>
      </div>
    );
  }

  const handleInstallClick = async () => {
    soundEngine.playPop(520);
    if (isInstallable) {
      const outcome = await install();
      if (outcome) {
        soundEngine.playSuccess();
        setInstalledNotice(true);
        setTimeout(() => setInstalledNotice(false), 4000);
      }
    } else {
      // If the browser hasn't fired beforeinstallprompt yet (or user previously dismissed), show visual guidance modal
      setShowGuideModal(true);
    }
  };

  const renderButtonContent = () => {
    if (variant === 'hero') {
      return (
        <button
          onClick={handleInstallClick}
          className="px-6 py-4 sm:px-8 sm:py-5 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-700 hover:via-purple-700 hover:to-pink-700 text-white font-black text-lg sm:text-xl rounded-3xl shadow-2xl transition-all transform hover:scale-105 active:scale-95 flex items-center gap-3 border-2 border-white/70 cursor-pointer"
          title="تثبيت التطبيق مباشرة على سطح المكتب للحاسوب أو الجهاز اللوحي"
        >
          <Monitor className="w-6 h-6 text-amber-300 animate-pulse" />
          <span>تثبيت التطبيق على سطح المكتب</span>
          <Download className="w-5 h-5 text-white/90" />
        </button>
      );
    }

    // Default: Navbar variant
    return (
      <button
        onClick={handleInstallClick}
        className="inline-flex items-center gap-2 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white text-xs sm:text-sm font-black shadow-md hover:shadow-lg transition-all transform active:scale-95 border border-white/40 cursor-pointer"
        title="تثبيت المنصة كتطبيق على سطح المكتب (بدون الحاجة لمتصفح مستقبلاً)"
      >
        <Monitor className="w-4 h-4 text-amber-300" />
        <span>تثبيت التطبيق</span>
        <Download className="w-3.5 h-3.5" />
      </button>
    );
  };

  return (
    <>
      {renderButtonContent()}

      {/* Success Notification after install */}
      {installedNotice && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-bounce">
          <CheckCircle className="w-6 h-6 text-white" />
          <div>
            <div className="font-black text-sm">تم تثبيت التطبيق بنجاح! 🎉</div>
            <div className="text-xs text-emerald-100">ستجده الآن في قائمة البرامج وعلى سطح المكتب.</div>
          </div>
        </div>
      )}

      {/* Educational Desktop Installation Guide Modal */}
      {showGuideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border-4 border-indigo-100 relative text-right">
            {/* Close Button */}
            <button
              onClick={() => {
                soundEngine.playPop(350);
                setShowGuideModal(false);
              }}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-3 mb-5 border-b pb-4">
              <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                <Monitor className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900 font-['Tajawal',sans-serif]">
                  تثبيت التطبيق على سطح المكتب
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 font-medium">
                  لتشغيل قسم الآنسة منار بضغطة واحدة من شاشة الحاسوب وبملء الشاشة
                </p>
              </div>
            </div>

            {isIOS ? (
              /* iOS Safari Instructions */
              <div className="space-y-4 text-slate-700 text-sm">
                <div className="p-4 bg-indigo-50/80 rounded-2xl border border-indigo-100 space-y-2">
                  <div className="font-black text-indigo-900 flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-indigo-600" />
                    خطوات التثبيت على أجهزة iPad / iPhone:
                  </div>
                  <ol className="list-decimal list-inside space-y-1.5 pr-2 font-medium text-slate-600 text-xs sm:text-sm">
                    <li>اضغط على زر المشاركة <strong>(Share / مشاركة 📤)</strong> في شريط متصفح سفاري.</li>
                    <li>مرر للأسفل واضغط على <strong>«إضافة إلى الصفحة الرئيسية» (Add to Home Screen)</strong>.</li>
                    <li>اضغط على <strong>«إضافة» (Add)</strong> في الزاوية العلوية.</li>
                  </ol>
                </div>
              </div>
            ) : (
              /* Windows / Mac / Chrome / Edge Desktop Instructions */
              <div className="space-y-4 text-slate-700 text-sm">
                <div className="p-4 bg-indigo-50/80 rounded-2xl border border-indigo-100 space-y-3">
                  <div className="font-black text-indigo-900 flex items-center gap-2 text-base">
                    <span>🖥️</span> طريقة التثبيت السريعة على الكمبيوتر:
                  </div>

                  {/* Step 1 */}
                  <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-indigo-50 shadow-sm">
                    <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                      1
                    </div>
                    <div>
                      <div className="font-bold text-slate-800">من شريط العنوان أعلى المتصفح:</div>
                      <div className="text-xs text-slate-600 mt-0.5">
                        اضغط على أيقونة التثبيت <span className="inline-block px-2 py-0.5 bg-slate-100 rounded border font-mono font-bold text-indigo-700">⊕</span> أو <span className="inline-block px-2 py-0.5 bg-slate-100 rounded border font-mono font-bold text-indigo-700">🖥️⬇️</span> الظاهرة في يمين أو يسار شريط الرابط.
                      </div>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-indigo-50 shadow-sm">
                    <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                      2
                    </div>
                    <div>
                      <div className="font-bold text-slate-800">أو من قائمة المتصفح (⋮):</div>
                      <div className="text-xs text-slate-600 mt-0.5">
                        اضغط على قائمة المتصفح <strong>(⋮)</strong> ثم اختر <strong>«تثبيت قسم التحضيري...» (Install App)</strong> أو من <strong>المزيد من الأدوات ⬅ إنشاء اختصار</strong>.
                      </div>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-indigo-50 shadow-sm">
                    <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                      3
                    </div>
                    <div>
                      <div className="font-bold text-slate-800">تأكيد التثبيت:</div>
                      <div className="text-xs text-slate-600 mt-0.5">
                        اضغط <strong>«تثبيت» (Install)</strong>، وسيتم إنشاء أيقونة خاصة بالتطبيق فورياً على سطح المكتب تعمل بشكل مستقل ودون شريط المتصفح!
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 p-2.5 rounded-xl">
                  <HelpCircle className="w-4 h-4 text-indigo-500 shrink-0" />
                  <span>التطبيق يدعم العمل دون انترنت (Offline) بعد التثبيت ويحفظ كل التغييرات محلياً.</span>
                </div>
              </div>
            )}

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => {
                  soundEngine.playPop(350);
                  setShowGuideModal(false);
                }}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md transition cursor-pointer"
              >
                فهمت، حسناً
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
