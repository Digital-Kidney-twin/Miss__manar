import React, { useState, useEffect } from 'react';
import { 
  Volume2, 
  VolumeX, 
  Maximize2, 
  RotateCcw, 
  Sparkles, 
  Lightbulb, 
  Home, 
  Tv,
  BookOpen,
  Users
} from 'lucide-react';
import { soundEngine } from '../utils/audio';
import { studentDB } from '../utils/studentStorage';
import { PWAInstallButton } from './PWAInstallButton';

export type ActiveModule = 
  | 'home'
  | 'students'
  | 'lessons_catalog'
  | 'letters'
  | 'numbers'
  | 'writing'
  | 'colors_shapes'
  | 'islamic'
  | 'science'
  | 'world'
  | 'behavior'
  | 'songs'
  | 'games'
  | 'assessment';

interface TeacherNavbarProps {
  currentModule: ActiveModule;
  onNavigate: (module: ActiveModule) => void;
  dataShowZoom: number;
  setDataShowZoom: (zoom: number) => void;
  starsCount: number;
  onResetActivity?: () => void;
  moduleTitle?: string;
}

export const TeacherNavbar: React.FC<TeacherNavbarProps> = ({
  currentModule,
  onNavigate,
  dataShowZoom,
  setDataShowZoom,
  starsCount,
  onResetActivity,
  moduleTitle
}) => {
  const [soundOn, setSoundOn] = useState(true);
  const [showPedagogyGuide, setShowPedagogyGuide] = useState(false);
  const [activeStudentName, setActiveStudentName] = useState<string | null>(null);

  useEffect(() => {
    const updateActiveStudent = () => {
      const activeId = studentDB.getActiveStudentId();
      if (activeId) {
        const student = studentDB.getAll().find(s => s.id === activeId);
        setActiveStudentName(student ? student.name : null);
      } else {
        setActiveStudentName(null);
      }
    };
    updateActiveStudent();
    const unsub = studentDB.subscribe(updateActiveStudent);
    return () => unsub();
  }, []);

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    soundEngine.setSoundEnabled(next);
    if (next) soundEngine.playPop(520);
  };

  const toggleFullscreen = () => {
    soundEngine.playPop(440);
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const cycleZoom = () => {
    soundEngine.playPop(480);
    if (dataShowZoom === 1) setDataShowZoom(1.12);
    else if (dataShowZoom === 1.12) setDataShowZoom(1.22);
    else setDataShowZoom(1);
  };

  const playClassApplause = () => {
    soundEngine.playSuccess();
    soundEngine.speakArabic('أَحْسَنْتُمْ يَا أَبْطَالَ القِسْمِ فِي دَارِ المَعْرِفَة، بَارَكَ اللَّهُ فِيكُمْ مَعَ الآنسة منار!');
  };

  // Sleek, minimal floating teacher controls bar without ANY white horizontal top header
  return (
    <>
      <aside 
        aria-label="أدوات المعلمة السريعة"
        className="fixed top-3 left-3 z-50 flex items-center gap-1.5 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-2xl shadow-xl border border-slate-200/90 select-none animate-fadeIn"
      >
        {currentModule !== 'home' ? (
          <button
            onClick={() => {
              soundEngine.playPop(400);
              onNavigate('home');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs shadow-xs transition-transform active:scale-95"
            title="العودة لشاشة الترحيب الرئيسية"
          >
            <Home className="w-3.5 h-3.5" />
            <span>الترحيب</span>
          </button>
        ) : (
          <div className="flex items-center gap-1.5 px-2 text-xs font-bold text-slate-800 font-['Tajawal',sans-serif]">
            <span>🏫</span>
            <span>الآنسة منار</span>
          </div>
        )}

        {/* Lessons Catalog Button */}
        {currentModule !== 'lessons_catalog' && (
          <button
            onClick={() => {
              soundEngine.playPop(420);
              onNavigate('lessons_catalog');
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs shadow-xs transition-transform active:scale-95"
            title="الانتقال إلى فهرس الدروس والأنشطة"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>فهرس الدروس</span>
          </button>
        )}

        {/* Pupils Management Button */}
        <button
          onClick={() => {
            soundEngine.playPop(450);
            onNavigate('students');
          }}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl font-bold text-xs shadow-xs transition-transform active:scale-95 ${
            currentModule === 'students'
              ? 'bg-amber-500 text-white'
              : 'bg-amber-100 hover:bg-amber-200 text-amber-900'
          }`}
          title="قائمة أبطال وتلاميذ قسم الآنسة منار (قاعدة البيانات والتخصيص)"
        >
          <Users className="w-3.5 h-3.5" />
          <span>قائمة التلاميذ</span>
          {activeStudentName && (
            <span className="hidden md:inline-block bg-black/10 px-1.5 py-0.5 rounded-md text-[10px] font-mono">
              🎯 {activeStudentName}
            </span>
          )}
        </button>

        {/* PWA Desktop Install Button */}
        <PWAInstallButton variant="navbar" />

        <span className="text-slate-300">|</span>

        {/* Current Lesson Badge if in lesson */}
        {currentModule !== 'home' && currentModule !== 'students' && moduleTitle && (
          <span className="text-xs font-bold text-rose-600 px-1.5 hidden sm:inline">
            {moduleTitle}
          </span>
        )}

        {/* Stars Counter */}
        <div className="flex items-center gap-1 text-xs font-bold text-amber-700 bg-amber-50 px-2 py-1 rounded-lg">
          <span>⭐</span>
          <span className="font-mono tabular-nums">{starsCount}</span>
        </div>

        {/* Data Show Zoom */}
        <button
          onClick={cycleZoom}
          className="p-1.5 text-slate-700 hover:bg-slate-100 rounded-lg text-xs font-bold flex items-center gap-1"
          title="تكبير لـ Data Show"
        >
          <Tv className="w-3.5 h-3.5 text-rose-600" />
          <span className="font-mono tabular-nums text-[10px] hidden sm:inline">
            {dataShowZoom === 1 ? '100%' : `${Math.round(dataShowZoom * 100)}%`}
          </span>
        </button>

        {/* Sound toggle */}
        <button
          onClick={toggleSound}
          className="p-1.5 text-slate-700 hover:bg-slate-100 rounded-lg"
          title={soundOn ? 'كتم الصوت' : 'تشغيل الصوت'}
        >
          {soundOn ? <Volume2 className="w-3.5 h-3.5 text-indigo-600" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
        </button>

        {/* Applause button */}
        <button
          onClick={playClassApplause}
          className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-lg"
          title="تصفيق للأطفال"
        >
          <Sparkles className="w-3.5 h-3.5" />
        </button>

        {/* Pedagogy Guide */}
        <button
          onClick={() => setShowPedagogyGuide(!showPedagogyGuide)}
          className="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg"
          title="دليل الآنسة منار"
        >
          <Lightbulb className="w-3.5 h-3.5" />
        </button>

        {/* Fullscreen */}
        <button
          onClick={toggleFullscreen}
          className="p-1.5 text-slate-700 hover:bg-slate-100 rounded-lg hidden sm:flex"
          title="ملء الشاشة"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>

        {/* Reset activity (if in lesson) */}
        {currentModule !== 'home' && onResetActivity && (
          <button
            onClick={onResetActivity}
            className="p-1.5 text-slate-700 hover:bg-slate-100 rounded-lg"
            title="إعادة النشاط"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        )}
      </aside>

      {/* Guide Popup */}
      {showPedagogyGuide && (
        <div className="fixed left-4 top-14 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-amber-200 p-5 z-50 text-right animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
              <span>🏫</span>
              <span>قسم الآنسة منار • دار المعرفة</span>
            </h4>
            <button
              onClick={() => setShowPedagogyGuide(false)}
              className="text-slate-400 hover:text-slate-600 text-base leading-none"
            >
              ✕
            </button>
          </div>
          <div className="space-y-2 text-xs text-slate-600 leading-relaxed">
            <div className="p-2.5 bg-rose-50 rounded-xl border border-rose-100">
              <strong className="text-rose-900 block mb-0.5">🖥️ شاشة كاملة لـ Data Show:</strong>
              تم حذف الشريط العلوي لتكون شاشة العرض خالية من أي شريط أبيض مع توفير صورة القسم في الخلفية لجاذبية بصرية قصوى.
            </div>
            <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-100">
              <strong className="text-amber-900 block mb-0.5">🔢 الأعداد 1 إلى 100:</strong>
              جميع الأعداد مكتوبة بالحروف، مع ثبات الوحدات على اليمين والعشرات على اليسار دائماً.
            </div>
          </div>
        </div>
      )}
    </>
  );
};
