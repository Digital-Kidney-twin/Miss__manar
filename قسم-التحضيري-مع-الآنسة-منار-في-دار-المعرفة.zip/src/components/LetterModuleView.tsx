import React, { useState, useEffect } from 'react';
import { 
  Volume2, 
  Sparkles, 
  ArrowLeft, 
  ArrowRight, 
  CheckCircle2, 
  RotateCcw,
  BookOpen,
  Pencil,
  Smile,
  Layers,
  Zap
} from 'lucide-react';
import { ARABIC_LETTERS, LetterItem, FULL_ALPHABET_SYMBOLS } from '../data/arabicLetters';
import { soundEngine } from '../utils/audio';
import confetti from 'canvas-confetti';

interface LetterModuleViewProps {
  onEarnStar: () => void;
}

export const LetterModuleView: React.FC<LetterModuleViewProps> = ({ onEarnStar }) => {
  const [selectedLetter, setSelectedLetter] = useState<LetterItem>(ARABIC_LETTERS[0]);
  const [activeTab, setActiveTab] = useState<'intro' | 'vowels' | 'sukoon_shaddah' | 'madd' | 'tanween' | 'positions' | 'vocab' | 'tracing' | 'game'>('intro');
  const [activeVowelIdx, setActiveVowelIdx] = useState(0);
  const [activeMaddIdx, setActiveMaddIdx] = useState(0);
  const [activeTanweenIdx, setActiveTanweenIdx] = useState(0);
  const [activePositionIdx, setActivePositionIdx] = useState(0);
  const [isTracingActive, setIsTracingActive] = useState(false);
  const [gameScore, setGameScore] = useState(0);
  const [gameAnswered, setGameAnswered] = useState<boolean | null>(null);

  // Play letter pronunciation when letter changes
  useEffect(() => {
    soundEngine.speakArabic(selectedLetter.name);
  }, [selectedLetter]);

  const speak = (text: string) => {
    soundEngine.playPop(500);
    soundEngine.speakArabic(text);
  };

  const handleNextLetter = () => {
    const currentIndex = ARABIC_LETTERS.findIndex(l => l.id === selectedLetter.id);
    const nextIndex = (currentIndex + 1) % ARABIC_LETTERS.length;
    setSelectedLetter(ARABIC_LETTERS[nextIndex]);
    soundEngine.playPop(440);
  };

  const handlePrevLetter = () => {
    const currentIndex = ARABIC_LETTERS.findIndex(l => l.id === selectedLetter.id);
    const prevIndex = (currentIndex - 1 + ARABIC_LETTERS.length) % ARABIC_LETTERS.length;
    setSelectedLetter(ARABIC_LETTERS[prevIndex]);
    soundEngine.playPop(440);
  };

  const triggerReward = () => {
    soundEngine.playSuccess();
    onEarnStar();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Alphabet Selector Ribbon */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200">
        <div className="flex items-center justify-between gap-2 mb-3 px-2">
          <div className="flex items-center gap-2">
            <span className="text-xl">🔤</span>
            <span className="font-bold text-slate-800 text-sm">اختر حرف الدرس:</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrevLetter}
              className="p-1.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-600 transition-colors"
              title="الحرف السابق"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <button
              onClick={handleNextLetter}
              className="p-1.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-600 transition-colors"
              title="الحرف التالي"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Letter Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none px-1">
          {ARABIC_LETTERS.map(letter => {
            const isSelected = letter.id === selectedLetter.id;
            return (
              <button
                key={letter.id}
                onClick={() => {
                  soundEngine.playPop(480);
                  setSelectedLetter(letter);
                }}
                className={`min-w-13 h-13 rounded-2xl font-bold text-2xl flex items-center justify-center transition-all ${
                  isSelected
                    ? 'bg-rose-500 text-white shadow-md scale-105 btn-3d'
                    : 'bg-rose-50/70 hover:bg-rose-100 text-rose-800 border border-rose-200'
                }`}
              >
                {letter.letter}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Letter Teaching Arena */}
      <div className="bg-white rounded-3xl p-6 lg:p-8 shadow-sm border border-slate-200">
        {/* Navigation Tabs for Pedagogical Steps */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 border-b border-slate-100 scrollbar-none">
          <button
            onClick={() => { soundEngine.playPop(440); setActiveTab('intro'); }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'intro' ? 'bg-rose-500 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>🌟 الحرف واسمه</span>
          </button>

          <button
            onClick={() => { soundEngine.playPop(440); setActiveTab('vowels'); }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'vowels' ? 'bg-amber-500 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>☀️ الحركات القصيرة</span>
          </button>

          <button
            onClick={() => { soundEngine.playPop(440); setActiveTab('sukoon_shaddah'); }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'sukoon_shaddah' ? 'bg-blue-500 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>🌀 السكون والشدة</span>
          </button>

          <button
            onClick={() => { soundEngine.playPop(440); setActiveTab('madd'); }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'madd' ? 'bg-purple-500 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>📏 حروف المد</span>
          </button>

          <button
            onClick={() => { soundEngine.playPop(440); setActiveTab('tanween'); }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'tanween' ? 'bg-emerald-500 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>🔔 التنوين</span>
          </button>

          <button
            onClick={() => { soundEngine.playPop(440); setActiveTab('positions'); }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'positions' ? 'bg-teal-500 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>🧩 أشكال الحرف</span>
          </button>

          <button
            onClick={() => { soundEngine.playPop(440); setActiveTab('vocab'); }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'vocab' ? 'bg-orange-500 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>🖼️ الصوت والصورة</span>
          </button>

          <button
            onClick={() => { soundEngine.playPop(440); setActiveTab('tracing'); }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'tracing' ? 'bg-indigo-500 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>✏️ كتابة الحرف</span>
          </button>

          <button
            onClick={() => { soundEngine.playPop(440); setActiveTab('game'); }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'game' ? 'bg-pink-500 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>🎮 لعبة التثبيت</span>
          </button>
        </div>

        {/* Tab 1: Intro - Big Letter & Child Description */}
        {activeTab === 'intro' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Big 3D Letter Stage */}
            <div className="md:col-span-5 flex flex-col items-center justify-center p-8 bg-gradient-to-b from-rose-50 to-pink-50 rounded-3xl border border-rose-100 relative">
              <div className="absolute top-4 right-4">
                <button
                  onClick={() => speak(selectedLetter.name)}
                  className="p-3 bg-white rounded-2xl shadow-sm border border-rose-200 text-rose-600 hover:scale-110 transition-transform"
                  title="استمع لصوت الحرف"
                >
                  <Volume2 className="w-6 h-6" />
                </button>
              </div>

              {/* 3D Big Letter Display */}
              <div 
                onClick={() => speak(selectedLetter.name)}
                className="w-48 h-48 sm:w-56 sm:h-56 rounded-3xl bg-white shadow-md border-4 border-rose-200 flex items-center justify-center cursor-pointer hover:scale-105 transition-transform card-3d select-none"
              >
                <span className="text-8xl sm:text-9xl font-extrabold text-rose-600 drop-shadow-md font-['Tajawal',sans-serif]">
                  {selectedLetter.letter}
                </span>
              </div>

              <div className="mt-4 text-center">
                <span className="text-2xl font-bold text-slate-800">
                  حَرْفُ {selectedLetter.name}
                </span>
              </div>
            </div>

            {/* Child Explanation & Audio Interaction */}
            <div className="md:col-span-7 space-y-6">
              <div className="bg-amber-50/80 border border-amber-200 rounded-3xl p-6 relative">
                <div className="flex items-start gap-4">
                  <span className="text-4xl">🧒</span>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-amber-900">
                      تَعَرَّفْ عَلَى صَدِيقِنَا الجَدِيد:
                    </h3>
                    <p className="text-lg text-slate-700 font-medium leading-relaxed">
                      {selectedLetter.description}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-amber-200/60 flex items-center justify-between">
                  <span className="text-xs text-amber-800 font-bold">
                    💡 اضغط على الزر لسماع النطق مع الأطفال
                  </span>
                  <button
                    onClick={() => speak(selectedLetter.description)}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>اقرأ لي الشرح 🔊</span>
                  </button>
                </div>
              </div>

              {/* Quick Word Preview */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-slate-700">
                  كَلِمَاتٌ تَبْدَأُ بِحَرْفِ {selectedLetter.letter}:
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {selectedLetter.vocabulary.slice(0, 3).map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => speak(`${item.word}.. ${item.soundDesc}`)}
                      className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-2xl flex items-center gap-3 text-right transition-colors"
                    >
                      <span className="text-3xl">{item.emoji}</span>
                      <div>
                        <span className="text-base font-bold text-rose-600 block">{item.word}</span>
                        <span className="text-xs text-slate-500 block">{item.meaning}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Action: Next Step Button */}
              <div className="flex justify-end pt-2">
                <button
                  onClick={() => {
                    soundEngine.playPop(520);
                    setActiveTab('vowels');
                  }}
                  className="px-6 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-2xl shadow-sm flex items-center gap-2 btn-3d"
                >
                  <span>نَتَعَلَّمُ الحَرَكَاتِ القَصِيرَة</span>
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Short Vowels (الحركات القصيرة) */}
        {activeTab === 'vowels' && (
          <div className="space-y-8">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h3 className="text-2xl font-bold text-slate-800">
                الحَرَكَاتُ القَصِيرَةُ مَعَ حَرْفِ ({selectedLetter.letter})
              </h3>
              <p className="text-slate-600 text-sm">
                الحركات القصيرة ثلاث: الفتحة تفتح فمنا، الكسرة تبتسم، والضمة تضم شفتينا!
              </p>
            </div>

            {/* 3 Interactive Cards for Fatha, Kasra, Damma */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {selectedLetter.shortVowels.map((vowel, idx) => {
                const isActive = activeVowelIdx === idx;
                const colors = [
                  { bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-600', badge: 'bg-amber-500' },
                  { bg: 'bg-sky-50', border: 'border-sky-200', text: 'text-sky-600', badge: 'bg-sky-500' },
                  { bg: 'bg-rose-50', border: 'border-rose-200', text: 'text-rose-600', badge: 'bg-rose-500' }
                ][idx % 3];

                return (
                  <div
                    key={idx}
                    onClick={() => {
                      setActiveVowelIdx(idx);
                      speak(`${vowel.sound}.. ${vowel.vowelName}.. ${vowel.note}`);
                    }}
                    className={`p-6 rounded-3xl border-2 transition-all cursor-pointer card-3d ${
                      colors.bg
                    } ${isActive ? `${colors.border} ring-4 ring-rose-200 scale-102` : 'border-transparent'}`}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <span className={`px-3 py-1 rounded-xl text-white text-xs font-bold ${colors.badge}`}>
                        {vowel.vowelName}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          speak(vowel.sound);
                        }}
                        className="p-2 bg-white rounded-xl shadow-xs border border-slate-200 text-slate-600 hover:text-rose-600"
                      >
                        <Volume2 className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Big Letter with Mark */}
                    <div className="w-32 h-32 mx-auto my-2 bg-white rounded-2xl shadow-sm border border-slate-200 flex items-center justify-center">
                      <span className={`text-7xl font-extrabold ${colors.text} font-['Tajawal',sans-serif]`}>
                        {vowel.char}
                      </span>
                    </div>

                    <div className="text-center space-y-2 mt-4">
                      <div className="text-xl font-extrabold text-slate-800">
                        {vowel.sound}
                      </div>
                      <div className="text-xs text-slate-600 font-medium">
                        {vowel.note}
                      </div>
                      <div className="pt-2 text-sm font-bold text-slate-700 bg-white/80 py-1.5 px-3 rounded-xl inline-block">
                        مِثَال: {vowel.example}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Teacher tip & next tab button */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <span className="text-xs text-slate-600">
                🗣️ اطلبي من الأطفال وضع يدهم على الشفتين لملاحظة حركة الفم عند كل حركة.
              </span>
              <button
                onClick={() => {
                  soundEngine.playPop(520);
                  setActiveTab('sukoon_shaddah');
                }}
                className="px-5 py-2.5 bg-blue-500 hover:bg-blue-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2"
              >
                <span>السكون والشدة</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Sukoon & Shaddah (السكون والشدة) */}
        {activeTab === 'sukoon_shaddah' && (
          <div className="space-y-8">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h3 className="text-2xl font-bold text-slate-800">
                السُّكُونُ وَالشَّدَّةُ مَعَ حَرْفِ ({selectedLetter.letter})
              </h3>
              <p className="text-slate-600 text-sm">
                السكون يجعل الحرف هادئاً وساكناً، والشدة تجعل الحرف قوياً ومشدداً!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Sukoon Card */}
              <div 
                onClick={() => speak(`${selectedLetter.sukoon.char}.. ${selectedLetter.sukoon.note}`)}
                className="p-6 bg-sky-50 rounded-3xl border-2 border-sky-200 card-3d cursor-pointer space-y-4"
              >
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 bg-sky-500 text-white text-xs font-bold rounded-xl">
                    السُّكُون (ـْ)
                  </span>
                  <button className="p-2 bg-white rounded-xl shadow-xs border border-sky-200 text-sky-600">
                    <Volume2 className="w-5 h-5" />
                  </button>
                </div>

                <div className="w-36 h-36 mx-auto bg-white rounded-2xl shadow-sm border border-sky-200 flex items-center justify-center">
                  <span className="text-7xl font-extrabold text-sky-600 font-['Tajawal',sans-serif]">
                    {selectedLetter.sukoon.char}
                  </span>
                </div>

                <div className="text-center space-y-2">
                  <h4 className="text-lg font-bold text-sky-900">الحَرْفُ السَّاكِن</h4>
                  <p className="text-sm text-slate-700 leading-relaxed font-medium">
                    {selectedLetter.sukoon.note}
                  </p>
                  <div className="p-2 bg-white rounded-xl border border-sky-200 inline-block text-base font-bold text-slate-800">
                    كَلِمَة: {selectedLetter.sukoon.example}
                  </div>
                </div>
              </div>

              {/* Shaddah Card */}
              <div className="p-6 bg-indigo-50 rounded-3xl border-2 border-indigo-200 card-3d space-y-4">
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 bg-indigo-600 text-white text-xs font-bold rounded-xl">
                    الشَّدَّة (ـّ)
                  </span>
                  <span className="text-xs text-indigo-700 font-bold">الحرف القوي 💪</span>
                </div>

                {/* 3 Shaddah varieties */}
                <div className="grid grid-cols-3 gap-3">
                  {selectedLetter.shaddah.map((shad, idx) => (
                    <div
                      key={idx}
                      onClick={() => speak(`${shad.char}.. ${shad.name}.. ${shad.note}`)}
                      className="p-3 bg-white rounded-2xl border border-indigo-200 text-center cursor-pointer hover:border-indigo-400 transition-colors"
                    >
                      <span className="text-4xl font-extrabold text-indigo-600 block mb-1">
                        {shad.char}
                      </span>
                      <span className="text-[11px] font-bold text-slate-600 block">
                        {shad.name}
                      </span>
                      <span className="text-xs font-semibold text-rose-500 block mt-1">
                        {shad.example}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="p-3 bg-white/80 rounded-2xl border border-indigo-100 text-center text-xs text-indigo-900 font-medium leading-relaxed">
                  الشدة عبارة عن حرفين تم دمجهما ليصبحا حرفاً واحداً قوياً نضغط عليه عند النطق!
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => {
                  soundEngine.playPop(520);
                  setActiveTab('madd');
                }}
                className="px-5 py-2.5 bg-purple-500 hover:bg-purple-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2"
              >
                <span>حروف المد الطويلة</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 4: Madd Letters (حروف المد) */}
        {activeTab === 'madd' && (
          <div className="space-y-8">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h3 className="text-2xl font-bold text-slate-800">
                حُرُوفُ المَدِّ الطَّوِيلَةِ مَعَ حَرْفِ ({selectedLetter.letter})
              </h3>
              <p className="text-slate-600 text-sm">
                المد صوت طويل وجميل: بالألف (ـا)، بالواو (ـو)، وبالياء (ـي)!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {selectedLetter.madd.map((m, idx) => {
                const isActive = activeMaddIdx === idx;
                return (
                  <div
                    key={idx}
                    onClick={() => {
                      setActiveMaddIdx(idx);
                      speak(`${m.long}.. ${m.type}.. ${m.formula}.. مِثَال: ${m.example}`);
                    }}
                    className={`p-6 rounded-3xl border-2 transition-all cursor-pointer card-3d ${
                      isActive ? 'bg-purple-50 border-purple-300 ring-4 ring-purple-100' : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <span className="px-3 py-1 bg-purple-600 text-white text-xs font-bold rounded-xl">
                        {m.type}
                      </span>
                      <button className="p-2 bg-white rounded-xl shadow-xs border border-slate-200 text-purple-600">
                        <Volume2 className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="w-32 h-32 mx-auto bg-white rounded-2xl shadow-sm border border-purple-200 flex items-center justify-center">
                      <span className="text-6xl font-extrabold text-purple-600 font-['Tajawal',sans-serif]">
                        {m.long}
                      </span>
                    </div>

                    <div className="text-center space-y-3 mt-4">
                      {/* Formula: short + vowel = long */}
                      <div className="p-2 bg-white rounded-xl border border-purple-200 text-sm font-bold text-slate-700 font-mono">
                        {m.formula}
                      </div>
                      <div className="text-xs text-slate-600">
                        {m.note}
                      </div>
                      <div className="text-base font-extrabold text-purple-700 bg-purple-100/60 py-1.5 px-3 rounded-xl inline-block">
                        مِثَال: {m.example}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => {
                  soundEngine.playPop(520);
                  setActiveTab('tanween');
                }}
                className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2"
              >
                <span>التنوين</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 5: Tanween (التنوين) */}
        {activeTab === 'tanween' && (
          <div className="space-y-8">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h3 className="text-2xl font-bold text-slate-800">
                التَّنْوِينُ مَعَ حَرْفِ ({selectedLetter.letter})
              </h3>
              <p className="text-slate-600 text-sm">
                التنوين نون ساكنة نسمع صوتها في آخر الكلمة ولا نكتبها!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {selectedLetter.tanween.map((t, idx) => (
                <div
                  key={idx}
                  onClick={() => speak(`${t.sound}.. ${t.name}.. مِثَال: ${t.example}`)}
                  className="p-6 bg-emerald-50 rounded-3xl border-2 border-emerald-200 card-3d cursor-pointer space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 bg-emerald-600 text-white text-xs font-bold rounded-xl">
                      {t.name}
                    </span>
                    <button className="p-2 bg-white rounded-xl shadow-xs border border-emerald-200 text-emerald-600">
                      <Volume2 className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="w-32 h-32 mx-auto bg-white rounded-2xl shadow-sm border border-emerald-200 flex items-center justify-center">
                    <span className="text-6xl font-extrabold text-emerald-600 font-['Tajawal',sans-serif]">
                      {t.char}
                    </span>
                  </div>

                  <div className="text-center space-y-2">
                    <div className="text-xl font-bold text-emerald-900 font-mono">
                      صَوْتُهَا: [{t.sound}]
                    </div>
                    <div className="text-xs text-slate-600 font-medium">
                      {t.note}
                    </div>
                    <div className="p-2 bg-white rounded-xl border border-emerald-200 text-base font-bold text-slate-800">
                      كَلِمَة: {t.example}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => {
                  soundEngine.playPop(520);
                  setActiveTab('positions');
                }}
                className="px-5 py-2.5 bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2"
              >
                <span>أشكال الحرف في الكلمة</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 6: Positions (أشكال الحرف في الكلمة) */}
        {activeTab === 'positions' && (
          <div className="space-y-8">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h3 className="text-2xl font-bold text-slate-800">
                أَشْكَالُ حَرْفِ ({selectedLetter.letter}) دَاخِلَ الكَلِمَة
              </h3>
              <p className="text-slate-600 text-sm">
                يتغير شكل الحرف ليمسك أيدي أصدقائه الحروف في البداية والوسط والنهاية!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {selectedLetter.positions.map((pos, idx) => (
                <div
                  key={idx}
                  onClick={() => speak(`${pos.pos}.. شَكْلُهُ: ${pos.form}.. مِثْل كَلِمَة: ${pos.word}`)}
                  className="p-6 bg-teal-50 rounded-3xl border-2 border-teal-200 card-3d cursor-pointer space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 bg-teal-600 text-white text-xs font-bold rounded-xl">
                      {pos.pos}
                    </span>
                    <span className="text-3xl">{pos.exampleEmoji}</span>
                  </div>

                  <div className="w-32 h-32 mx-auto bg-white rounded-2xl shadow-sm border border-teal-200 flex items-center justify-center">
                    <span className="text-6xl font-extrabold text-teal-600 font-['Tajawal',sans-serif]">
                      {pos.form}
                    </span>
                  </div>

                  <div className="text-center space-y-2">
                    <div className="p-3 bg-white rounded-2xl border border-teal-200 text-2xl font-extrabold text-slate-800 font-['Tajawal',sans-serif]">
                      <span className="text-rose-500 font-bold underline decoration-rose-300">
                        {pos.targetPart}
                      </span>
                      {pos.word.replace(pos.targetPart, '')}
                    </div>
                    <span className="text-xs text-slate-500 block">
                      الحرف مميز باللون الوردي داخل الكلمة
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => {
                  soundEngine.playPop(520);
                  setActiveTab('vocab');
                }}
                className="px-5 py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2"
              >
                <span>الصور والكلمات</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 7: Vocab & Sounds (الكلمات والصور) */}
        {activeTab === 'vocab' && (
          <div className="space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h3 className="text-2xl font-bold text-slate-800">
                بَنْكُ صُوَرِ وَكَلِمَاتِ حَرْفِ ({selectedLetter.letter})
              </h3>
              <p className="text-slate-600 text-sm">
                اضغط على أي صورة ثلاثية الأبعاد لسماع نطق الكلمة ووصفها الجميل!
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              {selectedLetter.vocabulary.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => speak(`${item.word}.. ${item.soundDesc}`)}
                  className="p-5 bg-white rounded-3xl border-2 border-orange-100 hover:border-orange-300 card-3d cursor-pointer text-center space-y-3"
                >
                  <div className="w-20 h-20 mx-auto bg-gradient-to-tr from-amber-50 to-orange-50 rounded-2xl border border-orange-200 flex items-center justify-center text-5xl shadow-inner">
                    {item.emoji}
                  </div>
                  <div>
                    <span className="text-2xl font-extrabold text-orange-600 block font-['Tajawal',sans-serif]">
                      {item.word}
                    </span>
                    <span className="text-xs text-slate-500 block mt-1">
                      {item.meaning}
                    </span>
                  </div>
                  <button className="w-full py-1.5 bg-orange-50 hover:bg-orange-100 rounded-xl text-orange-700 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors">
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>استمع</span>
                  </button>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-4">
              <button
                onClick={() => {
                  soundEngine.playPop(520);
                  setActiveTab('tracing');
                }}
                className="px-5 py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2"
              >
                <span>طريقة كتابة الحرف</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 8: Tracing & Writing (الكتابة وتتبع المسار) */}
        {activeTab === 'tracing' && (
          <div className="space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-2">
              <h3 className="text-2xl font-bold text-slate-800">
                كَيْفَ نَكْتُبُ حَرْفَ ({selectedLetter.letter})؟
              </h3>
              <p className="text-slate-600 text-sm">
                {selectedLetter.childTip}
              </p>
            </div>

            <div className="max-w-md mx-auto p-6 bg-slate-50 rounded-3xl border-2 border-slate-200 text-center space-y-4">
              {/* SVG Animated Stroke Guide */}
              <div className="w-full h-64 bg-white rounded-2xl shadow-inner border border-slate-200 flex items-center justify-center relative overflow-hidden">
                <svg viewBox="0 0 200 160" className="w-full h-full max-w-[260px]">
                  {/* Notebook line */}
                  <line x1="10" y1="120" x2="190" y2="120" stroke="#CBD5E1" strokeWidth="2" strokeDasharray="4 4" />
                  
                  {/* Background guide path */}
                  <path
                    d={selectedLetter.tracingPath}
                    fill="none"
                    stroke="#E2E8F0"
                    strokeWidth="18"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />

                  {/* Animated dash path */}
                  <path
                    d={selectedLetter.tracingPath}
                    fill="none"
                    stroke="#F43F5E"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="guide-path"
                  />
                </svg>

                <div className="absolute top-3 right-3 flex items-center gap-1.5 px-3 py-1 bg-rose-50 text-rose-600 rounded-xl text-xs font-bold border border-rose-200">
                  <span>⭐ نقطة البداية</span>
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-900 font-medium">
                💡 دعي الأطفال يرسمون الحرف في الهواء بأصابعهم مع تحريك القلم على السبورة!
              </div>

              <button
                onClick={() => speak(selectedLetter.childTip)}
                className="w-full py-3 bg-indigo-500 hover:bg-indigo-600 text-white font-bold rounded-2xl shadow-xs flex items-center justify-center gap-2"
              >
                <Volume2 className="w-5 h-5" />
                <span>اقرأ طريقة الكتابة بصوت واضح</span>
              </button>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => {
                  soundEngine.playPop(520);
                  setActiveTab('game');
                }}
                className="px-5 py-2.5 bg-pink-500 hover:bg-pink-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2"
              >
                <span>لعبة تثبيت الحرف</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 9: Letter Mini Game (لعبة التثبيت) */}
        {activeTab === 'game' && (
          <div className="space-y-6 max-w-xl mx-auto text-center">
            <div className="space-y-2">
              <span className="text-4xl">🎮</span>
              <h3 className="text-2xl font-bold text-slate-800">
                لُعْبَةُ صَيْدِ حَرْفِ ({selectedLetter.letter})
              </h3>
              <p className="text-slate-600 text-sm">
                اختر البطاقة التي تحتوي على حَرْفِ ({selectedLetter.letter}):
              </p>
            </div>

            {/* Game Options */}
            <div className="grid grid-cols-3 gap-4 pt-4">
              {[
                { letter: selectedLetter.letter, isCorrect: true },
                { letter: 'س', isCorrect: false },
                { letter: 'م', isCorrect: false }
              ]
                .sort(() => (selectedLetter.id === 'baa' ? -0.5 : 0.5))
                .map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      if (opt.isCorrect) {
                        setGameAnswered(true);
                        triggerReward();
                        setGameScore(s => s + 1);
                        speak(`أحسنت! هذا هو حرف ${selectedLetter.name}`);
                      } else {
                        setGameAnswered(false);
                        soundEngine.playGentleBoing();
                        speak('حاول مرة أخرى يا بطل!');
                      }
                    }}
                    className={`h-32 rounded-3xl font-extrabold text-6xl flex items-center justify-center border-2 transition-all card-3d ${
                      gameAnswered === true && opt.isCorrect
                        ? 'bg-emerald-500 text-white border-emerald-600 scale-105'
                        : 'bg-white hover:bg-rose-50 text-slate-800 border-slate-200 hover:border-rose-300'
                    }`}
                  >
                    {opt.letter}
                  </button>
                ))}
            </div>

            {gameAnswered === true && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-center gap-3 text-emerald-800 font-bold animate-bounce-slow">
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                <span>إِجَابَةٌ رَائِعَةٌ يَا بَطَل! حَصَلْتَ عَلَى نَجْمَةٍ جَدِيدَة ⭐</span>
              </div>
            )}

            <div className="pt-4 flex items-center justify-center gap-4">
              <button
                onClick={() => {
                  setGameAnswered(null);
                  soundEngine.playPop(440);
                }}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة اللعبة</span>
              </button>
              <button
                onClick={handleNextLetter}
                className="px-6 py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-xs"
              >
                <span>الانتقال للحرف التالي</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
