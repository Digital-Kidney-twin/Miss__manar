import React from 'react';
import { 
  ArrowLeft, 
  Volume2, 
  BookOpen, 
  Sparkles 
} from 'lucide-react';
import { ActiveModule } from './TeacherNavbar';
import { soundEngine } from '../utils/audio';

import heroImg from '../assets/images/classroom_hero_3d_1790362248708.jpg';

interface HomeDashboardProps {
  onNavigate: (module: ActiveModule) => void;
  starsCount: number;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({ onNavigate }) => {
  const speak = (text: string) => {
    soundEngine.playPop(520);
    soundEngine.speakArabic(text);
  };

  return (
    <div className="fixed inset-0 w-screen h-screen overflow-hidden flex flex-col items-center justify-center select-none z-10">
      {/* Fullscreen 3D Classroom Background Image filling 100% of the screen */}
      <img
        src={heroImg}
        alt="قسم الآنسة منار في دار المعرفة"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover object-center scale-100"
      />

      {/* Cinematic High-Contrast Overlay for Crisp Projection on Data Show */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-900/55 to-slate-950/45 backdrop-blur-[0.5px]" />

      {/* Center Welcome Stage: Classroom Background & Welcome Phrase Only */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center px-4 sm:px-8 max-w-5xl mx-auto space-y-8">
        
        {/* School Badge Pill */}
        <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/40 text-white text-sm sm:text-base font-extrabold shadow-xl transition-all">
          <span className="text-xl">🏫</span>
          <span className="font-['Tajawal',sans-serif]">القسم الرقمي التفاعلي للتحضيري • دار المعرفة</span>
        </div>

        {/* Grand Welcoming Phrase Requested by User (Without any flower emoji) */}
        <div className="space-y-3 sm:space-y-4">
          <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black text-white tracking-wide font-['Tajawal',sans-serif] leading-tight drop-shadow-[0_8px_24px_rgba(0,0,0,0.95)]">
            مَرْحَباً بِكُمْ فِي قِسْمِ الآنسة مَنَار
          </h1>
          <h2 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-amber-300 tracking-wide font-['Tajawal',sans-serif] drop-shadow-[0_8px_24px_rgba(0,0,0,0.95)]">
            فِي دَارِ المَعْرِفَة
          </h2>
        </div>

        {/* Clear Gateway to Lessons & Audio Greeting */}
        <div className="pt-6 sm:pt-8 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={() => {
              soundEngine.playPop(520);
              onNavigate('lessons_catalog');
            }}
            className="px-8 py-4 sm:px-12 sm:py-5 bg-gradient-to-r from-rose-500 via-pink-500 to-amber-500 hover:from-rose-600 hover:via-pink-600 hover:to-amber-600 text-white font-black text-xl sm:text-2xl rounded-3xl shadow-2xl transition-all transform hover:scale-105 active:scale-95 flex items-center gap-3 border-2 border-white/70 btn-3d cursor-pointer"
          >
            <BookOpen className="w-6 h-6 sm:w-7 sm:h-7" />
            <span>الانتقال إلى الدروس والأنشطة</span>
            <ArrowLeft className="w-6 h-6 sm:w-7 sm:h-7" />
          </button>

          <button
            onClick={() => speak('مرحباً بكم يا أطفال في قسم الآنسة منار في دار المعرفة!')}
            className="px-5 py-4 sm:py-5 bg-white/20 hover:bg-white/30 rounded-3xl backdrop-blur-md text-white border-2 border-white/50 shadow-2xl transition-transform active:scale-95 cursor-pointer flex items-center gap-2 font-bold text-base sm:text-lg"
            title="استمع إلى ترحيب الآنسة منار بصوتها"
          >
            <Volume2 className="w-6 h-6 text-amber-300" />
            <span>ترحيب صوتي</span>
          </button>
        </div>
      </div>
    </div>
  );
};
