export interface LetterItem {
  id: string;
  letter: string;
  name: string;
  phonic: string;
  description: string;
  shortVowels: {
    char: string;
    vowelName: string;
    sound: string;
    example: string;
    note: string;
  }[];
  sukoon: {
    char: string;
    note: string;
    example: string;
  };
  shaddah: {
    char: string;
    name: string;
    note: string;
    example: string;
  }[];
  madd: {
    formula: string;
    short: string;
    long: string;
    type: string;
    example: string;
    note: string;
  }[];
  tanween: {
    char: string;
    name: string;
    sound: string;
    example: string;
    note: string;
  }[];
  positions: {
    pos: 'بداية الكلمة' | 'وسط الكلمة' | 'نهاية الكلمة';
    form: string;
    word: string;
    targetPart: string;
    exampleEmoji: string;
  }[];
  vocabulary: {
    word: string;
    meaning: string;
    emoji: string;
    soundDesc: string;
  }[];
  tracingPath: string; // SVG path for stroke tracing
  childTip: string;
}

export const ARABIC_LETTERS: LetterItem[] = [
  {
    id: 'baa',
    letter: 'ب',
    name: 'بَاء',
    phonic: 'بـَ',
    description: 'هذا حرف الباء.. اسمه باء وله نقطة واحدة تحت! يشبه الصحن الصغير وتحته حبة حلوى.',
    shortVowels: [
      { char: 'بَ', vowelName: 'فَتْحَة', sound: 'بَ', example: 'بَقَرَة', note: 'باء مع الفتحة نفتح فمنا: بَ' },
      { char: 'بِ', vowelName: 'كَسْرَة', sound: 'بِ', example: 'بِنْت', note: 'باء مع الكسرة نبتسم بلطف: بِ' },
      { char: 'بُ', vowelName: 'ضَمَّة', sound: 'بُ', example: 'بُرْتُقَال', note: 'باء مع الضمة نضم شفتينا: بُ' }
    ],
    sukoon: {
      char: 'بْ',
      note: 'السكون دائرة صغيرة تجعل الحرف هادئاً وساكناً: بْ',
      example: 'حَبْل'
    },
    shaddah: [
      { char: 'بَّ', name: 'شَدَّة مع فتحة', note: 'الشدة تجعل الحرف قوياً ومشدداً: بَّ', example: 'صَبَّار' },
      { char: 'بِّ', name: 'شَدَّة مع كسرة', note: 'الشدة مع كسرة: بِّ', example: 'يُحَبِّب' },
      { char: 'بُّ', name: 'شَدَّة مع ضمة', note: 'الشدة مع ضمة: بُّ', example: 'يَصُبُّ' }
    ],
    madd: [
      { formula: 'بَ + ا = بَا', short: 'بَ', long: 'بَا', type: 'مد بالألف', example: 'بَاب', note: 'نمد الصوت طويلاً بالألف: بَا' },
      { formula: 'بِ + ي = بِي', short: 'بِ', long: 'بِي', type: 'مد بالياء', example: 'طَبِيب', note: 'نمد الصوت طويلاً بالياء: بِي' },
      { formula: 'بُ + و = بُو', short: 'بُ', long: 'بُو', type: 'مد بالواو', example: 'بُومَة', note: 'نمد الصوت طويلاً بالواو: بُو' }
    ],
    tanween: [
      { char: 'بً', name: 'تنوين الفتح (ـً)', sound: 'بَنْ', example: 'كِتَابًا', note: 'فتحتان فوق الحرف صوتها نون خفيفة: بَنْ' },
      { char: 'بٍ', name: 'تنوين الكسر (ـٍ)', sound: 'بِنْ', example: 'كِتَابٍ', note: 'كسرتان تحت الحرف صوتها نون خفيفة: بِنْ' },
      { char: 'بٌ', name: 'تنوين الضم (ـٌ)', sound: 'بُنْ', example: 'كِتَابٌ', note: 'ضمتان فوق الحرف صوتها نون خفيفة: بُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'بـ', word: 'بَاب', targetPart: 'بـ', exampleEmoji: '🚪' },
      { pos: 'وسط الكلمة', form: 'ـبـ', word: 'حَبْل', targetPart: 'ـبـ', exampleEmoji: '🪢' },
      { pos: 'نهاية الكلمة', form: 'ـب', word: 'كِتَاب', targetPart: 'ـب', exampleEmoji: '📖' }
    ],
    vocabulary: [
      { word: 'بَاب', meaning: 'باب', emoji: '🚪', soundDesc: 'باب نطرقه وندخل منه' },
      { word: 'بَطَّة', meaning: 'بطة', emoji: '🦆', soundDesc: 'بطة صفراء تسبح في الماء' },
      { word: 'بَقَرَة', meaning: 'بقرة', emoji: '🐄', soundDesc: 'بقرة طيبة تعطينا الحليب' },
      { word: 'بَحْر', meaning: 'بحر', emoji: '🌊', soundDesc: 'بحر أزرق واسع وجميل' },
      { word: 'بُرْتُقَال', meaning: 'برتقال', emoji: '🍊', soundDesc: 'برتقال لذيذ غني بالفيتامينات' }
    ],
    tracingPath: 'M 180,60 L 180,90 Q 180,120 100,120 Q 20,120 20,90 L 20,60',
    childTip: 'نرسم سناً صغيراً من اليمين، ثم نمشي على السطر إلى اليسار، ونرفع سناً آخراً، ونضع نقطة واحدة تحت!'
  },
  {
    id: 'alif',
    letter: 'أ',
    name: 'أَلِف',
    phonic: 'أَ',
    description: 'هذا حرف الألف.. عصا مستقيمة وجميلة وفوقها همزة كأنها تاج صغير!',
    shortVowels: [
      { char: 'أَ', vowelName: 'فَتْحَة', sound: 'أَ', example: 'أَرْنَب', note: 'ألف مع الفتحة نفتح فمنا: أَ' },
      { char: 'إِ', vowelName: 'كَسْرَة', sound: 'إِ', example: 'إِبْرِيق', note: 'ألف مع الكسرة ننزل الهمزة تحت: إِ' },
      { char: 'أُ', vowelName: 'ضَمَّة', sound: 'أُ', example: 'أُذُن', note: 'ألف مع الضمة نضم شفتينا: أُ' }
    ],
    sukoon: {
      char: 'أْ',
      note: 'السكون يجعل الهمزة تقف هادئة: أْ مثل كَأْس',
      example: 'كَأْس'
    },
    shaddah: [
      { char: 'أَّ', name: 'شَدَّة مع فتحة', note: 'ألف مشددة بالفتح', example: 'يَأْكُل' },
      { char: 'أِّ', name: 'شَدَّة مع كسرة', note: 'ألف مشددة بالكسر', example: 'رِئَة' },
      { char: 'أُّ', name: 'شَدَّة مع ضمة', note: 'ألف مشددة بالضم', example: 'يَؤُمُّ' }
    ],
    madd: [
      { formula: 'أَ + ا = آ', short: 'أَ', long: 'آ', type: 'مد بالألف (مدة)', example: 'آمَال', note: 'نمد الهمزة طويلاً لتصبح آ' },
      { formula: 'إِ + ي = إِي', short: 'إِ', long: 'إِي', type: 'مد بالياء', example: 'إِيمَان', note: 'نمد الكسرة بالياء: إِي' },
      { formula: 'أُ + و = أُو', short: 'أُ', long: 'أُو', type: 'مد بالواو', example: 'أُولَى', note: 'نمد الضمة بالواو: أُو' }
    ],
    tanween: [
      { char: 'ءً', name: 'تنوين الفتح (ـً)', sound: 'أَنْ', example: 'مَاءً', note: 'صوت نون خفيفة مفتوحة' },
      { char: 'ءٍ', name: 'تنوين الكسر (ـٍ)', sound: 'إِنْ', example: 'مَاءٍ', note: 'صوت نون خفيفة مكسورة' },
      { char: 'ءٌ', name: 'تنوين الضم (ـٌ)', sound: 'أُنْ', example: 'مَاءٌ', note: 'صوت نون خفيفة مضمومة' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'أ', word: 'أَرْنَب', targetPart: 'أ', exampleEmoji: '🐰' },
      { pos: 'وسط الكلمة', form: 'ـأ', word: 'فَأْر', targetPart: 'ـأ', exampleEmoji: '🐭' },
      { pos: 'نهاية الكلمة', form: 'ـا', word: 'عَصَا', targetPart: 'ـا', exampleEmoji: '🦯' }
    ],
    vocabulary: [
      { word: 'أَرْنَب', meaning: 'أرنب', emoji: '🐰', soundDesc: 'أرنب سريع يقفز في الحقل' },
      { word: 'أَسَد', meaning: 'أسد', emoji: '🦁', soundDesc: 'أسد شجاع ملك الغابة' },
      { word: 'أُمِّي', meaning: 'أمي', emoji: '👩', soundDesc: 'أمي الحبيبة نبع الحنان' },
      { word: 'أَلْوَان', meaning: 'ألوان', emoji: '🎨', soundDesc: 'علبة ألوان نرسم بها' },
      { word: 'أَنَانَاس', meaning: 'أناناس', emoji: '🍍', soundDesc: 'أناناس لذيذ وحلو المذاق' }
    ],
    tracingPath: 'M 100,20 L 100,120',
    childTip: 'عصا مستقيمة من الأعلى إلى الأسفل، ثم نرسم نصف دائرة صغيرة وشحطة للهمزة!'
  },
  {
    id: 'taa',
    letter: 'ت',
    name: 'تَاء',
    phonic: 'تـَ',
    description: 'هذا حرف التاء.. صحن جميل وفي قلبه نقطتان مثل عينين تبتسمان!',
    shortVowels: [
      { char: 'تَ', vowelName: 'فَتْحَة', sound: 'تَ', example: 'تَمْر', note: 'تاء مع الفتحة: تَ' },
      { char: 'تِ', vowelName: 'كَسْرَة', sound: 'تِ', example: 'تِمْسَاح', note: 'تاء مع الكسرة: تِ' },
      { char: 'تُ', vowelName: 'ضَمَّة', sound: 'تُ', example: 'تُفَّاح', note: 'تاء مع الضمة: تُ' }
    ],
    sukoon: {
      char: 'تْ',
      note: 'السكون يجعل التاء هادئة: تْ مثل بِنْت',
      example: 'بِنْت'
    },
    shaddah: [
      { char: 'تَّ', name: 'شَدَّة مع فتحة', note: 'تاء قوية مشددة: تَّ', example: 'يَتَعَلَّم' },
      { char: 'تِّ', name: 'شَدَّة مع كسرة', note: 'تاء مشددة بالكسر: تِّ', example: 'يَتِمُّ' },
      { char: 'تُّ', name: 'شَدَّة مع ضمة', note: 'تاء مشددة بالضم: تُّ', example: 'سِتُّونَ' }
    ],
    madd: [
      { formula: 'تَ + ا = تَا', short: 'تَ', long: 'تَا', type: 'مد بالألف', example: 'تَاج', note: 'نمد التاء بالألف: تَا' },
      { formula: 'تِ + ي = تِي', short: 'تِ', long: 'تِي', type: 'مد بالياء', example: 'تِين', note: 'نمد التاء بالياء: تِي' },
      { formula: 'تُ + و = تُو', short: 'تُ', long: 'تُو', type: 'مد بالواو', example: 'تُوت', note: 'نمد التاء بالواو: تُو' }
    ],
    tanween: [
      { char: 'تً', name: 'تنوين الفتح (ـً)', sound: 'تَنْ', example: 'بِنْتًا', note: 'تَنْ' },
      { char: 'تٍ', name: 'تنوين الكسر (ـٍ)', sound: 'تِنْ', example: 'بِنْتٍ', note: 'تِنْ' },
      { char: 'تٌ', name: 'تنوين الضم (ـٌ)', sound: 'تُنْ', example: 'بِنْتٌ', note: 'تُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'تـ', word: 'تُفَّاح', targetPart: 'تـ', exampleEmoji: '🍎' },
      { pos: 'وسط الكلمة', form: 'ـتـ', word: 'كِتَاب', targetPart: 'ـتـ', exampleEmoji: '📖' },
      { pos: 'نهاية الكلمة', form: 'ـت', word: 'بِنْت', targetPart: 'ـت', exampleEmoji: '👧' }
    ],
    vocabulary: [
      { word: 'تُفَّاح', meaning: 'تفاح', emoji: '🍎', soundDesc: 'تفاح أحمر حلو ومقرمش' },
      { word: 'تَمْر', meaning: 'تمر', emoji: '🌴', soundDesc: 'تمر غني بالطاقة والخير' },
      { word: 'تَاج', meaning: 'تاج', emoji: '👑', soundDesc: 'تاج ذهبي لامع' },
      { word: 'تِين', meaning: 'تين', emoji: '🫐', soundDesc: 'تين طيب من ثمار الجنة' },
      { word: 'تِمْسَاح', meaning: 'تمساح', emoji: '🐊', soundDesc: 'تمساح قوي يعيش قرب النهر' }
    ],
    tracingPath: 'M 180,60 L 180,90 Q 180,120 100,120 Q 20,120 20,90 L 20,60',
    childTip: 'صحن لطيف على السطر ونضع نقطتين جميلتين في داخله!'
  },
  {
    id: 'thaa',
    letter: 'ث',
    name: 'ثَاء',
    phonic: 'ثـَ',
    description: 'هذا حرف الثاء.. نخرج طرف لساننا الصغير بلطف، وله 3 نقاط مثل حبات الثلج!',
    shortVowels: [
      { char: 'ثَ', vowelName: 'فَتْحَة', sound: 'ثَ', example: 'ثَعْلَب', note: 'ثاء مع الفتحة: ثَ' },
      { char: 'ثِ', vowelName: 'كَسْرَة', sound: 'ثِ', example: 'ثِيَاب', note: 'ثاء مع الكسرة: ثِ' },
      { char: 'ثُ', vowelName: 'ضَمَّة', sound: 'ثُ', example: 'ثُعْبَان', note: 'ثاء مع الضمة: ثُ' }
    ],
    sukoon: { char: 'ثْ', note: 'السكون يجعل الثاء هادئة: ثْ', example: 'مِثْل' },
    shaddah: [
      { char: 'ثَّ', name: 'شَدَّة مع فتحة', note: 'ثاء قوية: ثَّ', example: 'يَثَّاقَل' },
      { char: 'ثِّ', name: 'شَدَّة مع كسرة', note: 'ثاء بالكسر: ثِّ', example: 'يُثَبِّت' },
      { char: 'ثُّ', name: 'شَدَّة مع ضمة', note: 'ثاء بالضم: ثُّ', example: 'يَبُثُّ' }
    ],
    madd: [
      { formula: 'ثَ + ا = ثَا', short: 'ثَ', long: 'ثَا', type: 'مد بالألف', example: 'ثَالِث', note: 'ثَا' },
      { formula: 'ثِ + ي = ثِي', short: 'ثِ', long: 'ثِي', type: 'مد بالياء', example: 'كَثِير', note: 'ثِي' },
      { formula: 'ثُ + و = ثُو', short: 'ثُ', long: 'ثُو', type: 'مد بالواو', example: 'ثُوم', note: 'ثُو' }
    ],
    tanween: [
      { char: 'ثً', name: 'تنوين الفتح (ـً)', sound: 'ثَنْ', example: 'أَثَاثًا', note: 'ثَنْ' },
      { char: 'ثٍ', name: 'تنوين الكسر (ـٍ)', sound: 'ثِنْ', example: 'أَثَاثٍ', note: 'ثِنْ' },
      { char: 'ثٌ', name: 'تنوين الضم (ـٌ)', sound: 'ثُنْ', example: 'أَثَاثٌ', note: 'ثُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'ثـ', word: 'ثَعْلَب', targetPart: 'ثـ', exampleEmoji: '🦊' },
      { pos: 'وسط الكلمة', form: 'ـثـ', word: 'مِثْقَاب', targetPart: 'ـثـ', exampleEmoji: '🔩' },
      { pos: 'نهاية الكلمة', form: 'ـث', word: 'مُثَلَّث', targetPart: 'ـث', exampleEmoji: '📐' }
    ],
    vocabulary: [
      { word: 'ثَعْلَب', meaning: 'ثعلب', emoji: '🦊', soundDesc: 'ثعلب ذكي ولطيف' },
      { word: 'ثَوْب', meaning: 'ثوب', emoji: '👕', soundDesc: 'ثوب نظيف وأنيق' },
      { word: 'ثَلْج', meaning: 'ثلج', emoji: '❄️', soundDesc: 'ثلج أبيض وبارد' },
      { word: 'ثُوم', meaning: 'ثوم', emoji: '🧄', soundDesc: 'ثوم مفيد للصحة' },
      { word: 'ثِمَار', meaning: 'ثمار', emoji: '🍇', soundDesc: 'ثمار لذيذة يانعة' }
    ],
    tracingPath: 'M 180,60 L 180,90 Q 180,120 100,120 Q 20,120 20,90 L 20,60',
    childTip: 'نفس صحن الباء والتاء، لكن نضع فوقه ثلاث نقاط كأنها قبعة!'
  },
  {
    id: 'jeem',
    letter: 'ج',
    name: 'جِيم',
    phonic: 'جـَ',
    description: 'هذا حرف الجيم.. حاجب لطيف في الأعلى وبطن كبير في داخله نقطة!',
    shortVowels: [
      { char: 'جَ', vowelName: 'فَتْحَة', sound: 'جَ', example: 'جَمَل', note: 'جيم مع الفتحة: جَ' },
      { char: 'جِ', vowelName: 'كَسْرَة', sound: 'جِ', example: 'جِدَار', note: 'جيم مع الكسرة: جِ' },
      { char: 'جُ', vowelName: 'ضَمَّة', sound: 'جُ', example: 'جُبْن', note: 'جيم مع الضمة: جُ' }
    ],
    sukoon: { char: 'جْ', note: 'السكون يجعل الجيم هادئة: جْ', example: 'نَجْم' },
    shaddah: [
      { char: 'جَّ', name: 'شَدَّة مع فتحة', note: 'جيم قوية: جَّ', example: 'نَجَّار' },
      { char: 'جِّ', name: 'شَدَّة مع كسرة', note: 'جيم بالكسر: جِّ', example: 'يُجَهِّز' },
      { char: 'جُّ', name: 'شَدَّة مع ضمة', note: 'جيم بالضم: جُّ', example: 'يَحُجُّ' }
    ],
    madd: [
      { formula: 'جَ + ا = جَا', short: 'جَ', long: 'جَا', type: 'مد بالألف', example: 'جَامِع', note: 'جَا' },
      { formula: 'جِ + ي = جِي', short: 'جِ', long: 'جِي', type: 'مد بالياء', example: 'جِيرَان', note: 'جِي' },
      { formula: 'جُ + و = جُو', short: 'جُ', long: 'جُو', type: 'مد بالواو', example: 'جُود', note: 'جُو' }
    ],
    tanween: [
      { char: 'جً', name: 'تنوين الفتح (ـً)', sound: 'جَنْ', example: 'فَرَجًا', note: 'جَنْ' },
      { char: 'جٍ', name: 'تنوين الكسر (ـٍ)', sound: 'جِنْ', example: 'فَرَجٍ', note: 'جِنْ' },
      { char: 'جٌ', name: 'تنوين الضم (ـٌ)', sound: 'جُنْ', example: 'فَرَجٌ', note: 'جُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'جـ', word: 'جَمَل', targetPart: 'جـ', exampleEmoji: '🐪' },
      { pos: 'وسط الكلمة', form: 'ـجـ', word: 'شَجَرَة', targetPart: 'ـجـ', exampleEmoji: '🌳' },
      { pos: 'نهاية الكلمة', form: 'ـج', word: 'تَاج', targetPart: 'ـج', exampleEmoji: '👑' }
    ],
    vocabulary: [
      { word: 'جَمَل', meaning: 'جمل', emoji: '🐪', soundDesc: 'جمل صبور سفينة الصحراء' },
      { word: 'جَزَر', meaning: 'جزر', emoji: '🥕', soundDesc: 'جزر برتقالي يقوي النظر' },
      { word: 'جُبْن', meaning: 'جبن', emoji: '🧀', soundDesc: 'جبن لذيذ ومغذي' },
      { word: 'جَرَس', meaning: 'جرس', emoji: '🔔', soundDesc: 'جرس المدرسة يرن بمرح' },
      { word: 'جَبَل', meaning: 'جبل', emoji: '⛰️', soundDesc: 'جبل شامخ وعالٍ' }
    ],
    tracingPath: 'M 140,40 L 70,40 Q 50,40 60,60 Q 80,80 120,80 Q 150,110 100,130 Q 50,130 50,110',
    childTip: 'خط مائل صغير، ثم بطن مدور كبير، ونضع النقطة في بطنه!'
  },
  {
    id: 'haa',
    letter: 'ح',
    name: 'حَاء',
    phonic: 'حـَ',
    description: 'هذا حرف الحاء.. مثل الجيم تماماً لكن بطنه نظيف بدون أي نقطة!',
    shortVowels: [
      { char: 'حَ', vowelName: 'فَتْحَة', sound: 'حَ', example: 'حَلِيب', note: 'حاء مع الفتحة: حَ' },
      { char: 'حِ', vowelName: 'كَسْرَة', sound: 'حِ', example: 'حِصَان', note: 'حاء مع الكسرة: حِ' },
      { char: 'حُ', vowelName: 'ضَمَّة', sound: 'حُ', example: 'حُوت', note: 'حاء مع الضمة: حُ' }
    ],
    sukoon: { char: 'حْ', note: 'السكون يجعل الحاء هادئة: حْ', example: 'بَحْر' },
    shaddah: [
      { char: 'حَّ', name: 'شَدَّة مع فتحة', note: 'حاء قوية: حَّ', example: 'تَفَّاح' },
      { char: 'حِّ', name: 'شَدَّة مع كسرة', note: 'حاء بالكسر: حِّ', example: 'يُحِبُّ' },
      { char: 'حُّ', name: 'شَدَّة مع ضمة', note: 'حاء بالضم: حُّ', example: 'شَحٌّ' }
    ],
    madd: [
      { formula: 'حَ + ا = حَا', short: 'حَ', long: 'حَا', type: 'مد بالألف', example: 'حَافِلَة', note: 'حَا' },
      { formula: 'حِ + ي = حِي', short: 'حِ', long: 'حِي', type: 'مد بالياء', example: 'حِيتَان', note: 'حِي' },
      { formula: 'حُ + و = حُو', short: 'حُ', long: 'حُو', type: 'مد بالواو', example: 'حُوت', note: 'حُو' }
    ],
    tanween: [
      { char: 'حً', name: 'تنوين الفتح (ـً)', sound: 'حَنْ', example: 'صَبَاحًا', note: 'حَنْ' },
      { char: 'حٍ', name: 'تنوين الكسر (ـٍ)', sound: 'حِنْ', example: 'صَبَاحٍ', note: 'حِنْ' },
      { char: 'حٌ', name: 'تنوين الضم (ـٌ)', sound: 'حُنْ', example: 'صَبَاحٌ', note: 'حُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'حـ', word: 'حِصَان', targetPart: 'حـ', exampleEmoji: '🐎' },
      { pos: 'وسط الكلمة', form: 'ـحـ', word: 'بَحْر', targetPart: 'ـحـ', exampleEmoji: '🌊' },
      { pos: 'نهاية الكلمة', form: 'ـح', word: 'تُفَّاح', targetPart: 'ـح', exampleEmoji: '🍎' }
    ],
    vocabulary: [
      { word: 'حِصَان', meaning: 'حصان', emoji: '🐎', soundDesc: 'حصان رشيق يركض سريعاً' },
      { word: 'حَلِيب', meaning: 'حليب', emoji: '🥛', soundDesc: 'حليب أبيض يمنحنا القوة' },
      { word: 'حُوت', meaning: 'حوت', emoji: '🐋', soundDesc: 'حوت أزرق عملاق في المحيط' },
      { word: 'حَقِيبَة', meaning: 'حقيبة', emoji: '🎒', soundDesc: 'حقيبة نضع فيها دفاترنا' },
      { word: 'حَدِيقَة', meaning: 'حديقة', emoji: '🏡', soundDesc: 'حديقة خضراء جميلة' }
    ],
    tracingPath: 'M 140,40 L 70,40 Q 50,40 60,60 Q 80,80 120,80 Q 150,110 100,130 Q 50,130 50,110',
    childTip: 'خط مائل، ثم بطن كبير مدور وبدون أي نقطة!'
  },
  {
    id: 'khaa',
    letter: 'خ',
    name: 'خَاء',
    phonic: 'خـَ',
    description: 'هذا حرف الخاء.. فوق رأسه نقطة كأنه يضع قبعة جميلة!',
    shortVowels: [
      { char: 'خَ', vowelName: 'فَتْحَة', sound: 'خَ', example: 'خَرُوف', note: 'خاء مع الفتحة: خَ' },
      { char: 'خِ', vowelName: 'كَسْرَة', sound: 'خِ', example: 'خِيَار', note: 'خاء مع الكسرة: خِ' },
      { char: 'خُ', vowelName: 'ضَمَّة', sound: 'خُ', example: 'خُبْز', note: 'خاء مع الضمة: خُ' }
    ],
    sukoon: { char: 'خْ', note: 'السكون يجعل الخاء هادئة: خْ', example: 'نَخْلَة' },
    shaddah: [
      { char: 'خَّ', name: 'شَدَّة مع فتحة', note: 'خاء قوية: خَّ', example: 'فَخَّار' },
      { char: 'خِّ', name: 'شَدَّة مع كسرة', note: 'خاء بالكسر: خِّ', example: 'يُخَفِّف' },
      { char: 'خُّ', name: 'شَدَّة مع ضمة', note: 'خاء بالضم: خُّ', example: 'يَضُخُّ' }
    ],
    madd: [
      { formula: 'خَ + ا = خَا', short: 'خَ', long: 'خَا', type: 'مد بالألف', example: 'خَاتَم', note: 'خَا' },
      { formula: 'خِ + ي = خِي', short: 'خِ', long: 'خِي', type: 'مد بالياء', example: 'نَخِيل', note: 'خِي' },
      { formula: 'خُ + و = خُو', short: 'خُ', long: 'خُو', type: 'مد بالواو', example: 'خُوخ', note: 'خُو' }
    ],
    tanween: [
      { char: 'خً', name: 'تنوين الفتح (ـً)', sound: 'خَنْ', example: 'فَرْخًا', note: 'خَنْ' },
      { char: 'خٍ', name: 'تنوين الكسر (ـٍ)', sound: 'خِنْ', example: 'فَرْخٍ', note: 'خِنْ' },
      { char: 'خٌ', name: 'تنوين الضم (ـٌ)', sound: 'خُنْ', example: 'فَرْخٌ', note: 'خُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'خـ', word: 'خَرُوف', targetPart: 'خـ', exampleEmoji: '🐑' },
      { pos: 'وسط الكلمة', form: 'ـخـ', word: 'نَخْلَة', targetPart: 'ـخـ', exampleEmoji: '🌴' },
      { pos: 'نهاية الكلمة', form: 'ـخ', word: 'بِطِّيخ', targetPart: 'ـخ', exampleEmoji: '🍉' }
    ],
    vocabulary: [
      { word: 'خَرُوف', meaning: 'خروف', emoji: '🐑', soundDesc: 'خروف أبيض له صوف دافئ' },
      { word: 'خُبْز', meaning: 'خبز', emoji: '🍞', soundDesc: 'خبز طازج وشهي' },
      { word: 'خِيَار', meaning: 'خيار', emoji: '🥒', soundDesc: 'خيار أخضر منعش' },
      { word: 'خَاتَم', meaning: 'خاتم', emoji: '💍', soundDesc: 'خاتم فضي يلمع' },
      { word: 'خُوخ', meaning: 'خوخ', emoji: '🍑', soundDesc: 'خوخ حلو وعصيري' }
    ],
    tracingPath: 'M 140,40 L 70,40 Q 50,40 60,60 Q 80,80 120,80 Q 150,110 100,130 Q 50,130 50,110',
    childTip: 'خط مائل، بطن مدور، ونضع نقطة واحدة فوق الرأس!'
  },
  {
    id: 'daal',
    letter: 'د',
    name: 'دَال',
    phonic: 'دَ',
    description: 'هذا حرف الدال.. جالس على السطر يفتح ذراعيه كأنه يبتسم!',
    shortVowels: [
      { char: 'دَ', vowelName: 'فَتْحَة', sound: 'دَ', example: 'دَرَّاجَة', note: 'دال مع الفتحة: دَ' },
      { char: 'دِ', vowelName: 'كَسْرَة', sound: 'دِ', example: 'دِيك', note: 'دال مع الكسرة: دِ' },
      { char: 'دُ', vowelName: 'ضَمَّة', sound: 'دُ', example: 'دُبّ', note: 'دال مع الضمة: دُ' }
    ],
    sukoon: { char: 'دْ', note: 'السكون يجعل الدال هادئة: دْ', example: 'بَدْر' },
    shaddah: [
      { char: 'دَّ', name: 'شَدَّة مع فتحة', note: 'دال قوية: دَّ', example: 'مُدَرِّس' },
      { char: 'دِّ', name: 'شَدَّة مع كسرة', note: 'دال بالكسر: دِّ', example: 'يُؤَدِّي' },
      { char: 'دُّ', name: 'شَدَّة مع ضمة', note: 'دال بالضم: دُّ', example: 'يَعُدُّ' }
    ],
    madd: [
      { formula: 'دَ + ا = دَا', short: 'دَ', long: 'دَا', type: 'مد بالألف', example: 'دَار', note: 'دَا' },
      { formula: 'دِ + ي = دِي', short: 'دِ', long: 'دِي', type: 'مد بالياء', example: 'دِيك', note: 'دِي' },
      { formula: 'دُ + و = دُو', short: 'دُ', long: 'دُو', type: 'مد بالواو', example: 'دُودَة', note: 'دُو' }
    ],
    tanween: [
      { char: 'دً', name: 'تنوين الفتح (ـً)', sound: 'دَنْ', example: 'وَلَدًا', note: 'دَنْ' },
      { char: 'دٍ', name: 'تنوين الكسر (ـٍ)', sound: 'دِنْ', example: 'وَلَدٍ', note: 'دِنْ' },
      { char: 'دٌ', name: 'تنوين الضم (ـٌ)', sound: 'دُنْ', example: 'وَلَدٌ', note: 'دُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'د', word: 'دُبّ', targetPart: 'د', exampleEmoji: '🐻' },
      { pos: 'وسط الكلمة', form: 'ـد', word: 'هَدِيَّة', targetPart: 'ـد', exampleEmoji: '🎁' },
      { pos: 'نهاية الكلمة', form: 'ـد', word: 'وَلَد', targetPart: 'ـد', exampleEmoji: '👦' }
    ],
    vocabulary: [
      { word: 'دُبّ', meaning: 'دب', emoji: '🐻', soundDesc: 'دب بني لطيف يحب العسل' },
      { word: 'دِيك', meaning: 'ديك', emoji: '🐓', soundDesc: 'ديك يصيح كوكو في الصباح' },
      { word: 'دَرَّاجَة', meaning: 'دراجة', emoji: '🚲', soundDesc: 'دراجة سريعة نركبها بالحديقة' },
      { word: 'دَفْتَر', meaning: 'دفتر', emoji: '📓', soundDesc: 'دفتر نظيف نكتب فيه' },
      { word: 'دُولْفِين', meaning: 'دولفين', emoji: '🐬', soundDesc: 'دولفين صديق مرح' }
    ],
    tracingPath: 'M 140,50 Q 80,70 80,110 L 140,110',
    childTip: 'ننزل بخط مائل من الأعلى إلى السطر، ثم نمشي أفقياً على السطر!'
  },
  {
    id: 'ra',
    letter: 'ر',
    name: 'رَاء',
    phonic: 'رَ',
    description: 'هذا حرف الراء.. مثل الزحليقة الممتعة، ينزل من السطر برفق!',
    shortVowels: [
      { char: 'رَ', vowelName: 'فَتْحَة', sound: 'رَ', example: 'رَمْل', note: 'راء مع الفتحة: رَ' },
      { char: 'رِ', vowelName: 'كَسْرَة', sound: 'رِ', example: 'رِيشَة', note: 'راء مع الكسرة: رِ' },
      { char: 'رُ', vowelName: 'ضَمَّة', sound: 'رُ', example: 'رُمَّان', note: 'راء مع الضمة: رُ' }
    ],
    sukoon: { char: 'رْ', note: 'السكون يجعل الراء هادئة: رْ', example: 'بَرْد' },
    shaddah: [
      { char: 'رَّ', name: 'شَدَّة مع فتحة', note: 'راء قوية: رَّ', example: 'دَرَّاجَة' },
      { char: 'رِّ', name: 'شَدَّة مع كسرة', note: 'راء بالكسر: رِّ', example: 'مُرَبِّي' },
      { char: 'رُّ', name: 'شَدَّة مع ضمة', note: 'راء بالضم: رُّ', example: 'يَمُرُّ' }
    ],
    madd: [
      { formula: 'رَ + ا = رَا', short: 'رَ', long: 'رَا', type: 'مد بالألف', example: 'رَاسِم', note: 'رَا' },
      { formula: 'رِ + ي = رِي', short: 'رِ', long: 'رِي', type: 'مد بالياء', example: 'رِيشَة', note: 'رِي' },
      { formula: 'رُ + و = رُو', short: 'رُ', long: 'رُو', type: 'مد بالواو', example: 'رُوح', note: 'رُو' }
    ],
    tanween: [
      { char: 'رً', name: 'تنوين الفتح (ـً)', sound: 'رَنْ', example: 'قَمَرًا', note: 'رَنْ' },
      { char: 'رٍ', name: 'تنوين الكسر (ـٍ)', sound: 'رِنْ', example: 'قَمَرٍ', note: 'رِنْ' },
      { char: 'رٌ', name: 'تنوين الضم (ـٌ)', sound: 'رُنْ', example: 'قَمَرٌ', note: 'رُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'ر', word: 'رُمَّان', targetPart: 'ر', exampleEmoji: '🍎' },
      { pos: 'وسط الكلمة', form: 'ـر', word: 'كُرَة', targetPart: 'ـر', exampleEmoji: '⚽' },
      { pos: 'نهاية الكلمة', form: 'ـر', word: 'قَمَر', targetPart: 'ـر', exampleEmoji: '🌙' }
    ],
    vocabulary: [
      { word: 'رُمَّان', meaning: 'رمان', emoji: '🍎', soundDesc: 'رمان أحمر به حبات حلوة' },
      { word: 'رِيشَة', meaning: 'ريشة', emoji: '🪶', soundDesc: 'ريشة طائر خفيفة وجميلة' },
      { word: 'رَسَّام', meaning: 'رسام', emoji: '👨‍🎨', soundDesc: 'رسام يرسم لوحة رائعة' },
      { word: 'رَمْل', meaning: 'رمل', emoji: '🏖️', soundDesc: 'رمل الشاطئ الذهبي' },
      { word: 'رَأْس', meaning: 'رأس', emoji: '👦', soundDesc: 'رأس فيه عقلنا المفكر' }
    ],
    tracingPath: 'M 130,50 L 120,70 Q 100,120 50,130',
    childTip: 'نبدأ فوق السطر قليلاً ثم نتزحلق بميلان تحت السطر!'
  },
  {
    id: 'seen',
    letter: 'س',
    name: 'سِين',
    phonic: 'سـَ',
    description: 'هذا حرف السين.. له ثلاث أسنان جميلة وصحن مدور كبير!',
    shortVowels: [
      { char: 'سَ', vowelName: 'فَتْحَة', sound: 'سَ', example: 'سَمَكَة', note: 'سين مع الفتحة: سَ' },
      { char: 'سِ', vowelName: 'كَسْرَة', sound: 'سِ', example: 'سِتَار', note: 'سين مع الكسرة: سِ' },
      { char: 'سُ', vowelName: 'ضَمَّة', sound: 'سُ', example: 'سُلَحْفَاة', note: 'سين مع الضمة: سُ' }
    ],
    sukoon: { char: 'سْ', note: 'السكون يجعل السين هادئة: سْ', example: 'شَمْس' },
    shaddah: [
      { char: 'سَّ', name: 'شَدَّة مع فتحة', note: 'سين قوية: سَّ', example: 'رَسَّام' },
      { char: 'سِّ', name: 'شَدَّة مع كسرة', note: 'سين بالكسر: سِّ', example: 'يُيَسِّر' },
      { char: 'سُّ', name: 'شَدَّة مع ضمة', note: 'سين بالضم: سُّ', example: 'يَمَسُّ' }
    ],
    madd: [
      { formula: 'سَ + ا = سَا', short: 'سَ', long: 'سَا', type: 'مد بالألف', example: 'سَاعَة', note: 'سَا' },
      { formula: 'سِ + ي = سِي', short: 'سِ', long: 'سِي', type: 'مد بالياء', example: 'سِيرَة', note: 'سِي' },
      { formula: 'سُ + و = سُو', short: 'سُ', long: 'سُو', type: 'مد بالواو', example: 'سُور', note: 'سُو' }
    ],
    tanween: [
      { char: 'سً', name: 'تنوين الفتح (ـً)', sound: 'سَنْ', example: 'دَرْسًا', note: 'سَنْ' },
      { char: 'سٍ', name: 'تنوين الكسر (ـٍ)', sound: 'سِنْ', example: 'دَرْسٍ', note: 'سِنْ' },
      { char: 'سٌ', name: 'تنوين الضم (ـٌ)', sound: 'سُنْ', example: 'دَرْسٌ', note: 'سُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'سـ', word: 'سَمَكَة', targetPart: 'سـ', exampleEmoji: '🐟' },
      { pos: 'وسط الكلمة', form: 'ـسـ', word: 'مَسْجِد', targetPart: 'ـسـ', exampleEmoji: '🕌' },
      { pos: 'نهاية الكلمة', form: 'ـس', word: 'شَمْس', targetPart: 'ـس', exampleEmoji: '☀️' }
    ],
    vocabulary: [
      { word: 'سَمَكَة', meaning: 'سمكة', emoji: '🐟', soundDesc: 'سمكة سريعة في البحر' },
      { word: 'سَيَّارَة', meaning: 'سيارة', emoji: '🚗', soundDesc: 'سيارة جميلة تسير على الطريق' },
      { word: 'سَاعَة', meaning: 'ساعة', emoji: '⏰', soundDesc: 'ساعة تدق تنبهنا للوقت' },
      { word: 'سُلَحْفَاة', meaning: 'سلحفاة', emoji: '🐢', soundDesc: 'سلحفاة هادئة وحكيمة' },
      { word: 'سَفِينَة', meaning: 'سفينة', emoji: '🚢', soundDesc: 'سفينة تبحر في الأمواج' }
    ],
    tracingPath: 'M 170,60 Q 155,90 140,60 Q 125,90 110,60 Q 95,120 50,120 Q 20,120 20,90',
    childTip: 'سن أول، سن ثانٍ، سن ثالث، ثم صحن كبير ينزل تحت السطر!'
  },
  {
    id: 'meem',
    letter: 'م',
    name: 'مِيم',
    phonic: 'مـَ',
    description: 'هذا حرف الميم.. دائرة صغيرة لطيفة وجميلة ولها ذراع ينزل للأسفل!',
    shortVowels: [
      { char: 'مَ', vowelName: 'فَتْحَة', sound: 'مَ', example: 'مَوْز', note: 'ميم مع الفتحة: مَ' },
      { char: 'مِ', vowelName: 'كَسْرَة', sound: 'مِ', example: 'مِقَصّ', note: 'ميم مع الكسرة: مِ' },
      { char: 'مُ', vowelName: 'ضَمَّة', sound: 'مُ', example: 'مُعَلِّمَة', note: 'ميم مع الضمة: مُ' }
    ],
    sukoon: { char: 'مْ', note: 'السكون يجعل الميم هادئة: مْ', example: 'نَمْل' },
    shaddah: [
      { char: 'مَّ', name: 'شَدَّة مع فتحة', note: 'ميم قوية: مَّ', example: 'شَمَّام' },
      { char: 'مِّ', name: 'شَدَّة مع كسرة', note: 'ميم بالكسر: مِّ', example: 'مُمَرِّضَة' },
      { char: 'مُّ', name: 'شَدَّة مع ضمة', note: 'ميم بالضم: مُّ', example: 'يَضُمُّ' }
    ],
    madd: [
      { formula: 'مَ + ا = مَا', short: 'مَ', long: 'مَا', type: 'مد بالألف', example: 'مَاء', note: 'مَا' },
      { formula: 'مِ + ي = مِي', short: 'مِ', long: 'مِي', type: 'مد بالياء', example: 'مِيلَاد', note: 'مِي' },
      { formula: 'مُ + و = مُو', short: 'مُ', long: 'مُو', type: 'مد بالواو', example: 'مُوز', note: 'مُو' }
    ],
    tanween: [
      { char: 'مً', name: 'تنوين الفتح (ـً)', sound: 'مَنْ', example: 'قَلَمًا', note: 'مَنْ' },
      { char: 'مٍ', name: 'تنوين الكسر (ـٍ)', sound: 'مِنْ', example: 'قَلَمٍ', note: 'مِنْ' },
      { char: 'مٌ', name: 'تنوين الضم (ـٌ)', sound: 'مُنْ', example: 'قَلَمٌ', note: 'مُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'مـ', word: 'مَوْز', targetPart: 'مـ', exampleEmoji: '🍌' },
      { pos: 'وسط الكلمة', form: 'ـمـ', word: 'شَمْس', targetPart: 'ـمـ', exampleEmoji: '☀️' },
      { pos: 'نهاية الكلمة', form: 'ـم', word: 'قَلَم', targetPart: 'ـم', exampleEmoji: '✏️' }
    ],
    vocabulary: [
      { word: 'مَوْز', meaning: 'موز', emoji: '🍌', soundDesc: 'موز أصفر حلو ولذيذ' },
      { word: 'مَسْجِد', meaning: 'مسجد', emoji: '🕌', soundDesc: 'مسجد نصلي فيه' },
      { word: 'مِقَصّ', meaning: 'مقص', emoji: '✂️', soundDesc: 'مقص نقص به الورق بحذر' },
      { word: 'مَدْرَسَة', meaning: 'مدرسة', emoji: '🏫', soundDesc: 'مدرستنا الجميلة نتعلم فيها' },
      { word: 'مَطَر', meaning: 'مطر', emoji: '🌧️', soundDesc: 'مطر يسقي الزرع وينعش الأرض' }
    ],
    tracingPath: 'M 140,80 A 20,20 0 1,0 100,80 L 70,80 L 70,130',
    childTip: 'دائرة صغيرة من اليمين، نمشي على السطر، ثم ننزل عصا مستقيمة للأسفل!'
  },
  {
    id: 'noon',
    letter: 'ن',
    name: 'نُون',
    phonic: 'نـَ',
    description: 'هذا حرف النون.. صحن غويط وفي قلبه نقطة تلمع كنجمة!',
    shortVowels: [
      { char: 'نَ', vowelName: 'فَتْحَة', sound: 'نَ', example: 'نَحْلَة', note: 'نون مع الفتحة: نَ' },
      { char: 'نِ', vowelName: 'كَسْرَة', sound: 'نِ', example: 'نِسْر', note: 'نون مع الكسرة: نِ' },
      { char: 'نُ', vowelName: 'ضَمَّة', sound: 'نُ', example: 'نُجُوم', note: 'نون مع الضمة: نُ' }
    ],
    sukoon: { char: 'نْ', note: 'السكون يجعل النون هادئة: نْ', example: 'عَيْن' },
    shaddah: [
      { char: 'نَّ', name: 'شَدَّة مع فتحة', note: 'نون قوية: نَّ', example: 'جَنَّة' },
      { char: 'نِّ', name: 'شَدَّة مع كسرة', note: 'نون بالكسر: نِّ', example: 'يُغَنِّي' },
      { char: 'نُّ', name: 'شَدَّة مع ضمة', note: 'نون بالضم: نُّ', example: 'يَظُنُّ' }
    ],
    madd: [
      { formula: 'نَ + ا = نَا', short: 'نَ', long: 'نَا', type: 'مد بالألف', example: 'نَار', note: 'نَا' },
      { formula: 'نِ + ي = نِي', short: 'نِ', long: 'نِي', type: 'مد بالياء', example: 'تِين', note: 'نِي' },
      { formula: 'نُ + و = نُو', short: 'نُ', long: 'نُو', type: 'مد بالواو', example: 'نُور', note: 'نُو' }
    ],
    tanween: [
      { char: 'نً', name: 'تنوين الفتح (ـً)', sound: 'نَنْ', example: 'لَبَنًا', note: 'نَنْ' },
      { char: 'نٍ', name: 'تنوين الكسر (ـٍ)', sound: 'نِنْ', example: 'لَبَنٍ', note: 'نِنْ' },
      { char: 'نٌ', name: 'تنوين الضم (ـٌ)', sound: 'نُنْ', example: 'لَبَنٌ', note: 'نُنْ' }
    ],
    positions: [
      { pos: 'بداية الكلمة', form: 'نـ', word: 'نَحْلَة', targetPart: 'نـ', exampleEmoji: '🐝' },
      { pos: 'وسط الكلمة', form: 'ـنـ', word: 'عِنَب', targetPart: 'ـنـ', exampleEmoji: '🍇' },
      { pos: 'نهاية الكلمة', form: 'ـن', word: 'عَيْن', targetPart: 'ـن', exampleEmoji: '👁️' }
    ],
    vocabulary: [
      { word: 'نَحْلَة', meaning: 'نحلة', emoji: '🐝', soundDesc: 'نحلة نشيطة تصنع العسل' },
      { word: 'نَجْمَة', meaning: 'نجمة', emoji: '⭐', soundDesc: 'نجمة تلمع في السماء ليلاً' },
      { word: 'نَمْلَة', meaning: 'نملة', emoji: '🐜', soundDesc: 'نملة مجتهدة تحب العمل' },
      { word: 'نَهْر', meaning: 'نهر', emoji: '🏞️', soundDesc: 'نهر ماؤه عذب وصافٍ' },
      { word: 'نَافِذَة', meaning: 'نافذة', emoji: '🪟', soundDesc: 'نافذة يدخل منها ضوء الشمس' }
    ],
    tracingPath: 'M 160,60 Q 150,130 90,130 Q 30,130 30,60',
    childTip: 'صحن عميق ينزل تحت السطر، ونضع نقطة واحدة في وسطه!'
  }
];

// Helper to get letter by id
export const getLetterById = (id: string): LetterItem => {
  const found = ARABIC_LETTERS.find(l => l.id === id);
  return found || ARABIC_LETTERS[0];
};

// All 28 Arabic letter symbols
export const FULL_ALPHABET_SYMBOLS = [
  'أ', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 
  'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 
  'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 
  'ك', 'ل', 'م', 'ن', 'هـ', 'و', 'ي'
];
