export interface FloatingExperimentItem {
  id: string;
  name: string;
  emoji: string;
  behavior: 'floats' | 'sinks';
  explanation: string;
}

export const FLOATING_ITEMS: FloatingExperimentItem[] = [
  {
    id: 'wood',
    name: 'قِطْعَةُ خَشَب',
    emoji: '🪵',
    behavior: 'floats',
    explanation: 'الخشب خفيف وكثافته أقل من الماء، لذلك يطفو فوق السطح مثل السفينة!'
  },
  {
    id: 'stone',
    name: 'حَجَرٌ صَغِير',
    emoji: '🪨',
    behavior: 'sinks',
    explanation: 'الحجر ثقيل وكثيف، لذلك ينزل ويغرق مباشرة في قاع الحوض!'
  },
  {
    id: 'apple',
    name: 'تُفَّاحَة',
    emoji: '🍎',
    behavior: 'floats',
    explanation: 'التفاحة تحتوي على هواء بداخلها، لذلك تطفو وتسبح فوق الماء!'
  },
  {
    id: 'coin',
    name: 'قِطْعَةٌ نَقْدِيَّة',
    emoji: '🪙',
    behavior: 'sinks',
    explanation: 'القطعة المعدنية ثقيلة جداً بالنسبة لحجمها، فتغوص إلى القاع!'
  },
  {
    id: 'feather',
    name: 'رِيشَةٌ خَفِيفَة',
    emoji: '🪶',
    behavior: 'floats',
    explanation: 'الريشة خفيفة جداً تطفو على سطح الماء برقة!'
  },
  {
    id: 'key',
    name: 'مِفْتَاحُ حَدِيد',
    emoji: '🔑',
    behavior: 'sinks',
    explanation: 'المفتاح مصنوع من الحديد الثقيل، لذلك يغرق في الماء!'
  },
  {
    id: 'ball',
    name: 'كُرَةُ بِلَاسْتِيك',
    emoji: '⚽',
    behavior: 'floats',
    explanation: 'الكرة البلاستيكية مليئة بالهواء وتطفو بسهولة!'
  }
];

export interface PlantStage {
  step: number;
  title: string;
  emoji: string;
  description: string;
}

export const PLANT_LIFECYCLE: PlantStage[] = [
  {
    step: 1,
    title: 'البَذْرَةُ فِي التُّرْبَة',
    emoji: '🌰',
    description: 'نغرس البذرة الصغيرة في التربة الخصبة ونسقيها بالماء النقي.'
  },
  {
    step: 2,
    title: 'الإِنْبَاتُ وَالجُذُور',
    emoji: '🌱',
    description: 'تخرج الجذور الصغيرة لتثبيت النبتة في الأرض وامتصاص الماء.'
  },
  {
    step: 3,
    title: 'السَّاقُ وَالأَوْرَاق',
    emoji: '🌿',
    description: 'تنمو الساق نحو ضوء الشمس الدافئ وتظهر الأوراق الخضراء الجميلة.'
  },
  {
    step: 4,
    title: 'الأَزْهَارُ وَالثِّمَار',
    emoji: '🌸🍎',
    description: 'تتفتح الأزهار ثم تتحول إلى ثمار لذيذة نقطفها ونأكلها.'
  }
];

export interface MatterState {
  state: string;
  name: string;
  example: string;
  emoji: string;
  detail: string;
}

export const WATER_STATES: MatterState[] = [
  {
    state: 'solid',
    name: 'الحَالَةُ الصَّلْبَة (الجَلِيد)',
    example: 'مُكَعَّبُ الثَّلْج 🧊',
    emoji: '🧊',
    detail: 'عندما يبرد الماء كثيراً يتجمد ويصبح صلباً متماسكاً كالثلج في الشتاء.'
  },
  {
    state: 'liquid',
    name: 'الحَالَةُ السَّائِلَة (المَاء)',
    example: 'مَاءُ الشُّرْب 💧',
    emoji: '💧',
    detail: 'الماء السائل الذي نشربه ونسقي به النباتات ويجري في الأنهار والبحار.'
  },
  {
    state: 'gas',
    name: 'الحَالَةُ الغَازِيَّة (البُخَار)',
    example: 'بُخَارُ المَاءِ ☁️',
    emoji: '☁️',
    detail: 'عندما يسخن الماء يتبخر ويصعد إلى السماء ليشكل السحب والغيوم.'
  }
];

export interface MagnetItem {
  name: string;
  emoji: string;
  attracted: boolean;
  material: string;
}

export const MAGNET_ITEMS: MagnetItem[] = [
  { name: 'مِسْمَارُ حَدِيد', emoji: '🔩', attracted: true, material: 'حديد' },
  { name: 'مِمْحَاة', emoji: '🧼', attracted: false, material: 'مطاط' },
  { name: 'مِشْبَكُ وَرَق', emoji: '📎', attracted: true, material: 'معدن' },
  { name: 'مِسْطَرَةُ خَشَب', emoji: '📏', attracted: false, material: 'خشب' },
  { name: 'مِقَصُّ مَعْدِن', emoji: '✂️', attracted: true, material: 'صلب' },
  { name: 'قَلَمُ رَصَاص', emoji: '✏️', attracted: false, material: 'خشب وجرافيت' }
];
