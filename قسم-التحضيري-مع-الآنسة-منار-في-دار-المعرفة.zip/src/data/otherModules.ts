export interface ColorItem {
  id: string;
  name: string;
  arabicName: string;
  hex: string;
  bgClass: string;
  borderClass: string;
  textClass: string;
  exampleItems: { name: string; emoji: string }[];
}

export const COLORS_DATA: ColorItem[] = [
  {
    id: 'red',
    name: 'Red',
    arabicName: 'أَحْمَر',
    hex: '#EF4444',
    bgClass: 'bg-red-500',
    borderClass: 'border-red-400',
    textClass: 'text-red-700',
    exampleItems: [
      { name: 'تُفَّاحَة', emoji: '🍎' },
      { name: 'فَرَاوْلَة', emoji: '🍓' },
      { name: 'قَلْب', emoji: '❤️' }
    ]
  },
  {
    id: 'yellow',
    name: 'Yellow',
    arabicName: 'أَصْفَر',
    hex: '#FBBF24',
    bgClass: 'bg-amber-400',
    borderClass: 'border-amber-400',
    textClass: 'text-amber-800',
    exampleItems: [
      { name: 'شَمْس', emoji: '☀️' },
      { name: 'مَوْز', emoji: '🍌' },
      { name: 'لَيْمُون', emoji: '🍋' }
    ]
  },
  {
    id: 'blue',
    name: 'Blue',
    arabicName: 'أَزْرَق',
    hex: '#3B82F6',
    bgClass: 'bg-blue-500',
    borderClass: 'border-blue-400',
    textClass: 'text-blue-700',
    exampleItems: [
      { name: 'بَحْر', emoji: '🌊' },
      { name: 'سَمَاء', emoji: '🌌' },
      { name: 'حُوت', emoji: '🐋' }
    ]
  },
  {
    id: 'green',
    name: 'Green',
    arabicName: 'أَخْضَر',
    hex: '#10B981',
    bgClass: 'bg-emerald-500',
    borderClass: 'border-emerald-400',
    textClass: 'text-emerald-700',
    exampleItems: [
      { name: 'شَجَرَة', emoji: '🌳' },
      { name: 'ضِفْدَع', emoji: '🐸' },
      { name: 'وَرَقَة نَبَات', emoji: '🍃' }
    ]
  },
  {
    id: 'pink',
    name: 'Pink',
    arabicName: 'وَرْدِي',
    hex: '#EC4899',
    bgClass: 'bg-pink-400',
    borderClass: 'border-pink-400',
    textClass: 'text-pink-700',
    exampleItems: [
      { name: 'زَهْرَة', emoji: '🌸' },
      { name: 'فَلَامِنْغُو', emoji: '🦩' },
      { name: 'حَلْوَى', emoji: '🍧' }
    ]
  },
  {
    id: 'purple',
    name: 'Purple',
    arabicName: 'بَنَفْسَجِي',
    hex: '#8B5CF6',
    bgClass: 'bg-purple-500',
    borderClass: 'border-purple-400',
    textClass: 'text-purple-700',
    exampleItems: [
      { name: 'بَاذِنْجَان', emoji: '🍆' },
      { name: 'عِنَب', emoji: '🍇' },
      { name: 'فَرَاشَة', emoji: '🪻' }
    ]
  },
  {
    id: 'orange',
    name: 'Orange',
    arabicName: 'بُرْتُقَالِي',
    hex: '#F97316',
    bgClass: 'bg-orange-500',
    borderClass: 'border-orange-400',
    textClass: 'text-orange-700',
    exampleItems: [
      { name: 'بُرْتُقَال', emoji: '🍊' },
      { name: 'جَزَر', emoji: '🥕' },
      { name: 'ثَعْلَب', emoji: '🦊' }
    ]
  },
  {
    id: 'brown',
    name: 'Brown',
    arabicName: 'بُنِّي',
    hex: '#78350F',
    bgClass: 'bg-amber-800',
    borderClass: 'border-amber-900',
    textClass: 'text-amber-900',
    exampleItems: [
      { name: 'دُبّ', emoji: '🐻' },
      { name: 'شُوكُولَاتَة', emoji: '🍫' },
      { name: 'جِذْع شَجَرَة', emoji: '🪵' }
    ]
  },
  {
    id: 'black',
    name: 'Black',
    arabicName: 'أَسْوَد',
    hex: '#1E293B',
    bgClass: 'bg-slate-900',
    borderClass: 'border-slate-800',
    textClass: 'text-slate-900',
    exampleItems: [
      { name: 'لَيْل', emoji: '🌃' },
      { name: 'فَحْم', emoji: '🪨' },
      { name: 'عَجَلَة', emoji: '🛞' }
    ]
  },
  {
    id: 'white',
    name: 'White',
    arabicName: 'أَبْيَض',
    hex: '#FFFFFF',
    bgClass: 'bg-white',
    borderClass: 'border-slate-300',
    textClass: 'text-slate-700',
    exampleItems: [
      { name: 'حَلِيب', emoji: '🥛' },
      { name: 'سَحَابَة', emoji: '☁️' },
      { name: 'ثَلْج', emoji: '❄️' }
    ]
  }
];

export interface ShapeItem {
  id: string;
  name: string;
  arabicName: string;
  sides: number;
  corners: number;
  description: string;
  realWorldExample: string;
  emojiExample: string;
  svgPath: string;
}

export const SHAPES_DATA: ShapeItem[] = [
  {
    id: 'circle',
    name: 'Circle',
    arabicName: 'دَائِرَة',
    sides: 0,
    corners: 0,
    description: 'خط منحنٍ مغلق ومستدير، ليس له أضلاع ولا زوايا، يدور مثل العجلة!',
    realWorldExample: 'الساعة والبيتزا وكرة القدم',
    emojiExample: '⚽',
    svgPath: '<circle cx="50" cy="50" r="40" fill="#38BDF8" stroke="#0284C7" stroke-width="6"/>'
  },
  {
    id: 'square',
    name: 'Square',
    arabicName: 'مُرَبَّع',
    sides: 4,
    corners: 4,
    description: 'له أربعة أضلاع متساوية في الطول تماماً، وأربع زوايا قائمة كصندوق الهدية!',
    realWorldExample: 'علبة الهدية وبلاط الأرضية',
    emojiExample: '🎁',
    svgPath: '<rect x="15" y="15" width="70" height="70" rx="10" fill="#F472B6" stroke="#DB2777" stroke-width="6"/>'
  },
  {
    id: 'triangle',
    name: 'Triangle',
    arabicName: 'مُثَلَّث',
    sides: 3,
    corners: 3,
    description: 'له ثلاثة أضلاع وثلاث زوايا جميلة تشبه شريحة الجبن اللذيذة أو سقف البيت!',
    realWorldExample: 'شريحة البيتزا وهرم الألعاب',
    emojiExample: '🍕',
    svgPath: '<polygon points="50,15 15,85 85,85" fill="#FBBF24" stroke="#D97706" stroke-width="6" stroke-linejoin="round"/>'
  },
  {
    id: 'rectangle',
    name: 'Rectangle',
    arabicName: 'مُسْتَطِيل',
    sides: 4,
    corners: 4,
    description: 'له أربعة أضلاع، ضلعان طويلان وضلعان قصيران كشاشة التلفاز والباب!',
    realWorldExample: 'باب القسم وكتاب القراءة',
    emojiExample: '🚪',
    svgPath: '<rect x="10" y="25" width="80" height="50" rx="8" fill="#34D399" stroke="#059669" stroke-width="6"/>'
  },
  {
    id: 'oval',
    name: 'Oval',
    arabicName: 'بَيْضَاوِي',
    sides: 0,
    corners: 0,
    description: 'منحنٍ جميل مستدير لكنه ممتد قليلاً مثل البيضة تماماً!',
    realWorldExample: 'البيضة ومرآة الغرفة',
    emojiExample: '🥚',
    svgPath: '<ellipse cx="50" cy="50" rx="42" ry="28" fill="#A78BFA" stroke="#7C3AED" stroke-width="6"/>'
  },
  {
    id: 'star',
    name: 'Star',
    arabicName: 'نَجْمَة',
    sides: 10,
    corners: 5,
    description: 'تلمع في السماء بخمسة رؤوس ذهبية تنير لنا عتمة الليل!',
    realWorldExample: 'نجمة السماء ونجمة البحر',
    emojiExample: '⭐',
    svgPath: '<polygon points="50,10 62,38 92,38 67,56 77,85 50,67 23,85 33,56 8,38 38,38" fill="#FDE047" stroke="#CA8A04" stroke-width="4" stroke-linejoin="round"/>'
  }
];

export interface PreWritingTrack {
  id: string;
  title: string;
  instruction: string;
  type: 'horizontal' | 'vertical' | 'slanted' | 'zigzag' | 'waves' | 'spiral';
  svgPath: string;
  startPoint: { x: number; y: number };
  endPoint: { x: number; y: number };
}

export const PRE_WRITING_TRACKS: PreWritingTrack[] = [
  {
    id: 'horiz',
    title: 'الخَطُّ الأُفُقِيُّ (سَيْرُ السَّيَّارَة)',
    instruction: 'تتبع المسار من اليمين إلى اليسار على استقامة واحدة 🚗',
    type: 'horizontal',
    svgPath: 'M 50,100 L 450,100',
    startPoint: { x: 450, y: 100 },
    endPoint: { x: 50, y: 100 }
  },
  {
    id: 'vert',
    title: 'الخَطُّ العَمُودِيُّ (سُقُوطُ المَطَر)',
    instruction: 'انزل بالقلم من الأعلى إلى الأسفل مستقيماً كالماء المتدفق 🌧️',
    type: 'vertical',
    svgPath: 'M 250,20 L 250,180',
    startPoint: { x: 250, y: 20 },
    endPoint: { x: 250, y: 180 }
  },
  {
    id: 'slanted',
    title: 'الخَطُّ المَائِلُ (الزُّحْلَيْقَة)',
    instruction: 'تزحلق بالقلم بميلان ممتع من أعلى اليمين إلى أسفل اليسار 🛝',
    type: 'slanted',
    svgPath: 'M 420,30 L 80,170',
    startPoint: { x: 420, y: 30 },
    endPoint: { x: 80, y: 170 }
  },
  {
    id: 'zigzag',
    title: 'خَطُّ الزِّكْزَاك (قِمَمُ الجِبَال)',
    instruction: 'اصعد وانزل كأنك تصعد قمم الجبال العالية ⛰️',
    type: 'zigzag',
    svgPath: 'M 450,150 L 375,50 L 300,150 L 225,50 L 150,150 L 75,50',
    startPoint: { x: 450, y: 150 },
    endPoint: { x: 75, y: 50 }
  },
  {
    id: 'waves',
    title: 'الخَطُّ المُنْحَنِي (أَمْوَاجُ البَحْر)',
    instruction: 'تمايل مع أمواج البحر اللطيفة بانحناءات سلسة 🌊',
    type: 'waves',
    svgPath: 'M 450,100 Q 375,30 300,100 T 150,100 T 50,100',
    startPoint: { x: 450, y: 100 },
    endPoint: { x: 50, y: 100 }
  }
];

export interface BehaviorScenario {
  id: string;
  title: string;
  situation: string;
  emoji: string;
  choiceA: { text: string; isCorrect: boolean; feedback: string };
  choiceB: { text: string; isCorrect: boolean; feedback: string };
  virtue: string;
}

export const BEHAVIOR_SCENARIOS: BehaviorScenario[] = [
  {
    id: 'share_toys',
    title: 'المُشَارَكَةُ مَعَ الأَصْدِقَاء',
    situation: 'صديقك في القسم ليس لديه أقلام تلوين ويريد تلوين رسمته.. ماذا تفعل؟',
    emoji: '🎨',
    choiceA: {
      text: 'أشاركه علبة ألواني وأبتسم له بلطف 💖',
      isCorrect: true,
      feedback: 'أحسنت يا بطل! التعاون والمشاركة ينشران المحبة والصداقة.'
    },
    choiceB: {
      text: 'أخفي ألواني ولا أدعه يلون بها ❌',
      isCorrect: false,
      feedback: 'لا يا صغيري، الصديق الطيب يحب لأخيه ما يحب لنفسه.'
    },
    virtue: 'التعاون والمحبة'
  },
  {
    id: 'respect_teacher',
    title: 'الاسْتِمَاعُ لِلْمُعَلِّمَة',
    situation: 'المعلمة تشرح درساً مهماً وممتعاً على الشاشة.. كيف أتصرف؟',
    emoji: '👩‍🏫',
    choiceA: {
      text: 'أتكلم مع زميلي وألعب في مقعدي ❌',
      isCorrect: false,
      feedback: 'هذا يشتت زملائي ويزعج معلمتي الحبيبة.'
    },
    choiceB: {
      text: 'أنصت بأدب وأرفع يدي بهدوء عندما أريد الإجابة 🙋‍♂️',
      isCorrect: true,
      feedback: 'رائع جداً! أدب الاستماع علامة التلميذ النجيب والمتفوق.'
    },
    virtue: 'احترام المعلمة والنظام'
  },
  {
    id: 'tidy_tools',
    title: 'تَرْتِيبُ الأَدَوَات',
    situation: 'انتهت حصة الرسم والنشاط، والأوراق والألوان على الطاولة.. ماذا أفعل؟',
    emoji: '🎒',
    choiceA: {
      text: 'أرتب أدواتي في مقلمتي وأرمي البقايا في سلة المهملات 🗑️',
      isCorrect: true,
      feedback: 'ممتاز! النظافة والترتيب يجعلان قسمنا جميلاً ومريحاً.'
    },
    choiceB: {
      text: 'أترك كل شيء مبعثراً وأخرج للعب ❌',
      isCorrect: false,
      feedback: 'لا، التلميذ المنظم يحافظ دوماً على نظافة قسمه ومقعده.'
    },
    virtue: 'النظافة والمسؤولية'
  },
  {
    id: 'magic_words',
    title: 'الكَلِمَاتُ الطَّيِّبَة',
    situation: 'عندما أطلب شيئاً من معلمتي أو صديقي، ماذا أقول؟',
    emoji: '🤝',
    choiceA: {
      text: 'أقول "من فضلك" وعندما أستلمه أقول "شكراً جزيلاً" ✨',
      isCorrect: true,
      feedback: 'كلمات سحرية جميلة تجعل قلوب الجميع مسرورة بك!'
    },
    choiceB: {
      text: 'أصرخ وآخذ الشيء بسرعة دون استئذان ❌',
      isCorrect: false,
      feedback: 'الاستئذان واللطف هما خُلُق التلميذ المسلم المهذب.'
    },
    virtue: 'آداب الحديث والاستئذان'
  }
];

export interface SongItem {
  id: string;
  title: string;
  topic: string;
  icon: string;
  melodyType: 'cheery' | 'marching' | 'lullaby';
  lyricsLines: {
    line: string;
    words: string[];
  }[];
}

export const SONGS_DATA: SongItem[] = [
  {
    id: 'alphabet_song',
    title: 'نَشِيدُ الحُرُوفِ العَرَبِيَّة',
    topic: 'لغتي الجميلة',
    icon: '🔤',
    melodyType: 'cheery',
    lyricsLines: [
      {
        line: 'أَلِفٌ بَاءٌ تَاءٌ ثَاء',
        words: ['أَلِفٌ', 'بَاءٌ', 'تَاءٌ', 'ثَاء']
      },
      {
        line: 'جِيمٌ حَاءٌ خَاءٌ دَال',
        words: ['جِيمٌ', 'حَاءٌ', 'خَاءٌ', 'دَال']
      },
      {
        line: 'لُغَتِي نُورٌ لُغَتِي عِزّ',
        words: ['لُغَتِي', 'نُورٌ', 'لُغَتِي', 'عِزّ']
      },
      {
        line: 'أَحْفَظُهَا فِي كُلِّ مَجَال',
        words: ['أَحْفَظُهَا', 'فِي', 'كُلِّ', 'مَجَال']
      }
    ]
  },
  {
    id: 'numbers_song',
    title: 'أُنْشُودَةُ الأَعْدَادِ المَرِحَة',
    topic: 'الرياضيات الممتعة',
    icon: '🔢',
    melodyType: 'marching',
    lyricsLines: [
      {
        line: 'وَاحِدٌ هُوَ رَبِّي العَالِي',
        words: ['وَاحِدٌ', 'هُوَ', 'رَبِّي', 'العَالِي']
      },
      {
        line: 'اِثْنَانِ هُمَا أُمِّي وَأَبِي',
        words: ['اِثْنَانِ', 'هُمَا', 'أُمِّي', 'وَأَبِي']
      },
      {
        line: 'ثَلَاثَةٌ أَرْكَانُ هِلَالِي',
        words: ['ثَلَاثَةٌ', 'أَرْكَانُ', 'هِلَالِي']
      },
      {
        line: 'أَرْبَعَةٌ تُشْبِهُ صَفَحَاتِ كِتَابِي',
        words: ['أَرْبَعَةٌ', 'تُشْبِهُ', 'كِتَابِي']
      },
      {
        line: 'خَمْسَةُ أَصَابِعَ فِي كَفِّي',
        words: ['خَمْسَةُ', 'أَصَابِعَ', 'فِي', 'كَفِّي']
      }
    ]
  },
  {
    id: 'school_song',
    title: 'مَدْرَسَتِي بَيْتِي الثَّانِي',
    topic: 'المدرسة والقسم',
    icon: '🏫',
    melodyType: 'cheery',
    lyricsLines: [
      {
        line: 'مَدْرَسَتِي حُلْوَةْ وَنَظِيفَة',
        words: ['مَدْرَسَتِي', 'حُلْوَةْ', 'وَنَظِيفَة']
      },
      {
        line: 'فِيهَا أَلْقَى أَحْلَى رِفَاق',
        words: ['فِيهَا', 'أَلْقَى', 'أَحْلَى', 'رِفَاق']
      },
      {
        line: 'مَعَ مُعَلِّمَتِي أَتَعَلَّم',
        words: ['مَعَ', 'مُعَلِّمَتِي', 'أَتَعَلَّم']
      },
      {
        line: 'أَرْسُمُ أَقْرَأُ كُلَّ صَبَاح',
        words: ['أَرْسُمُ', 'أَقْرَأُ', 'كُلَّ', 'صَبَاح']
      }
    ]
  }
];

export interface WorldTopic {
  id: string;
  title: string;
  category: string;
  emoji: string;
  summary: string;
  keyItems: { name: string; detail: string; emoji: string }[];
  quizQuestion: string;
  quizOptions: { text: string; isCorrect: boolean }[];
}

export const WORLD_TOPICS: WorldTopic[] = [
  {
    id: 'senses',
    title: 'الحَوَاسُّ الخَمْسُ العَجِيبَة',
    category: 'أنا وجسمي',
    emoji: '👁️',
    summary: 'أنعم الله علينا بخمس حواس نكتشف بها العالم الجميل من حولنا!',
    keyItems: [
      { name: 'البَصَر (العَيْنَان)', detail: 'نرى بهما الألوان والأشكال والكتب 👁️', emoji: '👁️' },
      { name: 'السَّمْع (الأُذُنَان)', detail: 'نسمع بهما أصوات الطيور والقرآن وصوت المعلمة 👂', emoji: '👂' },
      { name: 'الشَّمّ (الأَنْف)', detail: 'نشم به عطر الأزهار الزكية وروائح الطعام 👃', emoji: '👃' },
      { name: 'التَّذَوُّق (اللِّسَان)', detail: 'نميز به الطعم الحلو والمالح والحامض 👅', emoji: '👅' },
      { name: 'اللَّمْس (اليَدَان وَالجِلْد)', detail: 'نشعر به بالحرارة والبرودة والناعم والخشن ✋', emoji: '✋' }
    ],
    quizQuestion: 'بِأَيِّ حَاسَّةٍ نَسْمَعُ صَوْتَ الجَرَسِ فِي الصَّبَاح؟ 🔔',
    quizOptions: [
      { text: 'بِحَاسَّةِ السَّمْعِ (الأُذُن) 👂', isCorrect: true },
      { text: 'بِحَاسَّةِ الشَّمِّ (الأَنْف) 👃', isCorrect: false },
      { text: 'بِحَاسَّةِ التَّذَوُّقِ (اللِّسَان) 👅', isCorrect: false }
    ]
  },
  {
    id: 'animals',
    title: 'الحَيَوَانَاتُ الأَلِيفَةُ وَالبَرِّيَّة',
    category: 'الكائنات الحية',
    emoji: '🦁',
    summary: 'هناك حيوانات أليفة تعيش معنا في المزرعة، وحيوانات برية تعيش في الغابة!',
    keyItems: [
      { name: 'الحَيَوَانَاتُ الأَلِيفَة', detail: 'مثل الخروف 🐑 والبقرة 🐄 والحصان 🐎، تفيدنا بالحليب والصوف', emoji: '🐑' },
      { name: 'الحَيَوَانَاتُ البَرِّيَّة', detail: 'مثل الأسد 🦁 والزرافة 🦒 والفيل 🐘، تعيش في الغابات والمحميات', emoji: '🦁' },
      { name: 'الطُّيُورُ الجَمِيلَة', detail: 'تطير بأجنحتها في السماء مثل العصفور 🐦 والحمامة 🕊️', emoji: '🐦' }
    ],
    quizQuestion: 'أَيٌّ مِنْ هَذِهِ الحَيَوَانَاتِ يُعْطِينَا الحَلِيبَ الطَّازَج؟ 🥛',
    quizOptions: [
      { text: 'البَقَرَةُ الطَّيِّبَة 🐄', isCorrect: true },
      { text: 'الأَسَدُ القَوِي 🦁', isCorrect: false },
      { text: 'الثَّعْلَبُ المَاكِر 🦊', isCorrect: false }
    ]
  },
  {
    id: 'seasons',
    title: 'فُصُولُ السَّنَةِ الأَرْبَعَة',
    category: 'الطقس والطبيعة',
    emoji: '🍂',
    summary: 'تدور السنة وتتغير فيها الفصول لتبهرنا الطبيعة بجمالها!',
    keyItems: [
      { name: 'فَصْلُ الخَرِيف', detail: 'تتساقط فيه أوراق الأشجار وتهب الرياح 🍂', emoji: '🍂' },
      { name: 'فَصْلُ الشِّتَاء', detail: 'يسقط المطر والثلج ونرتدي ملابس دافئة ❄️', emoji: '❄️' },
      { name: 'فَصْلُ الرَّبِيع', detail: 'تتفتح الأزهار وتخضر الحقول وتغرد الطيور 🌸', emoji: '🌸' },
      { name: 'فَصْلُ الصَّيْف', detail: 'شمس مشرقة ودافئة ونذهب إلى شاطئ البحر ☀️', emoji: '🏖️' }
    ],
    quizQuestion: 'فِي أَيِّ فَصْلٍ تَتَفَتَّحُ الأَزْهَارُ وَتَطِيرُ الفَرَاشَات؟ 🌸',
    quizOptions: [
      { text: 'فَصْلُ الرَّبِيعِ البَدِيع 🌸', isCorrect: true },
      { text: 'فَصْلُ الشِّتَاءِ البَارِد ❄️', isCorrect: false },
      { text: 'فَصْلُ الخَرِيف 🍂', isCorrect: false }
    ]
  },
  {
    id: 'healthy_food',
    title: 'الغِذَاءُ الصِّحِّيُّ لِأَبْطَالِ الغَد',
    category: 'الصحة والنظافة',
    emoji: '🥗',
    summary: 'الطعام الصحي يمنح أجسامنا النشاط والذكاء والقوة لمذاكرة الدروس!',
    keyItems: [
      { name: 'الفَوَاكِهُ وَالخُضَار', detail: 'غنية بالفيتامينات مثل التفاح 🍎 والجزر 🥕 والموز 🍌', emoji: '🍎' },
      { name: 'الحَلِيبُ وَالأَجْبَان', detail: 'تبني عظامنا وأسناننا القوية 🥛🧀', emoji: '🥛' },
      { name: 'المَاءُ النَّقِيّ', detail: 'نشرب الماء كل يوم لنبقى منتعشين وأقوياء 💧', emoji: '💧' }
    ],
    quizQuestion: 'مَا هُوَ الغِذَاءُ الَّذِي يَجْعَلُ أَسْنَانَنَا وَعِظَامَنَا قَوِيَّة؟ 🦷',
    quizOptions: [
      { text: 'الحَلِيبُ الطَّازَج 🥛', isCorrect: true },
      { text: 'الحَلْوَى وَالمُشَرَّبَاتُ الغَازِيَّة 🍬', isCorrect: false },
      { text: 'رَقَائِقُ البَطَاطِس 🍟', isCorrect: false }
    ]
  }
];
