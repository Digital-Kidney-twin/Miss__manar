export interface NumberLesson {
  num: number;
  symbol: string;
  word: string;
  childSpeech: string;
  itemType: string;
  itemEmoji: string;
  singular: string;
  plural: string;
  countingItems: string[];
  writingSteps: {
    step: number;
    title: string;
    instruction: string;
    arrow: string;
  }[];
  tenFrameCount: number;
  funFact: string;
}

export const NUMBERS_DATA: NumberLesson[] = [
  {
    num: 0,
    symbol: '0',
    word: 'صِفْر',
    childSpeech: 'نبدأ من النقطة ⭐... الصفر يعني لا شيء في السلة، نقطة لطيفة وصغيرة!',
    itemType: 'فارغ',
    itemEmoji: '🧺',
    singular: 'شيء',
    plural: 'أشياء',
    countingItems: [],
    writingSteps: [
      { step: 1, title: 'البداية', instruction: 'نضع نقطة واحدة واضحة على السطر ⭐', arrow: '•' }
    ],
    tenFrameCount: 0,
    funFact: 'الصفر يعني أن السلة فارغة وتنتظر أن نملأها بالهدايا!'
  },
  {
    num: 1,
    symbol: '1',
    word: 'وَاحِد',
    childSpeech: 'نبدأ من هنا ⭐... ننزل بخط مستقيم مثل العصا الطويلة... ها هو الرقم 1!',
    itemType: 'شمس',
    itemEmoji: '☀️',
    singular: 'شمس واحدة',
    plural: 'شمس واحدة',
    countingItems: ['☀️'],
    writingSteps: [
      { step: 1, title: 'نبدأ من الأعلى ⭐', instruction: 'نضع القلم في الأعلى فوق السطر', arrow: '⬇️' },
      { step: 2, title: 'ننزل مستقيمين', instruction: 'ننزل بخط عمودي جميل ومستقيم حتى نلمس السطر', arrow: '⬇️' }
    ],
    tenFrameCount: 1,
    funFact: 'لدينا شمس واحدة تنير العالم وقمر واحد في السماء!'
  },
  {
    num: 2,
    symbol: '2',
    word: 'اِثْنَان',
    childSpeech: 'نبدأ من هنا ⭐... خط أفقي صغير لليمين، ثم ننزل بخط عمودي جميل... ها هو الرقم 2!',
    itemType: 'بطات',
    itemEmoji: '🦆',
    singular: 'بطة',
    plural: 'بطتان',
    countingItems: ['🦆', '🦆'],
    writingSteps: [
      { step: 1, title: 'نبدأ من اليسار ⭐', instruction: 'نمشي بخط أفقي صغير إلى اليمين', arrow: '➡️' },
      { step: 2, title: 'ننزل عمودياً', instruction: 'ننزل بخط مستقيم للأسفل حتى نصل السطر', arrow: '⬇️' }
    ],
    tenFrameCount: 2,
    funFact: 'لدينا عينان جميلتان وأذنان نسمع بهما واثنتان من الأيدي!'
  },
  {
    num: 3,
    symbol: '3',
    word: 'ثَلَاثَة',
    childSpeech: 'نبدأ من هنا ⭐... ننزل شوية... سنّة أولى وسنّة ثانية... ثم ننزل عموداً مستقيماً... ها هو الرقم 3!',
    itemType: 'تفاحات',
    itemEmoji: '🍎',
    singular: 'تفاحة',
    plural: 'تفاحات',
    countingItems: ['🍎', '🍎', '🍎'],
    writingSteps: [
      { step: 1, title: 'السنّة الأولى ⭐', instruction: 'نبدأ من اليمين بنصف دائرة صغيرة للأعلى', arrow: '↪️' },
      { step: 2, title: 'السنّة الثانية', instruction: 'نعمل سنّة ثانية متصلة بها كأنها شوكة طعام', arrow: '↪️' },
      { step: 3, title: 'النزول للسطر', instruction: 'ننزل بخط مستقيم للأسفل حتى نلمس السطر', arrow: '⬇️' }
    ],
    tenFrameCount: 3,
    funFact: 'المثلث له 3 أضلاع وإشارة المرور لها 3 ألوان مضيئة!'
  },
  {
    num: 4,
    symbol: '4',
    word: 'أَرْبَعَة',
    childSpeech: 'نبدأ من هنا ⭐... نصف دائرة أولى، ثم نصف دائرة ثانية مثل الجناحين... ها هو الرقم 4!',
    itemType: 'نجوم',
    itemEmoji: '⭐',
    singular: 'نجمة',
    plural: 'نجوم',
    countingItems: ['⭐', '⭐', '⭐', '⭐'],
    writingSteps: [
      { step: 1, title: 'القوس الأول ⭐', instruction: 'نبدأ من الأعلى ونرسم قوساً منحنياً إلى الوسط', arrow: '↩️' },
      { step: 2, title: 'القوس الثاني', instruction: 'نكمل بقوس ثانٍ يشبهه تماماً نحو الأسفل', arrow: '↩️' }
    ],
    tenFrameCount: 4,
    funFact: 'للسيارة 4 عجلات، والمربع له 4 أضلاع متساوية!'
  },
  {
    num: 5,
    symbol: '5',
    word: 'خَمْسَة',
    childSpeech: 'نبدأ من هنا ⭐... ندور وندور كالدائرة ونغلقها كالكعكة اللذيذة... ها هو الرقم 5!',
    itemType: 'بالونات',
    itemEmoji: '🎈',
    singular: 'بالون',
    plural: 'بالونات',
    countingItems: ['🎈', '🎈', '🎈', '🎈', '🎈'],
    writingSteps: [
      { step: 1, title: 'نبدأ الدوران ⭐', instruction: 'نضع القلم في الأعلى ونتحرك برفق على شكل دائرة', arrow: '🔄' },
      { step: 2, title: 'إغلاق الدائرة', instruction: 'نكمل الدوران ونغلق الكعكة من نقطة البداية', arrow: '⭕' }
    ],
    tenFrameCount: 5,
    funFact: 'في كل يد من أيدينا 5 أصابع رائعة نعد بها!'
  },
  {
    num: 6,
    symbol: '6',
    word: 'سِتَّة',
    childSpeech: 'نبدأ من هنا ⭐... خط أفقي لليسار، ثم ننزل بخط مستقيم للأسفل... ها هو الرقم 6!',
    itemType: 'فراشات',
    itemEmoji: '🦋',
    singular: 'فراشة',
    plural: 'فراشات',
    countingItems: ['🦋', '🦋', '🦋', '🦋', '🦋', '🦋'],
    writingSteps: [
      { step: 1, title: 'خط أفقي ⭐', instruction: 'نبدأ من اليمين ونتحرك أفقياً لليسار', arrow: '⬅️' },
      { step: 2, title: 'النزول للسطر', instruction: 'ننزل بخط عمودي مستقيم نحو الأسفل', arrow: '⬇️' }
    ],
    tenFrameCount: 6,
    funFact: 'حبة النرد لها 6 أوجه، والنحلة لها 6 أرجل تساعدها في صنع العسل!'
  },
  {
    num: 7,
    symbol: '7',
    word: 'سَبْعَة',
    childSpeech: 'نبدأ من هنا ⭐... ننزل للأسفل، ثم نصعد للأعلى فرحين كأننا نرفع يدينا للسماء... ها هو الرقم 7!',
    itemType: 'أزهار',
    itemEmoji: '🌸',
    singular: 'زهرة',
    plural: 'أزهار',
    countingItems: ['🌸', '🌸', '🌸', '🌸', '🌸', '🌸', '🌸'],
    writingSteps: [
      { step: 1, title: 'النزول بميلان ⭐', instruction: 'ننزل من الأعلى يميناً بخط مائل للأسفل', arrow: '↙️' },
      { step: 2, title: 'الصعود للأعلى', instruction: 'نصعد من النقطة السفلية بميلان نحو الأعلى يساراً', arrow: '↖️' }
    ],
    tenFrameCount: 7,
    funFact: 'أيام الأسبوع 7 أيام، وقوس قزح يتكون من 7 ألوان مبهجة!'
  },
  {
    num: 8,
    symbol: '8',
    word: 'ثَمَانِيَة',
    childSpeech: 'نبدأ من هنا ⭐... نصعد للأعلى مثل قمة الجبل، ثم ننزل للأسفل... ها هو الرقم 8!',
    itemType: 'كرات',
    itemEmoji: '⚽',
    singular: 'كرة',
    plural: 'كرات',
    countingItems: ['⚽', '⚽', '⚽', '⚽', '⚽', '⚽', '⚽', '⚽'],
    writingSteps: [
      { step: 1, title: 'صعود الجبل ⭐', instruction: 'نصعد من الأسفل إلى الأعلى بميلان', arrow: '↗️' },
      { step: 2, title: 'النزول من القمة', instruction: 'ننزل من القمة بميلان نحو الأسفل يساراً', arrow: '↘️' }
    ],
    tenFrameCount: 8,
    funFact: 'الأخطبوط اللطيف في البحر يمتلك 8 أذرع يسبح بها!'
  },
  {
    num: 9,
    symbol: '9',
    word: 'تِسْعَة',
    childSpeech: 'نبدأ من هنا ⭐... دائرة صغيرة في الأعلى، ثم ننزل بخط مستقيم مثل العصا... ها هو الرقم 9!',
    itemType: 'أقلام',
    itemEmoji: '✏️',
    singular: 'قلم',
    plural: 'أقلام',
    countingItems: ['✏️', '✏️', '✏️', '✏️', '✏️', '✏️', '✏️', '✏️', '✏️'],
    writingSteps: [
      { step: 1, title: 'رسم الدائرة ⭐', instruction: 'نرسم دائرة صغيرة مغلقة في الأعلى', arrow: '⭕' },
      { step: 2, title: 'العصا المستقيمة', instruction: 'ننزل من طرف الدائرة بخط عمودي مستقيم للأسفل', arrow: '⬇️' }
    ],
    tenFrameCount: 9,
    funFact: 'الرقم 9 هو أكبر رقم مكوّن من منزلة واحدة!'
  },
  {
    num: 10,
    symbol: '10',
    word: 'عَشَرَة',
    childSpeech: 'نبدأ من هنا ⭐... نكتب الرقم 1 وبجانبه صفر جميل... عشرة أصابع تصفق بحرارة!',
    itemType: 'مكعبات',
    itemEmoji: '🧊',
    singular: 'مكعب',
    plural: 'مكعبات',
    countingItems: ['🧊', '🧊', '🧊', '🧊', '🧊', '🧊', '🧊', '🧊', '🧊', '🧊'],
    writingSteps: [
      { step: 1, title: 'كتابة الرقم 1 ⭐', instruction: 'نكتب عصا مستقيمة من الأعلى للأسفل', arrow: '⬇️' },
      { step: 2, title: 'وضع الصفر', instruction: 'نضع نقطة الصفر على يمين الرقم 1', arrow: '•' }
    ],
    tenFrameCount: 10,
    funFact: 'إذا جمعنا أصابع يدنا اليمنى (5) واليسرى (5) نحصل على 10!'
  }
];

export interface MathConcept {
  id: string;
  title: string;
  opposite: string;
  question: string;
  itemA: { label: string; icon: string; sizeClass: string; isCorrect: boolean };
  itemB: { label: string; icon: string; sizeClass: string; isCorrect: boolean };
  tip: string;
}

// Convert any integer from 0 to 100 into spoken Arabic words
export function getArabicNumberWord(num: number): string {
  if (num === 0) return 'صِفْر';
  if (num === 100) return 'مِئَة';

  const singleUnits = ['', 'وَاحِد', 'اِثْنَان', 'ثَلَاثَة', 'أَرْبَعَة', 'خَمْسَة', 'سِتَّة', 'سَبْعَة', 'ثَمَانِيَة', 'تِسْعَة'];
  const unitsWithTanween = ['', 'وَاحِدٌ', 'اِثْنَانِ', 'ثَلَاثَةٌ', 'أَرْبَعَةٌ', 'خَمْسَةٌ', 'سِتَّةٌ', 'سَبْعَةٌ', 'ثَمَانِيَةٌ', 'تِسْعَةٌ'];
  const teens = ['عَشَرَة', 'أَحَدَ عَشَر', 'اثْنَا عَشَر', 'ثَلَاثَةَ عَشَر', 'أَرْبَعَةَ عَشَر', 'خَمْسَةَ عَشَر', 'سِتَّةَ عَشَر', 'سَبْعَةَ عَشَر', 'ثَمَانِيَةَ عَشَر', 'تِسْعَةَ عَشَر'];
  const tens = ['', 'عَشَرَة', 'عِشْرُون', 'ثَلَاثُون', 'أَرْبَعُون', 'خَمْسُون', 'سِتُّون', 'سَبْعُون', 'ثَمَانُون', 'تِسْعُون'];

  if (num < 10) return singleUnits[num];
  if (num >= 10 && num < 20) return teens[num - 10];

  const u = num % 10;
  const t = Math.floor(num / 10);

  if (u === 0) return tens[t];
  return `${unitsWithTanween[u]} وَ${tens[t]}`;
}

export interface FullNumberItem {
  num: number;
  word: string;
  units: number; // الوحدات (على اليمين دائماً)
  tens: number;  // العشرات (على اليسار دائماً)
}

export const ALL_100_NUMBERS: FullNumberItem[] = Array.from({ length: 100 }, (_, i) => {
  const n = i + 1;
  return {
    num: n,
    word: getArabicNumberWord(n),
    units: n === 100 ? 0 : n % 10,
    tens: n === 100 ? 10 : Math.floor(n / 10)
  };
});

export const TENS_NUMBERS = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

export const BASIC_MATH_CONCEPTS: MathConcept[] = [
  {
    id: 'size',
    title: 'كَبِير / صَغِير',
    opposite: 'الحجم',
    question: 'أَيْنَ هُوَ الفِيلُ الكَبِير؟ 🐘',
    itemA: { label: 'فِيلٌ كَبِير', icon: '🐘', sizeClass: 'text-8xl', isCorrect: true },
    itemB: { label: 'فَأْرٌ صَغِير', icon: '🐭', sizeClass: 'text-4xl', isCorrect: false },
    tip: 'الفيل ضخم وكبير، بينما الفأر صغير الحجم!'
  },
  {
    id: 'length',
    title: 'طَوِيل / قَصِير',
    opposite: 'الطول',
    question: 'أَيْنَ هُوَ الشَّيْءُ الأَطْوَل؟ 🦒',
    itemA: { label: 'زَرَافَةٌ طَوِيلَة', icon: '🦒', sizeClass: 'text-8xl', isCorrect: true },
    itemB: { label: 'أَرْنَبٌ قَصِير', icon: '🐇', sizeClass: 'text-4xl', isCorrect: false },
    tip: 'الزرافة عنقها طويل جداً، والأرنب قصير ولطيف!'
  },
  {
    id: 'position',
    title: 'فَوْق / تَحْت',
    opposite: 'المكان',
    question: 'أَيْنَ العُصْفُورُ الَّذِي فَوْقَ الشَّجَرَة؟ 🐦',
    itemA: { label: 'عُصْفُورٌ فَوْق', icon: '🐦☁️', sizeClass: 'text-7xl', isCorrect: true },
    itemB: { label: 'قِطٌّ تَحْت', icon: '🐱🌿', sizeClass: 'text-7xl', isCorrect: false },
    tip: 'العصفور يطير فوق الغصن، والقطة تجلس تحت الشجرة!'
  },
  {
    id: 'in_out',
    title: 'دَاخِل / خَارِج',
    opposite: 'المكان',
    question: 'أَيْنَ السَّمَكَةُ الَّتِي دَاخِلَ الحَوْض؟ 🐠',
    itemA: { label: 'دَاخِلَ الحَوْض', icon: '🫧🐠🫧', sizeClass: 'text-7xl', isCorrect: true },
    itemB: { label: 'خَارِجَ الحَوْض', icon: '🐱🧺', sizeClass: 'text-7xl', isCorrect: false },
    tip: 'السمكة تسبح داخل الماء لتتنفس بأمان!'
  }
];
